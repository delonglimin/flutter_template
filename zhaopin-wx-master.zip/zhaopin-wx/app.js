import { localData,empty  } from "./utils/index";
import { initMetaData,formatDict } from './utils/getData'
App({
  globalData:{
    networkType:null,
    safeTop:0,//顶部安全距离
    winWidth:0,
    winHeight:0,
    dpr:1,
    gpsOpen:false,
    system:'',
    statusBarHeight:0,//状态栏高度
    titleBarHeight:0, //标题栏高度
    navHeight:0,
    isLogin:false,
    cardStatus:{
      hasUser:false,
      hasGP:false,
    },
    balance:0,
    yuan:'',
    realName:false,//实名
    shipAdr:[],
    indusData:[],//工种
    benifit:[],//福利
    unread:0,
    canOnShow:1
  },
  onLaunch() {
   
  },
  onShow(){
    this.networkChange()
    this.initApp();
    
    if(this.globalData.canOnShow == 0){
      this.globalData.canOnShow=1
      return
    }
    // console.log('app onshow loadMetaInfos',this.globalData.canOnShow)
    this.loadMetaInfos()
 
  },
  initApp(){
    wx.getSystemInfo({
      success: (res) => {
        let {safeArea,system,statusBarHeight,platform,devicePixelRatio,locationEnabled} = res;
        let {width,height,top} = safeArea;
        this.globalData.system =  system = system.toLowerCase();
        this.globalData.dpr=devicePixelRatio;
        this.globalData.winWidth = width;
        this.globalData.winHeight = height;
        this.globalData.safeTop = top;
        this.globalData.gpsOpen = locationEnabled;
        if (platform === 'andorid' ) {
          this.globalData.titleBarHeight = 48
        } else {
          this.globalData.titleBarHeight = 44
        }
       
        this.globalData.statusBarHeight = statusBarHeight;
        
    
        // 总体高度 = 状态栏高度 + 导航栏高度
        this.globalData.navHeight = this.globalData.titleBarHeight + this.globalData.statusBarHeight
       
      }
    });
    // 名片信息
    let  {jobUserCardGroupBo,jobUserCardPersonalBo} = localData('cardInfo'),userInfo=localData('userInfo'),yuan=localData('yuan');
    this.globalData.isLogin = userInfo.id? true :false;
    this.globalData.yuan= yuan || '';
    
    this.globalData.cardStatus.hasGP = empty(jobUserCardGroupBo)? false : true;
    this.globalData.cardStatus.hasUser = empty(jobUserCardPersonalBo)? false : true;
   
    this.globalData.realName = userInfo.verifyStatus==1?true:false;
    this.globalData.balance= userInfo.balance;
    
    
    this.globalData.unread= localData('unread') || '0'
  
  },
  async loadMetaInfos(){
    let {job_industry,job_benifit,work_year,company_scale,company_type,report_type,card_group_total,feedback_type} = await initMetaData();
    if(!empty(job_industry)){
      let indusData = job_industry.map((it,idx)=>{
        let obj = {
          text:it.dictLabel,
          id:it.dictValue,
          badge:null,
          num:0,
          disabled:false
        };
        !empty(it.children) && (obj.children = it.children.map(c=>{
          return {
            idx:idx,
            text:c.dictLabel,
            id:c.dictValue
          }
        }));
        return obj
      });
      localData('indusData',indusData)
    }
    if(!empty(job_benifit)){
      let benifit = formatDict(job_benifit);
      localData('benifit',benifit)
    }
    if(!empty(work_year)){
      let yearArr = formatDict(work_year);
      localData('yearArr',yearArr)
    }
    if(!empty(card_group_total)){
      let memArr = formatDict(card_group_total);
      localData('memArr',memArr)
    }
    if(!empty(company_scale)){
      let comSArr = formatDict(company_scale);
      localData('comSArr',comSArr)
    }
    if(!empty(company_type)){
      let comTArr = formatDict(company_type);
      localData('comTArr',comTArr)
    }
    if(!empty(feedback_type)){
      let feedType = formatDict(feedback_type);
      localData('feedType',feedType)
    }
    if(!empty(report_type)){
      let reportArr = formatDict(report_type);
      localData('reportArr',reportArr)
    }
  },
  networkChange() {
    wx.getNetworkType({
      success:res=>{
     
        if (res.networkType != 'none') {
          this.globalData.networkType = res.networkType;
         // 有网
          this.globalData.hasNetwork = true
          wx.onNetworkStatusChange(res=>{
            if (res.isConnected) {
              this.globalData.networkType = res.networkType;
              this.globalData.hasNetwork = true
            } else {
              this.netDialog()
              this.globalData.hasNetwork = false;
              this.globalData.networkType = null;
            }
          })
        } else {
          this.netDialog()
          wx.onNetworkStatusChange(res=>{
            console.log('无网状态',res)
            if (res.isConnected) {
              this.globalData.networkType = res.networkType;
              this.globalData.hasNetwork = true;
              let pages = getCurrentPages()
              if(pages.length > 0) {
                let currentPage = pages[pages.length - 1]
                let url = '/'+currentPage.route;
                wx.reLaunch({url})
              }
            } else {
              //无网状态
              this.netDialog()
              this.globalData.networkType = null;
              this.globalData.hasNetwork = false
            }
          })
        }
      },fail:err=>{
        
      }
    })
  },

  netDialog(){
    wx.showModal({
      title:'网络异常',
      content:'系统网络异常，请稍后再试',
      confirmText:'重 试',
     // showCancel:false,
      success (res) {
        if (res.confirm) {
          let pages = getCurrentPages()
          
          if(pages.length > 0) {
            let currentPage = pages[pages.length - 1]
            let url = '/'+currentPage.route;
            wx.reLaunch({url})
          }
           
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  }

})