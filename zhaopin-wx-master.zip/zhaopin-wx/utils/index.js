export const formatNumber = (n) => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}
export const wxReport = (e) => {
  wx.reportEvent(e,{})
}

export const getUrlParams=(url) => {
  let urlStr = url.split('?')[1],obj = {};
  let paramsArr = urlStr.split('&')
  for(let i = 0,len = paramsArr.length;i<len;i++){
      let arr = paramsArr[i].split('=')
      obj[arr[0]] = arr[1];
  }
  return obj
}
export const empty = (a) => {
  let b,
    c,
    d,
    e = [void 0, null, !1, 0, '', '0']
  c = 0
  for (d = e.length; c < d; c++)
    if (a === e[c]) return !0
  if ('object' === typeof a) {
    if (0 === a.length) return !0
    for (b in a) return !1
    return !0
  }
  return !1
}
 
// 提示信息
export function msgToast(title,icon='none',duration=1500) {
  wx.showToast({
    title, icon, duration
  });
}
export const randomStr=(len=32)=> {
  let $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678',maxPos = $chars.length,pwd = '';
  for (let i = 0; i < len; i++) {
    pwd += $chars.charAt(Math.floor(Math.random() * maxPos))
  }
  return pwd
}
// app.js入口用 初始化
export const gbData =(k, v)=>{
  if (v === undefined) {
    return getApp().globalData[k]
  } else {
    getApp().globalData[k] = v
    
  }
}
// 手机缓存
export function localData(k, v) {
  if (v === undefined) {
    return wx.getStorageSync(k)
  } else if (v === null) {
    wx.removeStorage({
      key: k,
      fail() {},
    })
  } else {
    wx.setStorage({
      key: k,
      data: v,
      success() {
        // console.log('存',k,v)
      },
      fail() {
        //console.log('存失败',k,v)
      },
    })
  }
}
export function clearLocal() {
  wx.clearStorageSync()
}

export const checkEmail = (email) => {
  return RegExp(/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/).test(email);
}
export const checkMobile = (mobile) => {
  return RegExp(/^1[3456789]\d{9}$/).test(mobile);
}
export const getCurPage=()=>{
  let pages = getCurrentPages();
  let curPage = pages[pages.length - 1];
  return curPage
}
export const tidyBr=(val)=>{
  let res = val.replace(/(\n\r|\r\n|\r|\n\n|\n)/g, '<br/>');
  return res
}
export const tidyBrBack=(val)=>{
  let res = val.replace(/(<br\/>|<br>)/g, '\n');
  return res
}
export const sumAge=(birthdayTs)=>{
  const orginDate = new Date(birthdayTs),b_month=orginDate.getMonth()+1,b_day=orginDate.getDate();
  const curDate = new Date(), month = curDate.getMonth() + 1,day = curDate.getDate();
  let age = curDate.getFullYear() - orginDate.getFullYear() - 1;
  if (b_month < month || b_month === month && b_day <= day) {
    age++
  }
  if (age <= 0) {
    age = 1
  }
  return age
}
 
export const loginCtrl = (flag)=>{
  let token = localData('token');
  if (!token) {
    if(flag){
      // wx.showModal({ title: '提示', content: '请先登录才能继续操作', confirmText:'去登录', cancelText:'取消', success:res=>{ if (res.confirm) {
        wx.navigateTo({url: '/pages/user/login/index',})
      // } else { }}})
    }
    return false
  }else{
    return true
  }
}
export function randomString(e) {  
  e = e || 32;
  let t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678",
  a = t.length,
  n = "";
  for (let i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * a));
  return n
}
export function formatRichText(html){
  let newContent= html.replace(/<img[^>]*>/gi,function(match,capture){
      match = match.replace(/style="[^"]+"/gi, '');
      match = match.replace(/width="[^"]+"/gi, '');
      match = match.replace(/height="[^"]+"/gi, '');
     
      return match;
  });

  newContent = newContent.replace(/style="[^"]+"/gi,function(match,capture){
      match = match.replace(/width:[^;]+;/gi, 'max-width:100%;');
      return match;
  });
  newContent = newContent.replace(/<br[^>]*\/>/gi, '');
  newContent = newContent.replace(/<(pre|\/pre).*?>/gi, '');
 
  newContent = newContent.replace(/\<img/gi, '<img style="max-width:100%;height:auto;display:block;margin:10px 0;"');
  return newContent;
}
export function backLeft(){
  wx.navigateBack({
    delta: 1,
  })
}

export function formatSalary(salaryType,salaryMax,salaryMin,flag=0){
  let str = '';
  if(salaryType==0){
    
    return str= '面议'
  }
  let inStr = salaryType==1? ' /日' : ' /月';
  if(flag==1){
    str= salaryMin+'~'+salaryMax+' 元'+inStr;
  }else{
    if(salaryMax == salaryMin){
      str= format(salaryMin)+inStr
    } else if(salaryMax > salaryMin && salaryMin>0){
      str= format(salaryMin)+'~'+ format(salaryMax)+inStr
    }else{
      str= format(salaryMin)+ inStr
    } 
  }
  return str
}

export function format(num){
  if(num >= 1e3 && num < 1e4){
    return Math.round(num / 1e3) + 'k'
   // return parseInt(num / 1e3).toFixed(1) + 'k'
  }else if(num >= 1e4){
    return parseInt(num / 1e4).toFixed(1) + 'w'
  }else{
  return num + '元'
  }
}
export function formatCity(obj, arr, count, maxCount) {
  obj.forEach((item) => {
    item.count = count;
    let o = { id: item.code, text: item.name,disabled: false, };
    
    // if (item.children ) {
    //   if (item.count < maxCount) {
    //     item.count++;
    //     o.children = formatCity(item.children, [], item.count, maxCount);
    //   }
    //   arr.push(o);
    // }
      item.count++;
      if (item.count < maxCount) {
        if (item.children) {
          o.children = formatCity(item.children, [], item.count, maxCount);
        }
      }
      arr.push(o);
   

  });

  return arr;
}

export function isCardID(id){
  return /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(id)
}

/*节流*/
export function throttle(fn, interval) {
  var enterTime = 0;
  var gapTime = interval || 300 ;
  return function() {
    var context = this;
    var backTime = new Date();
    if (backTime - enterTime > gapTime) {
      fn.call(context,arguments);
      enterTime = backTime;
    }
  };
}

 
export function debounce(fn, wait) {
  var timer = null;
  return function () {
      var context = this
      var args = arguments
      if (timer) {
          clearTimeout(timer);
          timer = null;
      }
      timer = setTimeout(function () {
          fn.apply(context, args)
      }, wait)
  }
}

export const getViewInfo = (dom) => {
  return new Promise((resolve, reject) => {
    try {
      wx.createSelectorQuery().select(dom).boundingClientRect(res => {
        resolve(res)
      }).exec();
    }catch (err) {
      reject(err)
    }
  })
}  

// 身份证信息提取
export const formatIdCard=(IdCard, type)=> {
  //出生日期
  let birthday = IdCard.substring(6, 10) + "-" + IdCard.substring(10, 12) + "-" + IdCard.substring(12, 14)
  // 1-男 2 -女
  let sex = parseInt(IdCard.substr(16, 1)) % 2 === 1? 1:2;
  //获取年龄
  const ageDate = new Date(), month = ageDate.getMonth() + 1,day = ageDate.getDate();
  let age = ageDate.getFullYear() - IdCard.substring(6, 10) - 1;
  if (IdCard.substring(10, 12) < month || IdCard.substring(10, 12) === month && IdCard.substring(12, 14) <= day) {
    age++
  }
  if (age <= 0) {
    age = 1
  }
  return {birthday,age,sex}
}

