import { localData,gbData,empty } from './index';
import {viewCard,userinfo,msgList,upDateUser} from '../api/user';
import {original,textForEdit,imgForUpdate,mydiscts,realPhone} from '../api/base'
import {commonlog,sharelog,realWx} from '../api/job';

export function upDateUserInfo(data){
  return new Promise((resolve,reject)=>{
    upDateUser(data).then(res=>{
      resolve();
    }).catch(err=>{
      reject(err)
    });
  });
}

export function getCityCode(location){
  return new Promise((resolve,reject)=>{
    wx.request({
      url: `https://apis.map.qq.com/ws/geocoder/v1/?location=${location}&key=WD7BZ-GB2CQ-EJB54-GUDXN-ZHVYT-TXF3U&get_poi=0`,
      success:(res)=> {
       // console.log(res)
        if(res.statusCode==200){
          let data  = res.data;
          //console.log(data)
          if(data.status==0){
            resolve(data.result.ad_info)
          }else{
            resolve({})
          }
        }
      },fail:err=>{
        reject(res)
      }
    })

  })
}

export function getCardInfo(userId){
  return new Promise((resolve,reject)=>{
    viewCard({userId}).then(res=>{
     
      // let cardStatus = gbData('cardStatus');
      // let {jobUserCardGroupBo, jobUserCardPersonalBo} = res;

      // cardStatus.hasUser = empty(jobUserCardPersonalBo)? false : true;
      // cardStatus.hasGP = empty(jobUserCardGroupBo)? false : true;
        
      // localData('cardInfo',{jobUserCardGroupBo,jobUserCardPersonalBo})

      // gbData('cardStatus',cardStatus)
     // cardStatus
      resolve(res)
    }).catch(err=>{
      reject(err)
    })
  })
}
export function getRealCall(id,type){
  
  return new Promise((resolve,reject)=>{
    realPhone({id,type}).then(res=>{
      resolve(res)
    }).catch(err=>{
      resolve(err)
    })
  })
}
export function getRealWx(cardId){
  return new Promise((resolve,reject)=>{
    realWx({cardId}).then(res=>{
      resolve(res)
    }).catch(err=>{
      reject(err)
    })
  })
}

export function getUserInfo(id){
  return new Promise((resolve,reject)=>{
    userinfo({userId:id}).then(res=>{
      gbData('userInfo',res);
      localData('userInfo',res);
      
      resolve(res)
    }).catch(err=>{
      reject(err)
    })
  })
}

export function postComLog(param){
  return new Promise((resolve,reject)=>{
    commonlog(param).then(res=>{
        resolve(res)
    }).catch(err=>{
      console.log('任务查看提交err',err)
    })
  })
}
export function postShareLog(param){
  return new Promise((resolve,reject)=>{
    sharelog(param).then(res=>{
        resolve(res)
    }).catch(err=>{
      console.log('任务查看提交err',err)
    })
  })
}

export function getMetaData(dictType){
  return new Promise((resovle,reject)=>{
    original({dictType}).then(res=>{
      resovle(res)
    }).catch(err=>{
      resovle([])
      //reject(err)
    })
  })
}
export function formatDict(arr){
  arr = arr.map(r=>{
    return {
      name: r.dictLabel,
      value:r.dictValue,
      active: false
    }
  });
  return arr
}
//获取元数据
export function initMetaData(){
  return new Promise((resolve,reject)=>{
    let dictTypeListStr ='job_industry,job_benifit,work_year,card_group_total,report_type,company_scale,company_type,feedback_type';
    mydiscts({dictTypeListStr}).then(res=>{
      
      resolve(res)
     
    }).catch(err=>{
      reject(err)
    });
  })
}

export function msgInfo(){
  return new Promise((resolve,reject)=>{
    msgList().then(res=>{
      wx.stopPullDownRefresh();
      let data = res || [];
      if(empty(data)) return;
      let num = 0;
      data.map(item=>{
        // 0-名片投递；1-审核通知；2-谁看过我；3-培训通知；4-系统通知
        num+=item.msgCount;
        if(item.msgType==0) {
          item.typeName = '名片投递'
          item.icon = `/pages/assets/message/cardup.svg`
        }
        if(item.msgType==1) {
          item.typeName = '审核通知'
          item.icon = `/pages/assets/message/auditnotice.svg`
        }
        if(item.msgType==2) {
          item.typeName = '谁看过我'
          item.icon = `/pages/assets/message/wholookme.svg`
        }
        if(item.msgType==3) {
          item.typeName = '培训通知'
          item.icon = `/pages/assets/message/trainnotion.svg`
        }
        if(item.msgType==4) {
          item.typeName = '系统通知'
          item.icon = `/pages/assets/message/systemnotion.svg`
        }
        return item
      });
       
      resolve({data,unread:num})
       
    }).catch(err=>{
      wx.stopPullDownRefresh();
      reject(err)
    })
  })
}

export function checkCForEdit(type,id,content){
  return new Promise((resolve,reject)=>{
    textForEdit({fromType:type,fromRelationId:id,content}).then(res=>{
      let data = res;
      resolve(data);
    }).catch(err=>{
      reject(err)
    })
  })
}
export function checkImgForEdit(id,type,content){
  return new Promise((resolve,reject)=>{
    imgForUpdate({fromRelationId:id,fromType:type,content,}).then(res=>{
      let data = res;
      resolve(data);
    }).catch(err=>{
      reject(err)
    })
  })
}
