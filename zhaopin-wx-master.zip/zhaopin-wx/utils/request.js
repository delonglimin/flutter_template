import { throttle,debounce,msgToast } from './index'
class Request {
	constructor(parms) {
	  
	}
  get(url, data) {
		return this.request('GET', url, data)
	}
	post(url, data) {
		return this.request('POST', url, data)
	}
	put(url, data) {
		return this.request('PUT', url, data)
  }

  
	request(method, url, data) { 
    const whiteList = ["/jobUserCard/getPersonalList","/job/getJobList",
    "/login/getOpenId","/login/login1Key","/banner/getBannerList",
    "/job/getCompanyJob","/jobUserCard/getGroupList",'/job/getJobDetail',
    '/jobUserCard/getUserCardById','/agreement/getInfoById',
    '/dataDict/getListByList','/job/getCompanyJob','/job/getCompanyJobNumber','/dataDict/getRequestInCity'];

    let header = {'content-type':'application/json'},userId = wx.getStorageSync('userId') || '',token = wx.getStorageSync('token') || '';
    let idx = whiteList.findIndex(f=> f==url);
    if (idx <0) {
      if(!token){
        return  Promise.reject({
          msg: '需要登录验证',
          url: url,
        })
      } 
    }
    header['token'] = token;
    let timer = null,limitTimer=null,overTimer=null;

		return new Promise((resolve, reject)=>{
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      timer = setTimeout(()=>{
        wx.showLoading({title: '加载中',});
      }, 200)
      let queryParam = data;
			wx.request({
 
        url:`http://10.1.1.109:7003${url}`,
 
				data:queryParam,
 
				header,
				method,
        dataType: 'json',
        timeout:10000,
				responseType: 'text',
				success:(res)=>{
          
          let {statusCode, data} = res;
        
          if (statusCode == 200) {
            if(data.code== 200){
               resolve(data.data)
            }else{
              switch (data.code) {
                case 403:
                  msgToast('您没有权限','error',2000)
                  break;
                case 401:
                  if (overTimer) {
                    clearTimeout(overTimer);
                    overTimer = null;
                  }
                  overTimer = setTimeout(()=>{
                    wx.removeTabBarBadge({index: 3})
                    wx.clearStorageSync()
                    let loginUrl = '/pages/user/login/index?req=1';
                    if(url=='/job/getJobList'){
                  
                      if(queryParam.publisherUserType==1){
                        loginUrl+='&iscom=1';
                        console.log('企业')
                      }
                      
                    }
                    console.log('loginUrl',loginUrl);
                    wx.navigateTo({ url: loginUrl});
                  }, 100);
                  break;
                case 411:
                  if (limitTimer) {
                    clearTimeout(limitTimer);
                    limitTimer = null;
                  }
                  limitTimer = setTimeout(()=>{
                    wx.showModal({
                      title: '提示',
                      content: '账号因违规已冻结！',
                      confirmText:'确认',
                      showCancel:false,
                      success:res=>{
                        if (res.confirm) {
                          wx.removeTabBarBadge({index: 3})
                          wx.clearStorageSync()
                          wx.reLaunch({ url: '/pages/user/login/index'});
                        } else {
                          console.log('取消')
                        }
                      }
                    });
                  }, 100);
                  break;
                case 500:
                  reject(data)
                  if(url !='/user/ocrIdentifyCard'){
                    msgToast(data.msg,'none',2000)
                  }
                  break;
                case 208:
                  reject(data)
                  if(url !='/user/verifyIdNamePhone'){
                    msgToast(data.msg,'none',2000)
                  }
                  break;
                default:
                  reject(data)
                  msgToast(data.msg?data.msg:'系统网络异常','none',2000)
                  break;
              }
            }
          }else{
            msgToast('服务器出错','error')
          }
				},
				fail(e) {
          msgToast('系统网络异常','none',2000)
					reject({msg: '请求失败',url: url,method,data});
				},
        complete(){
          clearTimeout(timer);
          timer = null;

          wx.hideLoading();
        }
			})
		})
  }
}

export const request = new Request({})
