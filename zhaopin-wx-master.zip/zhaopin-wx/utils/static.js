export const mainMenu = [{
    title: '找零工',
    icon: './menu/m01@2x.svg',
    path: '/pages/shortterm/shortterm?type=0'
  },
  {
    title: '企业直聘',
    icon: './menu/m02@2x.svg',
    path: '/pages/shortterm/shortterm?publisherUserType=1'
  },
  {
    title: '培训',
    icon: './menu/m03@2x.svg',
    path: '/pages/training/training'
  },
  {
    title: '邀请注册',
    icon: './menu/m04@2x.svg',
    path: '/pages/user/shareout/index'
  },
  // {
  //   title: '建筑招工',
  //   icon: './menu/m05@2x.svg',
  //   path: '/pages/'
  // },
  // {
  //   title: '装修招工',
  //   icon: './menu/m06@2x.svg',
  //   path: '/pages/'
  // },
  // {
  //   title: '物流招工',
  //   icon: './menu/m07@2x.svg',
  //   path: '/pages/'
  // },
  // {
  //   title: '餐饮招工',
  //   icon: './menu/m08@2x.svg',
  //   path: '/pages/'
  // }
]
 
export const findJob = {
  menuTit: '我的找活',
  menuArr:[
    {icon: './icons/card.png',path: "/mycard/index",name:'我的名片'},
    {icon: './icons/post.png',path: "/comlist/index",name:'投递过'},
    {icon: './icons/fresh.png',path: "pages/findjob/findjob",name:'刷新名片'}
    // {icon: './icons/train.png',path: "/train/index",name:'我的培训'}
  ]
}
export const findworker = {
  menuTit: '我的招工',
  menuArr:[
    
    {icon: './icons/mail.png',path: "/recruit/add/index?type=0",name:'发布招工'},
    {icon: './icons/emp.png',path: "/recruit/index",name:'我的招工'},
    // {icon: './icons/radia.png',path: "/leida/index",name:'零工雷达'}
    {icon: './icons/build.png',path: "/ad/index",name:'企业入驻'},
  ]
}
export const scores = {
  menuTit: '积分活动',
  menuArr:[
    {icon: './icons/signd.png',path: "/signdate/index",name:'每日签到'},
    {icon: './icons/draw.png',path: "/lottery/index",name:'天天抽奖'},
    {icon: './icons/score.png',path: "/shop/index",name:'积分商城'},
    {icon: './icons/task.png',path: "/task/index",name:'每日任务'}, 
    {icon: './icons/addr.png',path: "/addr/index",name:'收货地址'},
  ]
}
export const moreServ = {
  menuTit: '更多服务',
  menuArr:[
    {icon: './icons/view.png',path: "/comlist/index",name:'谁看过我'},
    {icon: './icons/black.png',path: "/black/index",name:'黑名单'},
    {icon: './icons/serv.png',path: "/serv/index",name:'联系客服'},
    {icon: './icons/feed.png',path: "/feed/index",name:'意见反馈'}
  ]
}
