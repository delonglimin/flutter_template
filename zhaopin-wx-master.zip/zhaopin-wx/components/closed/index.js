Component({
  options: {
		styleIsolation: 'shared',
	},
  properties: {
    showClose:{
      type:Boolean,
      value:false
    },
    type:{
      type:Number,
      value:null
    }
  },
  data: {},
  attached(){},
 
  methods: {
    closeCom(){
      this.setData({showClose:false});
      wx.reLaunch({
        url: '/pages/index/index',
      })
      this.triggerEvent('close')
    },
    goHome(){
      wx.reLaunch({
        url: '/pages/index/index',
      })
    }
  }
})
