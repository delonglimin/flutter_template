import { localData,empty } from "../../utils/index"
import {doFresh,dayFresh} from '../../api/job'
Component({
  properties: {
    floatStatus:{
      type:Boolean,
      value:false
    },
    isSpecial:false
  },
  data: {
    btnTitle:'我要找活',
    isLogin:false,
    canPost:false
  },
  attached(){
   
    console.log('isSpecial',this.data.isSpecial)
    let isLogin = localData('token')? true :false,cardInfo = localData('cardInfo');
    let canPost = empty(cardInfo)? false: (!empty(cardInfo.jobUserCardGroupBo) || !empty(cardInfo.jobUserCardPersonalBo))?true:false;
    let btnTitle = this.data.btnTitle;
    if(this.data.isSpecial){
      btnTitle='我要招工';
    }else{
      (!isLogin || !canPost)?  btnTitle='我要找活' :  btnTitle='刷新名片';
    }
    this.setData({isLogin,canPost,btnTitle})
    console.log(this.data)
  },
  methods: {
    clickEvent(){
      let {isLogin,canPost,isSpecial}=this.data;
      if(!isLogin){
        this.triggerEvent('goLogin');
        return
      }
      if(isSpecial || !canPost){
        this.triggerEvent('goPost');
        return
      }
      this.triggerEvent('goFresh');
 
    },
    doFreshNum(){
      doFresh({}).then(res=>{
        console.log(res)
      })
    },
    initFreshNum(){
      dayFresh({}).then(res=>{
        console.log(res.freshNumber)
        
      })
    }
    
  }
})
