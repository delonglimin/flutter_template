Component({
  options: {
		styleIsolation: 'shared',
	},
  properties: {
    item:{
      type:Object,
      value:{}
    }
  },
  methods: {
    goList(){
      let info = this.data.item.userBo,{name,nickName,id} = info;
      let title = nickName ? nickName : name? name : ('技工0'+id);
      wx.navigateTo({
        url: `/pages/commonlist/index?id=${id}&name=${title}`,
      })
    },
    // 个人
    goCard(){
      
      let {majorPersonId} = this.data.item;
     
      //return
      wx.navigateTo({
        // &source=${source}
        url: `/pages/workerdetail/workerdetail?type=1&userid=${majorPersonId}&source=2&fromview=1`,
      })
    },
     // 班组
    goCardG(){
      let {majorPersonId} = this.data.item;
      wx.navigateTo({
        // &source=${source}
        url: `/pages/workerdetail/workerdetail?type=2&userid=${majorPersonId}&source=2&fromview=1`,
      })
    },
    goCompany(){
      let {majorPersonId} =this.data.item;
      this.triggerEvent('viewCom',{id:majorPersonId})
    },
    goPath(){
      let {majorPersonId,majorPersonName,viewAccountType} = this.data.item;
      let name = viewAccountType==1? majorPersonName : majorPersonName? majorPersonName: ('技工0'+majorPersonId);
      
    
     
      wx.navigateTo({
        url: `/pages/commonlist/index?id=${majorPersonId}&name=${name}&type=${viewAccountType}`,
      })
    }
  }
})
