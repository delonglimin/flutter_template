Component({
  options: {
		styleIsolation: 'shared',
	},
  properties: {
    item:{
      type:Object,
      value:{}
    }
  },
  data: {

  },
  methods: {
    goTask(){
      
      let {status,type} = this.data.item;
      if(status==1) return;
      this.triggerEvent('goTask',{type})
    }
  }
})
