// components/alertcell.js
Component({
 
  properties: {
    icon:{
      type:Boolean,
      value:true
    },
    title:{
      type:String,
      value:''
    },
    style:{
      type:String,
      value:''
    },
     
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
