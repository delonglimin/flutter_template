 
import { empty,localData,formatCity  } from '../../utils/index';
import {areaList} from '../../utils/citylist'
Component({ 
  options: {
		styleIsolation: 'shared',
	},
  properties:{
    showCity:{
      type:Boolean,
      value:false
    },
    activeId:{
      type:Array,
      value:[]
    },
    max:{
      type:Number,
      value:3
    }
  },
 
  data:{
    selceted:[],
    nameArr:[],
    listArr:[],
    
    activeIdx:0,
    cityActiveId:[]
  },
  lifetimes: {
    attached() {
       
    },
    detached(){
      
    }
  },
  observers:{
    'activeId,showCity'(ids,flag){
      this.setData({cityActiveId:ids})
      if(flag){
        let idArr = ids || [], listArr=[],selceted=[];
        
        listArr = formatCity(areaList,listArr,1,3);
        if(empty(idArr)){
          listArr.map((m,i)=>{
            m.num=0;
            m.idx=i;
            m.badge=null;
            m.children.map((son)=>{
              son.idx =i;
            });
          });
          this.setData({listArr,selceted:[]})
          return
        } 
         
        listArr.map((item,idx)=>{
          item.num=0;
          item.idx=idx;
          item.children.map((son,i)=>{
            son.idx =idx;
            let has = idArr.indexOf(son.id);
            if(has>-1){
              selceted.push(son)
              listArr[idx].num++;
              listArr[idx].num>0 ?  listArr[idx].badge = listArr[idx].num : listArr[idx].badge = null;
            }
          })
        }); 
        let arr = listArr.filter(f=>f.num>0)
        if(!empty(arr)){
          this.setData({activeIdx:arr[0].idx})
        }
        this.setData({ listArr,selceted });
      }
    }
  },
  methods:{
    backLeft(){
      this.setData({showCity:false})
    },
    clickNav({ detail = {} }) {
      
      this.setData({
        activeIdx: detail.index || 0,
      });
    },
   
    clickItem({ detail = {} }) {
      let { cityActiveId, listArr,selceted}=this.data;
      let {id,idx} = detail;
      
      console.log('detail',detail)
      const has = cityActiveId.indexOf(id);
      console.log('cityActiveId',cityActiveId,id,has)
      if (has > -1) {
        cityActiveId.splice(has, 1);
        selceted.splice(has, 1);
        listArr[idx].num--;
      } else {
        cityActiveId.push(id);
        selceted.push(detail);
        console.log('listArr[idx]',listArr[idx])
        listArr[idx].num++;
      }
      listArr[idx].num>0? listArr[idx].badge= listArr[idx].num : listArr[idx].badge= null;
      this.setData({ cityActiveId, listArr,selceted});
    },

    reset(){
      let { listArr }= this.data;
      listArr.map(m=>{
        m.num=0;
        m.badge=null;
      });
      this.setData({ cityActiveId:[], selceted:[],listArr,activeIdx:0});
    },
    //工种
    confirm(){
      let { selceted,cityActiveId } =this.data,nameStr='';
      
      nameStr = selceted.map(m=>{ return m.text }).toString().replace(/,/g, '、');
      console.log(nameStr,cityActiveId)
  
      this.triggerEvent('getCity',{cityList:cityActiveId, cityNameStr:nameStr})
      this.setData({showCity:false})
    }
  }
})