Component({
	data: {},
	options: {
		styleIsolation: 'shared',
	},
	properties: {
    hisTime:{
      type: String, value: {}
    },
    isHis:{
      type:Boolean,
      value:false
    },
    item: { type: Object, value: {} },
    source:{
      type:Number,
      value:1
    },
    isFav:{
      type:Boolean,
      value:false
    },
    index:{
      type:Number,
      value:0
    },
    relationId:{
      type:Number,
      value:null
    }
	},
	methods: {
    delete(){
      let {relationId,index} = this.data;
      
     this.triggerEvent('delete',{relationId,index,type:2})
    },
    goDetail(){
      let {id,userId} = this.data.item,{source}=this.data;
      wx.navigateTo({
        url: `/pages/workerdetail/workerdetail?id=${id}&type=1&userid=${userId}&source=${source}`,
      })
    }
  },
})
