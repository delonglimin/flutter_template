 Component({
  properties: {
    items:{type:Array,value:[]},
    selectedArr:{type:Array,value:[]},
  },
  data: {
    
  },
  observers:{
    'selectedArr'(data){
    
      if(data&&data.length){
        let items = this.data.items;
        items.map(m=>{
          let has = data.indexOf( m.value);
          if(has>-1){
            m.active=true;
          }
          return m
        })
        this.setData({items})
         
      }
    }
  },
  methods: {
    selcetItem(e){
      const { selectedArr } = this.data;
      let value = e.target.dataset.value;
      const index = selectedArr.indexOf(value);
      if (index > -1) {
        selectedArr.splice(index, 1);
       
      } else {
        selectedArr.push(value);
      }
      this.setData({ selectedArr });
      this.triggerEvent('change',selectedArr)

    }
  }
})
