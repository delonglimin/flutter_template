import { empty } from '../../utils/index'
Component({
  options: {
    styleIsolation: 'shared'
  },
  properties: {
    placeholder:{
      type:String,
      value:'',
    },
    disabled:{
      type:Boolean,
      value:false,
    },
    keytext:{
      type:String,
      value:'',
      observer:function(n,o,change){
        if(n){
          this.setData({isFocus:true,inputAlign: 'left'})
        }
      }
    }
  },
  data: {
    isFocus:false,
		inputAlign: 'center',
  },
  methods: {
    onChange(e) {
      this.setData({
        keytext: e.detail,
      })
      this.triggerEvent('inputVal',e.detail)
    },
    focusInput() {
      this.setData({ inputAlign: 'left', isFocus: true })
    },
    clearInput() {
      this.triggerEvent('clear')
      this.setData({ keytext: '', inputAlign: 'center', isFocus: false })
    },
    blurInput() {
      if (empty(this.data.keytext))
        this.setData({ inputAlign: 'center', isFocus: false })
    },
    goSearch(e) {
      let keytext = e.detail;
      this.triggerEvent('keyText', keytext)
    },
  }
})
