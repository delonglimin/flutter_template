Component({
	data: {
    avatar:'',
  },
	options: {
    multipleSlots: true,
		styleIsolation: 'shared',
	},
	properties: {
 
    item: { type: Object, value: {} },
    hisTime:{
      type: String, value: {}
    },
    source:{
      type:Number,
      value:1
    },
    isHis:{
      type:Boolean,
      value:false
    },
   
    showStatus:{
      type:Boolean,
      value:false
    },
    index:{
      type:Number,
      value:0
    },
    isFav:{
      type:Boolean,
      value:false
    },
    relationId:{
      type:Number,
      value:null
    }
	},
	attached(){
    let obj = this.data.item;
    if(obj.publisherUserType==1){
      this.setData({avatar: obj.companyBo && obj.companyBo.logo ?  `${obj.companyBo.logo}?x-oss-process=image/resize,m_fill,h_44,w_44` :'/pages/assets/avatar.gif'})
    }else{
      this.setData({avatar: obj.userBo && obj.userBo.avator ?  `${obj.userBo.avator}?x-oss-process=image/resize,m_fill,h_44,w_44` :'/pages/assets/avatar.gif'})
    }
	},
	methods: {
    // 职位取消收藏
    delete(){
      let {relationId,index} = this.data;
      this.triggerEvent('delete',{relationId,index,type:1})
    },
		goPath(e){
      let {publisherUserType,id} = this.data.item,{source}=this.data;
			let url = `/pages/shorttermdetail/shorttermdetail?id=${id}&type=${publisherUserType}&source=${source}`

			wx.navigateTo({
				url
			})
    },
    loadErr(e){
     this.setData({avatar:'../../pages/assets/avatar.gif'})
    }
	},
})
