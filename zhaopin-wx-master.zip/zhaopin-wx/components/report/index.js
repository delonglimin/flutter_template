import {
  report
} from '../../api/user'
import {
  localData,
  randomStr,
  empty,
  msgToast,
  debounce
} from '../../utils/index'
Component({
  properties: {
    showReport: {
      type: Boolean,
      value: false
    },

    params: {
      type: Object,
      value: {}
    }
  },
  data: {
    form: {
      reportType: null,
      fromPoint: 0,
      fromType: 0,
      fromRelationId: null,
      imgUrl: '',
      note: '',
      reportRelationType: 0,
      reportRelationId: null,
    },
    isFull: false,
    fileList: [],
    reportType: null,
    reportArr: localData('reportArr') || [],
  },

  methods: {
    setOnshow() {
      this.triggerEvent('setOnshow')
    },
    backLeft() {
      this.resetForm()
    },
    resetForm(){
      this.setData({
        showReport: false,
        isFull: false,
        fileList: [],
        reportType: null,
        form: {
          reportType: null,
          fromPoint: 0,
          fromType: 0,
          fromRelationId: null,
          imgUrl: '',
          note: '',
          reportRelationType: 0,
          reportRelationId: null,
        }
      });
    },
    inputChange: debounce(function (e) {

      this.setData({
        'form.note': e.detail
      })
    }),
    typeChange(e) {
      let type = Number(e.detail);

      this.setData({
        reportType: type
      })
    },

    beforeRead(e) {
      const {
        file,
        callback
      } = e.detail
      callback(file)
    },
    afterRead(e) {
      let filesArr = e.detail.file;
      let {
        fileList,
        form
      } = this.data;
      let arrStr = empty(form.imgUrl) ? [] : form.imgUrl.split(';');
      filesArr.map((item, index) => {
        item.name = 'reportimg' + new Date().getTime() + index + item.url.substr(-4)

        wx.uploadFile({
          url: `https://upload.eqianhuo.com/oss/file/upload`,
          filePath: item.url,
          name: 'file',
          // formData:postData,
          success: (res) => {
            let resdata = JSON.parse(res.data)
            let rst = resdata.data;

            if (rst.downloadUrl) {
              fileList.push({
                url: rst.downloadUrl,
                name: item.name,
              })
              arrStr.push(rst.downloadUrl);
              form.imgUrl = arrStr.join(';');
              this.setData({
                fileList,
                form
              });

            }
          },
        })
      })
    },

    async postReport() {

      let {
        form,
        params,
        reportType
      } = this.data;


      if (empty(reportType)) {
        msgToast('请选择举报类型，必选')
        return
      }
      if (empty(form.note)) {
        msgToast('请输入举报说明，必填')
        return
      }
     
      if (form.note.length < 15) {
        msgToast('举报说明限制15-300字')
        return
      }

      form.reportType = reportType;
      Object.assign(form, params);

      //0-失败 1-成功 -1：名片已下架 -2：职位已下线
      report(form).then(res => {
        let type = res;
        //1 职位  0 名片

        switch (type) {
          case 0:
            msgToast('举报失败', 'fail');
            break;
          case 1:
            msgToast('举报成功', 'success');
            break;
          case -1:
            msgToast('名片已关闭', 'error');
            break;
          case -2:
            msgToast('职位已下线', 'error');
            break;
        }
        this.resetForm()

      }).catch(err => {
        if(err.msg.indexOf('名片已关闭')){
          this.resetForm();
          this.triggerEvent('cardClose',1)
        }
      })
    }
  }
})