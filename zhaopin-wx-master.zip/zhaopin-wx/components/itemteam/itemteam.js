Component({
	data: {},
	options: {
		styleIsolation: 'shared',
	},
	properties: {
    hisTime:{
      type: String, value: {}
    },
    isHis:{
      type:Boolean,
      value:false
    },
    item: { type: Object, value: {} },
    source:{
      type:Number,
      value:1
    },
    index:{
      type:Number,
      value:0
    },
    isFav:{
      type:Boolean,
      value:false
    },
    relationId:{
      type:Number,
      value:null
    }
	},
	methods: {
    delete(){
      let {relationId,index} = this.data;
      console.log({relationId,index,type:3})
      this.triggerEvent('delete',{relationId,index,type:3})
    },
    goDetail(){
      let {id,userId} = this.data.item,{source}=this.data;
      wx.navigateTo({
        url: `/pages/workerdetail/workerdetail?id=${id}&type=2&userid=${userId}&source=${source}`,
      })
    }
  },
})
