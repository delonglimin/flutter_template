// components/usermenu.js
Component({
  properties: {
    menuData:{
      type:Object,
      value:{}
    }
  },
  data: {

  },
  methods: {
    toPath(e){
      let {item} = e.currentTarget.dataset;
     
      this.triggerEvent('goPath',item)
    }
  }
})