Component({
  options: {
		styleIsolation: 'shared',
	},
  properties: {
    item:{
      type:Object,
      value:{}
    },
    msgType:{
      type:Number,
      value:0
    }
  },
  methods: {
    goList(){
      let type = this.data.msgType,tabactive =null;
      if(type==1){
        tabactive= this.data.item.nowStatus==1?0:2;
        console.log(tabactive)
        // 0 1 2 3
        wx.navigateTo({
          url: `/pages/user/recruit/index?tabactive=${tabactive}`,
        })
        return
      }
      if(type==0){
        let {jobId} =this.data.item;
        wx.navigateTo({
          url: `/pages/user/recruit/comlist/index?type=0&id=${jobId}`,
        })
        return
      }
      if(type==4){
        // 系统     0个人名片 1班组名片  2 个人职位  3 公司职位 
        let {informContentId,informType} =this.data.item;
        if(informType==3){
          return
        }
        if(informType==2){
          wx.navigateTo({ 
            url: `/pages/user/recruit/add/index?id=${informContentId}&type=1`,
          })
          return
        }
        if(informType<2){
          wx.navigateTo({ 
            url: `/pages/user/mycard/index?&type=${informType}`,
          })
        }
         
      }
      
    }
  }
})
