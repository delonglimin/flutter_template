Component({
	data: {},
	options: {
    styleIsolation: 'shared',
	},
	properties: {
    item: { type: Object, value: {} },
    status: {
      type: Number,
      value:1
    },
    checkType:{
      type:Number,
      value:0 //0-待审核 1-审核成功 2-审核失败
    }
	},
	attached(){
    
	},
	methods: {
    goDetail(){
      if(this.data.checkType==1){
        let {id} = this.data.item;
        wx.navigateTo({
          url: `/pages/shorttermdetail/shorttermdetail?id=${id}`,
        })
      }
    },
		goPath(e){
			let {type,id} = this.data.item;
			let url =  type == 0 ? `/pages/shorttermdetail/shorttermdetail?id=${id}` : `/pages/shorttermdetailcom/shorttermdetailcom?id=${id}`;
			wx.navigateTo({
				url
			})
    },
    goPathCom(e){
      let {type,id} = e.currentTarget.dataset;
      wx.navigateTo({
        url: `/pages/user/recruit/comlist/index?id=${id}&type=${type}`,
      })
    },
    refresh(){
      let id =this.data.item.id;
      this.triggerEvent('refresh',id)
    },
    pause(){
      let id =this.data.item.id;
      this.triggerEvent('pause',id)
    },
    edite(){
      let id =this.data.item.id;
      this.triggerEvent('edite',id)
    },
    delIt(){
      let id =this.data.item.id;
      this.triggerEvent('delIt',{id,type:this.data.checkType})
    },
    startIt(){
      let id =this.data.item.id;
      this.triggerEvent('startIt',id)
    },
	},
})
