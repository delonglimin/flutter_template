 Component({
  properties: {
    items:{type:Array,value:[]},
    activeIdx:{type:Number,value:-1}
  },
  
  methods: {
    selcetItem(e){
      let index = e.target.dataset.index;
      let data = this.data.items[index];
      this.triggerEvent('change',{data,index})
    }
  }
})
