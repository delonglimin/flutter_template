import {localData} from '../../utils/index'

Component({
  data: {
    
  },
  properties: {
    mainMenu:{type:Array,value:[]},
    isTask:{
      type:Boolean,
      value:false
    }
  },
  methods: {
    goWhere(e){
      let {path,title} = e.currentTarget.dataset;
       
      
      if(!localData('token') && (path.indexOf('training')>-1 || path.indexOf('shareout')>-1)) {
        wx.navigateTo({
          url: '/pages/user/login/index?from=invite',
        })
        return
      }
     
      let flag = this.data.isTask===true? 1 : 0;
      wx.navigateTo({
        url: `${path}?title=${title}&isTask=${flag}`,
      })
    }
  }
})