Component({
  properties: {
    imgArr:{type:Array,value:[]},
    height:null
  },
  data: {
   
    indicatorDots:true,
    autoplay:true,
    interval:5000,
    duration:500
  },
  attached: function() {
   
  },
  /**
   * 组件的方法列表
   */
  methods: {
    getPath(e){
      let path = e.currentTarget.dataset.path;
      this.triggerEvent('goPath',path);
    }
  }
})
