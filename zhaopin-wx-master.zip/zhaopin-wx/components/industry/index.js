 
import { empty,localData  } from '../../utils/index';

Component({ 
  options: {
		styleIsolation: 'shared',
	},
  properties:{
    showIndus:{
      type:Boolean,
      value:false
    },
    activeId:{
      type:Array,
      value:[]
    }
  },
 
  data:{
   
    selceted:[],
    nameArr:[],
    listArr:[],
    max:3,
    activeIdx:0,
    indusActiveId:[]
  },
  lifetimes: {
    attached() {
       
    },
    detached(){
      
    }
  },
  observers:{
    'activeId,showIndus'(id,flag){
      this.setData({indusActiveId:id})
      if(flag){
        let idArr = id || [],selceted=[];
        let listArr = localData('indusData') || [];
       
        if(empty(idArr)){
          listArr && listArr.map(m=>{
            m.num=0;
            m.badge=null;
          })
          this.setData({selceted:[],listArr});
          return
        }
       
       // let lev1Idx =0;
        listArr.map((item,idx)=>{
          item.num=0;
          item.idx=idx;
         
          item.children && item.children.map(son=>{
        
            let has = idArr.indexOf(son.id);
            if(has>-1){
              selceted.push(son)
              let pidx = son.idx;
              listArr[pidx].num++;
              listArr[pidx].num>0 ? listArr[pidx].badge = listArr[pidx].num : listArr[pidx].badge = null;
            }
          })
        });
        let arr = listArr.filter(f=>f.num>0)
        
        if(!empty(arr)){
          this.setData({activeIdx:arr[0].idx})
        }
        
        this.setData({ listArr,selceted });
      }
    }
  },
  methods:{
    backLeft(){
      this.setData({showIndus:false})
    },
    clickNav({ detail = {} }) {
      
      this.setData({
        activeIdx: detail.index || 0,
      });
    },
    clickItem({ detail = {} }) {
      let { indusActiveId, listArr,selceted}=this.data;
      let {id,idx} = detail;
      
      const has = indusActiveId.indexOf(id);
      if (has > -1) {
        indusActiveId.splice(has, 1);
        selceted.splice(has, 1);
        listArr[idx].num--;
      } else {
        indusActiveId.push(id);
        selceted.push(detail);
        listArr[idx].num++;
      }
      listArr[idx].num>0? listArr[idx].badge= listArr[idx].num : listArr[idx].badge= null;
      this.setData({ indusActiveId, listArr,selceted});
    },
    reset(){
      let { listArr }= this.data;
      listArr.map(m=>{
        m.num=0;
        m.badge=null;
      })
      this.setData({ indusActiveId:[], selceted:[],listArr,activeIdx:0});
    },
    //工种
    confirm(){
      let { selceted } =this.data,nameStr='';
      console.log('selceted',selceted)
      nameStr = selceted.map(m=>{ return m.text }).toString().replace(/,/g, '、');
    
      this.triggerEvent('getIndus',{industryList:this.data.indusActiveId,insusNameStr:nameStr})
      this.setData({showIndus:false})
    }
  }
})