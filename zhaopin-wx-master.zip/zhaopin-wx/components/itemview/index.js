Component({
  options: {
		styleIsolation: 'shared',
	},
  properties: {
    item:{
      type:Object,
      value:{}
    }
  },
  methods: {
    goList(){
      let info = this.data.item.userBo,{name,nickName,id} = info;
      let title = nickName ? nickName : name? name : ('技工0'+id);
      wx.navigateTo({
        url: `/pages/commonlist/index?id=${id}&name=${title}`,
      })
    },
    // 个人
    goCard(){
      
      let {userBo} = this.data.item;
      let userid = userBo.id;
      //return
      wx.navigateTo({
        // &source=${source}
        url: `/pages/workerdetail/workerdetail?type=1&userid=${userid}&source=2&fromview=1`,
      })
    },
     // 班组
    goCardG(){
      let {userBo} = this.data.item;
      let userid = userBo.id;
      wx.navigateTo({
        // &source=${source}
        url: `/pages/workerdetail/workerdetail?type=2&userid=${userid}&source=2&fromview=1`,
      })
    },
    goCompany(){
      let {companyUserId} =this.data.item;
      this.triggerEvent('viewCom',{id:companyUserId})
    },
    goPath(){
      let {userId,userBo} = this.data.item;
      let name = userBo.nickName?userBo.nickName:userBo.name?userBo.name:('技工0'+userBo.id);
     console.log('userId',userId)
     
      wx.navigateTo({
        url: `/pages/commonlist/index?id=${userId}&name=${name}`,
      })
    }
  }
})
