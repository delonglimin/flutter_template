Component({
  options: {
		styleIsolation: 'shared',
	},
  properties: {
    showComp:{
      type:Boolean,
      value:false
    },
    comInfo:{
      type:Object,
      value:{}
    },
    jobArr:{
      type:Array,
      value:[]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
     
    openDesc:false
  },
  attached(){
   
  },
 
  methods: {
    closeCom(){
      this.setData({showComp:false})
      this.triggerEvent('close')
    },
    viewMore(){
      let flag = this.data.openDesc;
      this.setData({openDesc:!flag})
    },
   
  }
})
