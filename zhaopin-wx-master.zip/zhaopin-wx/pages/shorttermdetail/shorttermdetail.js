import {jobItem,callog,deliv,removeFav,addFav,commonlog,sharelog,comEmploy,comJobList,isReport,checkStatus} from '../../api/job'
import {addblack} from '../../api/user'
import {getRealCall} from '../../utils/getData'
import {gbData, localData, msgToast,loginCtrl,tidyBrBack,formatSalary,empty,getUrlParams} from '../../utils/index';
 
import Dialog from '@vant/weapp/dialog/dialog';
Page({
  data:{
    isClose:false,
    showClose:false,
    canPrev:false,
    reportParams:{},
    userNowLat:'',
    userNowLng:'',
    disabled:false,
    showShare:false,
    latitude: 23.099994,
    longitude: 113.324520,
    markers: [],
    info: {
      isFavorite:0
    },
    id:null,
    source:null,
    comInfo:{},
    showComp:false
  },
  onLoad(o){
    let pages = getCurrentPages();
    (pages[pages.length - 2])? this.setData({canPrev:true}) : this.setData({canPrev:false})
    
    if(o.q){
      const q = decodeURIComponent(o.q);
    //  console.log('扫码',q)
      let params = getUrlParams(q);
      if(params.id){
        this.getDetail(params.id,2);
        this.setData({id:params.id,source:2})
      }
      return
    }
    let {id} = o;
    let source = o.source>-1? o.source :2;
    this.setData({id,source})
    this.getDetail(id,source);

    
  },

  onReady(){
    this.mapCtx = wx.createMapContext('myMap')
  },
  onShareAppMessage(options){
    let {info,id,source} =this.data;
      this.addShareLog()
      return {
        title:'我在仟活发现了好岗位，快来看看吧',
        path: `/pages/shorttermdetail/shorttermdetail?id=${id}&source=${source}`,
        imageUrl:''
      }
  },
  onShareTimeline(){
    let {info,id,source} =this.data;
    this.addShareLog()
    return {
      title:'我在仟活发现了好岗位，快来看看吧',
      path: `id=${id}&source=${source}`,
      imageUrl:''
    }
  },
  backLeft(){
    if(this.data.canPrev){
     wx.navigateBack({//返回
       delta: 1
     })
    }else{
      wx.reLaunch({
        url: '/pages/index/index',
      })
    }
  },
  async reportItem(){  
    if(!loginCtrl(true)) return

    let {publisherUserId,id,publisherUserType,publisherCompanyId} =this.data.info,userId = localData('userId');
    if(publisherUserId==userId){
      this.setData({showShare:false})
      msgToast('不能举报自己','error')
      return
    }
    if(this.data.isClose){
      msgToast('职位已关闭，无法举报')
      this.setData({ showShare:false })
      return
    }
 

    let reFlag = await this.checkReport(id,1);
    if(reFlag==1){
      msgToast('您已举报过此职位')
      this.setData({showShare:false})
      return
    }
    let reportParams={
      fromPoint:0, //0-微信 1-企业端
      fromType:1, //0-名片 1-职位
      fromRelationId:id, //id
      reportRelationType: publisherUserType,  //被举报类型 0-微信用户 1-企业
      reportRelationId: publisherUserType==0?publisherUserId:publisherCompanyId //被举报人关联ID 个人ID或公司ID
    }
    this.setData({showReport:true,showShare:false,reportParams})
  },
  async setBlack(){
  
    if(!loginCtrl(true)) return
   
    let {publisherUserId,id} =this.data.info,userId = localData('userId');

    if(publisherUserId==userId){
      this.setData({showShare:false,})
      msgToast('不能拉黑自己','error')
      return
    }
  
   
    this.setData({showShare:false});
    
    Dialog.confirm({
      title: '拉黑此帐户',
      message: '拉黑后，您和对方将相互不可见',
      zIndex:10000
    }).then(() => {
      let {id,publisherUserType,publisherCompanyId} =this.data.info;
      let blackRelationId =  publisherUserType==1 ?publisherCompanyId: publisherUserId;
      
      addblack({fromPoint:0,fromType:1,fromRelationId:id,blackRelationType:publisherUserType,blackRelationId}).then(res=>{
        wx.navigateBack({
          delta: 1,
        })
      }).catch(err=>{
        console.log(err)
        if(err.msg && err.msg.indexOf('职位已关闭')>-1){
          wx.navigateBack({
            delta: 1,
          })
          this.setData({isClose:true});
        }
         
      })
    }).catch(err=>{
      console.log(err)
    })
    
  },
  addShareLog(){
    if(!loginCtrl()) return
    let userid = localData('userId');
    // shareType  0-分享职位 1-分享培训视频 2-其它.  shareContentId
    sharelog({userId:userid,shareType:0,shareContentId:this.data.id}).then(res=>{
   
      this.setData({showShare:false})
    }).finally(()=>{
      msgToast('分享职位成功','none',3000)
    })
  },
  shareItem(e){
    this.setData({showShare:false})
    if(this.data.isClose){
      msgToast('职位已关闭，无法分享')
      return
    }
    
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage','shareTimeline']
    })
  },
  closeCom(){
    this.setData({showComp:false})
  },
  goCompany(){
    this.setData({showComp:true})
  },


  // xiugai
  async takeCall(){
    if(!loginCtrl(true)) return
    let {info} = this.data;
    if(this.data.isClose){
      msgToast('职位已关闭，无法打电话');
      return
    }

    let telcall= await getRealCall(info.id,1)
    if(telcall.msg && telcall.msg.indexOf('职位已下架')>-1){
      msgToast('职位已关闭，无法打电话')
      this.setData({isClose:true})
      return
    }
    if(telcall){
      wx.makePhoneCall({
        phoneNumber:telcall,
        success:res=>{
          this.addCallLog(info.id,telcall)
        },
        fail:f=>{
          console.log('call fail')
        }
      })
    }
   
  },
 closeShareP(){
    this.setData({showShare:false})
  },
  // 投递
  async delivCardItem(){
    if(!loginCtrl(true)) return
    let {info} =this.data,userid = localData('userId');
    if(userid==info.publisherUserId && info.publisherUserType==0){
      msgToast('不能投递自己','error');
      return
    }
    if(info.isSendUserCard) return;
    if(this.data.isClose){
      msgToast('职位已关闭，无法投递')
      return
    }
 
    let {id} = info, {jobUserCardGroupBo, jobUserCardPersonalBo} = localData('cardInfo') || {};

    if(empty(jobUserCardGroupBo) && empty(jobUserCardPersonalBo)){
      wx.showModal({
        title: '提示',
        content:"请先发布名片才能进行投递哦！",
        success(res){
         
          if(res.confirm){
            
             wx.navigateTo({
               url: '../user/mycard/index?type=0',
             }) 
          }else{
            console.log('取消')
          }
        }
      });
      return
    }
    if(!empty(jobUserCardGroupBo) || !empty(jobUserCardPersonalBo)){
      let cardObj = jobUserCardGroupBo || jobUserCardPersonalBo;
      if(cardObj.status ==0){
        msgToast('个人名片未通过审核');
        return
      }
      
      deliv({userCardId:cardObj.id, jobId:id, userCardType:cardObj.cardType}).then(res=>{
        info.isSendUserCard=true;
        this.setData({info})
        msgToast('投递成功','success')
      }).catch(err=>{
        
        if(err.msg&&err.msg.indexOf('职位已关闭')>-1){
         msgToast('职位已关闭，无法投递')
         this.setData({ isClose:true})
        }
      })
    }
  },
  addCallLog(jobId,phone){
    callog({jobId,phone}).then(res=>{
     // console.log('call log',res)
    })
  },
  async collectItem(){
    if(!loginCtrl(true)) return;

    if(this.data.isClose){
      msgToast('职位已关闭');
    }
    let {info} = this.data,{id,isFavorite} =info;
 
    if(isFavorite){
      removeFav({type:1,relationId:id}).then(res=>{
        info.isFavorite = false;
        this.setData({info})
        msgToast('取消收藏成功');
      
      }).catch(err=>{
        console.log(err)
        if(err.msg&&err.msg.indexOf('职位已关闭')>-1){
         msgToast('取消收藏成功')
         this.setData({'info.isFavorite':false  })
        }
     })
      return
    }
    addFav({type:1,relationId:id}).then(res=>{
      //console.log('收藏',res)
      info.isFavorite = true;
      this.setData({info})
      msgToast('收藏成功');
     
    }).catch(err=>{
      console.log(err)
      if(err.msg&&err.msg.indexOf('职位已关闭')>-1){
       msgToast('收藏成功')
       this.setData({'info.isFavorite':true,isClose:true})
      }
   })
    
  },
  // commonlog
  upDateLog(jobId,pageIndex){
    let userId = localData('userId');
    let param ={
      userId,
      type:1,// 1职位 0名片
      jobId,
      userType:0,
      pageIndex,//来源  0-微信零工页面 1-微信感兴趣页面 2-其它
    }
    commonlog(param).then(res=>{
      //console.log('查看日志')
    })
  },
  setOnshow(){
    console.log('canOnShow')
    gbData('canOnShow',0)
  },
  getDetail(id,source){
    let {userNowLng,userNowLat} =this.data;
    jobItem({userNowLat,userNowLng,id}).then(res=>{
      let markers = [{
        id: 1,
        width: "20",  
        height: "30",  
        latitude: res.lat,
        longitude: res.lng,
        name: res.address
      }];
 
      if(res.companyUserBo && res.companyUserBo.tel){
        res.comBoTelMix = res.companyUserBo.tel.substr(0,3)+'********'
      }else{
        res.comBoTelMix='无电话'
      }

      if(res.publisherCompanyId){
        this.comEmployNum(res.publisherCompanyId);
        let comInfo = res.companyBo || '';
        if(comInfo.summary){
          comInfo.summary = tidyBrBack(comInfo.summary)
        }
        if(!empty(comInfo.welfares)){
          comInfo.welfares = comInfo.welfares.split(',')
        }
        // localData('comSArr') ||
        let comTArr=localData('comTArr') || [], comSArr= localData('comSArr') || [];
        let s = comSArr.findIndex(f=>f.value==comInfo.scale);
        let t = comTArr.findIndex(f=>f.value==comInfo.type);
        t > -1? comInfo.typeStr= comTArr[t].name : comInfo.typeStr='';
        s > -1? comInfo.scaleStr= comSArr[s].name : comInfo.scaleStr='';
       
        if(!empty(comInfo.descImgs)){
          let imgArr=[];
          if(comInfo.descImgs.indexOf(',')<0 && comInfo.descImgs.indexOf(';')<0){
            imgArr = [comInfo.descImgs];
          }else{
            if(comInfo.descImgs.indexOf(',')>-1){
              imgArr = comInfo.descImgs.split(',')
            }else{
              imgArr = comInfo.descImgs.split(';')
            }
          }
          comInfo.descImages = imgArr.map(p=>{
            return {
              url:p
            }
          })
        }else{
          comInfo.descImages=[]
        }
        
       
        // map
        comInfo.markers=[
          {
            id: 2,
            width: "20",  
            height: "30",  
            latitude: comInfo.lat,
            longitude: comInfo.lng,
            name: comInfo.address
          }
        ]
        this.loadComJobs(comInfo.id);

        this.setData({comInfo});
      }
      
      let {salaryType,salaryMax,salaryMin} =res;
       res.salary = formatSalary(salaryType,salaryMax,salaryMin,1);
      this.setData({info:res,markers})
      if(res.status==0){
        this.setData({isClose:true,showClose:true})
      }
        //查看日志
     
      if(loginCtrl()) { 
      
        let userId = localData('userId');
       
        if(res.publisherUserId != userId){
          //console.log('不是自己的')
          this.upDateLog(res.id,source)
        }
        
      }
     
    })
  },
 
  async openSharePanel(){
   // let isClose = await this.checkJobStatus(this.data.info.id);
   // this.setData({isClose});

    this.setData({showShare:true})
  },
  closePop(){
    this.setData({showShare:false})
  },
  comEmployNum(id){
    comEmploy({publisherCompanyId:id}).then(res=>{
      let num = res.number;
      this.setData({jobnum:num,'comInfo.jobnum':num})
       
    })
  },
  loadComJobs(id){
    comJobList({publisherCompanyId:id}).then(res=>{
     
      this.setData({comjobArr:res || []})
    })
  },
  checkReport(id,type){
    return new Promise((resolve,reject)=>{
      isReport({fromRelationId:id,fromType:type}).then(res=>{
        resolve(res)
      }).catch(err=>{
        reject()
      })
    })
  },
 
 
})