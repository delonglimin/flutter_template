import { signHis, signDay, sign3Day} from '../../../api/user'
import {msgToast,empty,gbData,localData, wxReport} from '../../../utils/index';
import { getMetaData} from '../../../utils/getData';
Page({

  data: {
    show:false,
    earnPoints:0,
    award3Arr: [],
    isSigned:false,
    nbsp: 0,
    date: 0,
    dateArr: [],
    month: 0,
    continuousDays: 0
  },

  onLoad() {
   
    this.getSignHis();
    this.getSign3Day();
    this.initDate();
    this.loadMsg()
  },
  initDate() {
    let balance = gbData('balance') ||0;
    let yuan = gbData('yuan') ||'';
    this.setData({balance,yuan});
    let mydate = new Date(),
      year = mydate.getFullYear(),
      month = mydate.getMonth() + 1,
      date = mydate.getDate(),
      day = mydate.getDay();

    let nbsp = 7 - ((date - day) % 7);
    let dateArr = [];
    for (let i = 1; i <= date; i++) {
      let obj = {
        active: false,
        date: i,
        now: false,
        disabled: true
      };
      if (i == date) {
        obj.now = true;
        obj.active = false;
        obj.disabled = false
      }
      dateArr.push(obj)
    }
    this.setData({
      nbsp,
      date,
      dateArr,
      year,
      month
    })
    let monthDaySize;
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
      monthDaySize = 31;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
      monthDaySize = 30;
    } else if (month == 2) {
      // 计算是否是闰年,如果是二月份则是29天
      if ((year - 2000) % 4 == 0) {
        monthDaySize = 29;
      } else {
        monthDaySize = 28;
      }
    };
    this.setData({
      monthDaySize
    })
  },
  // 签到
  goSign() {
    let arr = this.data.award3Arr.filter(f => f.today == true);
    if (arr) {
      let {earnPoints,  title,continuousDays } = arr[0];
      signDay({earnPoints, title,continuousDays}).then(res => {
        //console.log('signDay',res)
        let yuan = res.balenceStr;
        let {continuousDays} =this.data;
        continuousDays++;
        this.upDateToday();
        let data = localData('userInfo');
        // earnPoints-获得积分
        data.balance = Number(data.balance)+Number(earnPoints)
        this.setData({earnPoints})
     
        gbData('balance',data.balance)
        gbData('yuan',yuan)
        localData('userInfo',data)
        localData('yuan',yuan)
        this.setData({continuousDays,yuan,balance:data.balance,isSigned:true,show:true});

        setTimeout(()=>{
          this.setData({show:false})
        },2500)
       
       // msgToast('签到成功', 'success')
      })
    }
  },
  async loadMsg(){
    let list = await getMetaData('daily_sign_activity');
    let msgText ='';
    list.map(m=>{
      msgText += m.dictLabel
    })
    this.setData({msgText})
     
  },
  jumpath(e){
    let type = e.currentTarget.dataset.type;
    
    switch (type) {
      case 'score':
        wx.navigateTo({
          url: '../task/index',
          success:()=>{
            console.log('task')
            wxReport('signdate_task');
          }
        })
        break;
      case 'shop':
        wx.navigateTo({
          url: '../shop/index',
          success:()=>{
            console.log('signdate_shop')
            wxReport('signdate_shop');
          }
        })
        break;
      case 'draw':
        wx.navigateTo({
          url: '../lottery/index',
          success:()=>{
            wxReport('signdate_lottery')
          }
        })
        break;
    }
  },
  viewRule(){
    wx.navigateTo({
      url: '/pages/articaldetail/index?id=5',
    })
  },
  upDateToday() {
    let {
      dateArr
    } = this.data, tday = new Date().getDate();
    let idx = dateArr.findIndex(f => f.date == tday);
    if (idx > -1) {
      dateArr[idx].active = true;
      this.setData({
        dateArr
      })
    }
  },
  getSignHis() {
    signHis().then(res => {
      let arr = res || [], dateArr = this.data.dateArr,signed=[];

      if (empty(dateArr) || empty(arr)) return
      //已签到的
      arr.map(m=>{
        m.date = new Date(m.createTime).getDate();
        signed.push(m.date)
      });
     
      dateArr.map(d => {
        if(signed.indexOf(d.date)>-1){
         // console.log(d.date,signed,this.data.date)
          d.active = true;
          if(d.date == this.data.date){
            this.setData({isSigned:true})
          }else{
            this.setData({isSigned:false})
          }
        }
      });
      this.setData({ dateArr })
    })
    
  },
  getSign3Day() {
    sign3Day().then(res => {
      let data = res;
      
      if(empty(data.boList)) return
      
      data.boList.map((f,idx)=>{
        if(f.today==true){
          let continuousDays = f.continuousDays;
       
          if(f.todaySignedin){
            this.setData({isSigned:true,continuousDays});
          }else{
            this.setData({isSigned:false,continuousDays:continuousDays-1});
          }
        }
      });
      
   
      this.setData({
        award3Arr: data.boList,
        yuan:data.balenceStr,
        balance:data.balence
      });
      gbData('balance',data.balence);
      let userInfo = localData('userInfo');
      userInfo.balance = data.balence;
      localData('userInfo',userInfo)
    })
  },
  onReady() {

  },

  onShow() {

  },

  onHide() {

  },

  onUnload() {

  },

})