import {drawHis,drawDo,drawGoods, drawLuck,hasorder} from '../../../api/user'
import {gbData,localData, msgToast,empty,randomStr, wxReport } from '../../../utils/index'
import {orderUpdate } from '../../../api/base'
 

Page({
  data: {
    l_cur:0,
    secondDialog:false,
    balance:gbData('balance'),
    count: 0,
    formerOrder:{},
    hisArr:[],luckArr:[],
    query:{
      pageNum:1,
      pageSize:50
    },
    dhasMore:false,
    hasMore:false,
    loading:false,
    awardShow:false,
    dloading:false,
    hisShow:false,
    query2:{
      pageNum:1,
      pageSize:50
    },

    prize_arr: [],

    /*
     * 数组的长度就是最多所转的圈数，最后一圈会转到中奖后的位置
     * 数组里面的数字表示从一个奖品跳到另一个奖品所需要的时间
     * 数字越小速度越快
     * 想要修改圈数和速度的，更改数组个数和大小即可
     */
    num_interval_arr: [90, 80, 70, 60, 50, 50, 50, 100, 150, 250],
   
    order_arr: [0, 1, 2, 5, 8, 7, 6, 3],
    // 抽奖状态，是否转完了
    isTurnOver: true,
    // 是否需要复原，把没转完的圈转完
    isRecover: false,
    // 记录上一次抽奖后的奖品id
    prize_id_last: ''
  },
  onLoad() {
    wxReport('lottery');
    this.setData({type:2})
    this.initDraw()
    
    // 中奖记录
    this.getLuckList()
    //转盘记录
    this.getHisList()
  },
 
  onReady() {

  },
 
  onShow() {
    this.loadhasOrder();

    //收货地址返回选择
    let addrInfo={},{addrJumpInfo } =this.data;
    let adrArr = localData('adrArr') || [];
    if(!empty(adrArr)){
      if(addrJumpInfo&&addrJumpInfo.receiverPhone){
        addrInfo = addrJumpInfo
      }else{
        let defAdr = adrArr.filter(f=>f.status==1);
        addrInfo = defAdr[0];
      }
      this.setData({addrInfo,noShip:false})
    }else{
      this.setData({addrInfo:{},noShip:true})
    }

  },
  onReachBottom(){
 
    if(this.data.active==0){
      let {hasMore,loading,query} =this.data;
      if(!hasMore  || loading) return
      this.setData({loading:true})
      query.pageNum++;
      this.setData({query});
      this.getLuckList()
    }else{
      let {dhasMore,dloading,query2} =this.data;
      if(!dhasMore  || dloading) return
      this.setData({dloading:true})
      query2.pageNum++;
      this.setData({query2});
      this.getHisList()
    }
  },
 
  tabHisChange(e){
    let id =e.currentTarget.dataset.id;
    this.setData({l_cur:id})
  },
  async initDraw() {
    let {balance} = gbData('balance') || 0;
    let {integral,list} = await this.getGoods() || {};
    if(integral>-1) balance = integral;
    let count = Math.floor(balance/30);
    this.setData({balance,count});
    if(!empty(list)){
      list = list.map(m=>{
        return {
          id: m.id,
          imgUrl: m.goodsImgUrl ||'',
          isSelected: false,
          name: m.name,
          type: 'prize',
          classify:m.type
        }
      });
      list.splice(4,0,{ type:'btn',classify:'',id:randomStr(), isSelected: false,name:'按钮',imgUrl:''});
     
      let newlist = [];
      for(let i=0; i++; i<list.length){
        newlist.push(list[i]);
      }
      
      this.setData({prize_arr:newlist});
    }else{
      list = [];
      this.setData({prize_arr:[]});
    }

    
    this.setData({balance,count,prize_arr:list});
  },
  // 点击抽奖
  async clickPrize() {
    if(this.data.count==0){
      msgToast('可抽奖次数为0，无法继续抽奖');
      return
    }
    if (this.data.isTurnOver) {
      // 把抽奖状态改为未完成
      this.setData({
        isTurnOver: false
      })
      let data = await this.drawDoIt();
      let {id,orderId,name,type,userIntegral,createTime,goodsImgUrl} = data,
       {hisArr,luckArr}=this.data, 
       awardItem={},
       userInfo= localData('userInfo');

      if(empty(id)){
        msgToast('网络错误,稍后再试！','error')
        return
      }
      wxReport('lottery_clickdraw');
      this.setData({ prize_id: id,type});
      // 调用抽奖方法
      this.lottery(id);
     
      gbData('balance',userIntegral);
      
      userInfo.balance =userIntegral;
      localData('userInfo',userInfo);
      
      // 机会  积分
      let count = Math.floor(userIntegral/30);
      setTimeout(()=>{
        this.setData({balance:userIntegral,count})
      },8000) 

      //中奖记录
      if(type>0){
     
        setTimeout(()=>{
          this.setData({showAdr:true});
        },8000)

        this.setData({formerOrder:{goodsName:name,goodsImgUrl:goodsImgUrl,id:orderId}})
        createTime=createTime.substr(0,10).replace(/-/g,'.');

        awardItem = {
          userName:userInfo.nickName?userInfo.nickName:'技工0'+userInfo.id,
          userAvator:userInfo.avator,
          createTime:createTime, //贺磊说的一定有
          luckyItemName:name,
          status:0,
          id:randomStr(5)
        }
        if(type=1) {
          awardItem.status=2;
        }
        luckArr.unshift(awardItem)
        setTimeout(()=>{
          this.setData({luckArr})
        },8000)
      }else{
        setTimeout(()=> {
          wx.showModal({
            title: "很遗憾,并没有中奖",
            content: "再接再厉吧",
            showCancel: false
          })
        }, 8000);
      }
        
      //转盘记录
      let hisItem = {
        userName:userInfo.nickName?userInfo.nickName:userInfo.name,
        userAvator:userInfo.avator,
        expendIntegral:30,
        createTime:createTime,
        luckyItemName:name,
        id:randomStr(5),
      };
      hisArr.unshift(hisItem);
      setTimeout(()=>{
        this.setData({hisArr})
      },8000)
    } else {
      wx.showToast({
        title: '请勿重复点击',
        icon: 'none'
      })
    }
  },

  // 抽奖旋转动画方法
  async lottery(prize_id) {
    //console.log('中奖ID：' + prize_id)
    // 如果不是第一次抽奖，需要等待上一圈没跑完的次数跑完再执行
    this.recover().then(() => {
      let num_interval_arr = this.data.num_interval_arr;
      let order_arr = this.data.order_arr;
      // 旋转的总次数
      let sum_rotate = num_interval_arr.length;
      // 每一圈所需要的时间
      let interval = 0;
      num_interval_arr.forEach((delay, index) => {
        setTimeout(() => {
          // index+1
          this.rotateCircle(delay, index+1, sum_rotate, prize_id, order_arr);
        }, interval)
        //因为每一圈转完所用的时间是不一样的，所以要做一个叠加操作
        interval += delay * 8;
      })
    })
  },

  /*
   * 封装旋转一圈的动画函数，最后一圈可能不满一圈
   * delay:表示一个奖品跳到另一个奖品所需要的时间
   * index:表示执行到第几圈
   * sum_rotate：表示旋转的总圈数
   * prize_id：中奖后的id号
   * order_arr_pre：表示旋转这一圈的执行顺序
   */
  rotateCircle(delay, index, sum_rotate, prize_id, order_arr_pre) {

    // 页面奖品总数组
    let prize_arr = this.data.prize_arr;
    // 执行顺序数组
    let order_arr = []
    // 如果转到最后以前，把数组截取到奖品项的位置
    if (index == sum_rotate) {
      let idx = this.data.prize_arr.findIndex(f=>f.id==prize_id),
      prize_idx= order_arr_pre.findIndex(p=> p == idx)+1;
      // order_arr = order_arr_pre.slice(0, prize_id)
      order_arr = order_arr_pre.slice(0, prize_idx)

    } else {
      order_arr = order_arr_pre;
    }
    //console.log('结束arr',prize_id,order_arr,order_arr_pre)
    for (let i = 0; i < order_arr.length; i++) {
      setTimeout(() => {
        // 清理掉选中的转态
        prize_arr.forEach(e => {
          e.isSelected = false
        })
        // 执行到第几个就改变它的选中状态
        let curIdx = order_arr[i];
       
        prize_arr[curIdx].isSelected = true;
        // 更新状态
        this.setData({
          prize_arr: prize_arr
        })
        // 如果转到最后一圈且转完了，并且是非重置圈，把抽奖状态改为已经转完了
        if (index === sum_rotate && i === order_arr.length - 1 && !this.data.isRecover) {
          this.setData({
            isTurnOver: true,
            isRecover: true,
            prize_id_last: prize_id
          })
        }
      }, delay * i)
    }
  },

  // 复原，把上一次抽奖没跑完的次数跑完
  async recover() {
    if (this.data.isRecover) { // 判断是否需要重置操作
      let delay = this.data.num_interval_arr[0]; // 为了衔接流程，使用第一圈的转速
      // console.log(delay)
      let order_arr = this.data.order_arr;
      // console.log(order_arr)
      let prize_id_last = this.data.prize_id_last; // 上一次抽奖的id
      // console.log(prize_id_last)
      order_arr = order_arr.slice(prize_id_last); // 截取未跑完的格子数组
      // console.log(order_arr)
      return await new Promise(resolve => { 
        // 确保跑完后才去执行新的抽奖
        this.rotateCircle(delay, 1, 1, 8, order_arr); // 第一圈的速度，最多只有一圈，旋转一圈，跑到最后一个奖品为止，未跑完的数组
        setTimeout(() => { // 确保跑完后才告诉程序不用重置复原了
          this.setData({
            isRecover: false,
          })
          resolve() // 告诉程序Promise执行完了
        }, delay * order_arr.length)
      })
    }
  },
  loadhasOrder(){
    let ignoreLottery = localData('ignoreLottery');
    console.log( ignoreLottery !=1)
    hasorder({orderFrom:1}).then(res=>{
      let {unHandleOrderFlag} = res;
      this.setData({formerOrder:res});
      if(unHandleOrderFlag && ignoreLottery !=1){
        this.setData({showAdr:true});
      }
    })
  },
  closeDialog(){
    this.setData({showAdr:false});
    let ignoreLottery = localData('ignoreLottery');
    if(ignoreLottery !=1){
      this.setData({secondDialog:true})
      localData('ignoreLottery',1);
      return
    }
    this.setData({secondDialog:false})
    
  },
  //商品列表
  getGoods() {
    return new Promise((resolve, reject) => {
      drawGoods().then(res => {
        resolve(res)
      });
    })
  },
 
  viewRule(){
    wx.navigateTo({
      url: '/pages/articaldetail/index?id=4',
    })
  },
  toOrders(){
    wx.navigateTo({
      url: '/pages/user/orders/index',
    })
  },
  addNewAdr(){
		let {noShip,addrInfo} = this.data;
    console.log(noShip,addrInfo)
     
    let id = noShip?-1: addrInfo.id;
		wx.navigateTo({
      url: '../addr/index?isorder=1&id='+id,
		});
  },
  confirmAdr(){
    if(this.data.type ==1){
      this.setData({showAdr:false})
      return
    }
    let {receiver,receiverPhone,receiveAddress,addressCode,detailAddress,postalcode} = this.data.addrInfo;
    let userId = localData('userId'),id = this.data.formerOrder.id;
   // console.log({receiver,receiverPhone,receiveAddress,addressCode,detailAddress,postalcode,id,userId})
 
    orderUpdate({receiver,receiverPhone,receiveAddress,addressCode,detailAddress,postalcode,id,userId}).then(res=>{
       wxReport('lottery_clickconfirm');
      this.setData({addrJumpInfo:{}});
      let adrArr = localData('adrArr') || [],addrInfo={};
      if(!empty(adrArr)){
        let defAdr = adrArr.filter(f=>f.status==1);
        addrInfo = defAdr[0];
        this.setData({noShip:false,addrInfo});
      }else{
        this.setData({noShip:true,addrInfo:{}});
      }
     
      msgToast('提交成功');
      this.setData({showAdr:false})
    })
    
  },
  getLuckList() {
    let query =this.data.query;
    drawLuck(query).then(res => {
      this.setData({loading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query.pageNum==1){
        this.setData({luckArr:rows});
        if(rows.length==total){
          total==0? this.setData({awardShow:false}): this.setData({awardShow:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({hasMore:false,awardShow:true});
          return
        }
        this.setData({luckArr:this.data.luckArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.luckArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,awardShow:true})
      }
    })
  },
  getHisList() {
    let query2 =this.data.query2;
    drawHis(query2).then(res => {
     
      this.setData({dloading:false})
      let {total,rows} =res;
      rows = rows || [];

      if(query2.pageNum==1){
        rows.map(m=>{
          m.createTime =  m.createTime.substr(0,10).replace(/-/g,'.')
        })
       


        this.setData({hisArr:rows});
        if(rows.length==total){
          total==0? this.setData({hisShow:false}): this.setData({hisShow:true})
          this.setData({dhasMore:false})
          return
        }
      }
      if(query2.pageNum>1){
        if(empty(rows)){
          this.setData({dhasMore:false,hisShow:true});
          return
        }
        this.setData({hisArr:this.data.hisArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.hisArr.length;
        len<total ? this.setData({dhasMore:true}): this.setData({dhasMore:false,hisShow:true})
      }
    }).catch(err=>{
      this.setData({dloading:false})
    })
  },
  toTask(){
    wx.navigateTo({
      url: '../task/index',
      success:()=>{
        wxReport('lottery_task')
      }
    })
  },
  drawDoIt() {
    return new Promise((resolve,reject)=>{
      let userId = localData('userId')
      drawDo({userId}).then(res => {
        resolve(res)
      })
    })
  }
})