import {empty, localData, msgToast } from '../../../utils/index'
import {initMetaData,formatDict } from '../../../utils/getData'
import {addFeed} from '../../../api/user'
Page({
  data:{
    feedTypeArr:[],
    curType:null,
    feedform:{
      type:null,
      content:'',
 
    }
  },
  onLoad(){
    this.initMeta()
  },
  initMeta(){
   
    let feedType=localData('feedType');
    if(empty(feedType)){
        this.reloadIndus()
    }else{
      this.setData({feedTypeArr:feedType});
    }
  },
  async reloadIndus(){
    let {feedback_type} = await initMetaData();
    if(!empty(feedback_type)){
      let feedType = formatDict(feedback_type);
      this.setData({feedTypeArr:feedType});
      localData('feedType',feedType)
    }
  },
  typeCahnge(e){
    if(this.data.loading) return
    let type = e.currentTarget.dataset.id;
    console.log(type)
    this.setData({curType:type,'feedform.type':type})
  },
  getInputVal(v){
   
    this.setData({'feedform.content':v.detail})
  },
  submitFeed(){
    let {feedform} =this.data;
 //   let userinfo= localData('userInfo');
 //   feedform.phone=userinfo.tel;
    if(empty(feedform.type)){
      msgToast('请选择反馈类型')
      return
    }
    if(empty(feedform.content)){
      msgToast('请填写反馈内容')
      return
    }
    
    if(feedform.content.length < 15){
      msgToast('意见反馈不少于15字')
      return
    }
    this.setData({loading:true})
    addFeed(feedform).then(res=>{
      this.setData({loading:false})
      msgToast('提交成功','success',1500);
      setTimeout(()=>{
        wx.navigateBack({
          delta: 1
        });
      },1500)
      
    }).catch(err=>{
      this.setData({loading:false})
    })
    
  }
})