import {getOcrInfo,postRealNameInfo} from '../../../api/user';
import {msgToast,isCardID,localData,gbData,formatIdCard,empty, wxReport} from '../../../utils/index';
import {upDateUserInfo} from '../../../utils/getData'
 
Page({
  data: {
    show:false,
    firstP:true,
    name: '',
    cardId: '',
    card1: '',
    card2: '',
    
  },
  onLoad(options) {
    wxReport("realname")
    this.eventType()
  },
  setOnshow(){
    gbData('canOnShow',0)
  },
  eventType(){
    let pages = getCurrentPages();
    if(pages.length>=2){
      let {route}  = (pages[pages.length-2]);
      console.log(route);
      if(route.indexOf('user/user')>-1){
        wxReport('user_realname')
        return
      }
      if(route.indexOf('findjob')>-1){
        console.log('findjob');
        wxReport('findjob_realname')
        return
      }
      if(route.indexOf('findworker')>-1){
        console.log('findworker');
        wxReport('findworker_realname')
        return
      }
      if(route.indexOf('recruit')>-1){
        console.log('recruit');
        wxReport('finrecruit_realname')
       
        return
      }
      if(route.indexOf('task')>-1){
        console.log('task');
        wxReport('task_realname')
        return
      }

      
       
    }
  },
  afterRead(event) {
    const { file,  name } = event.detail;
    wx.showLoading()
    wx.uploadFile({
      url: `https://fjmp.yuchangchina.com/prod/hkzx-file/file/upload`,
      filePath: file.url,
      name: 'file',
      success: (res) => {
        wx.hideLoading()
        let fileResult = JSON.parse(res.data)
        if (name == 1) {
          getOcrInfo({
            idCardUrl: fileResult.downloadUrl,
            type:name
          }).then((res) => {
            if (res.type != 1) {
              msgToast('请上传个人信息页面','none', 3000)
              return
            }
            wxReport('realname_uploadpersonalinformation');
            this.setData({
              card1: fileResult.downloadUrl,
              name: res.name,
              cardId: res.idNumber
            });
          }).catch(err=>{
            
            this.setData({show:true,errtext:err.msg})
          })
        } else {
          getOcrInfo({
            idCardUrl: fileResult.downloadUrl,
            type:name
          }).then((res) => {
            if (res.type != 2) {
              msgToast('请上传国徽面','none', 3000)
              return
            }
            wxReport('realname_uploadnationalemblem');
            this.setData({
              card2: fileResult.downloadUrl
            });
          }).catch(err=>{
            this.setData({show:true,errtext:err.msg})
          })
        }
      },
      fail: err => {
        wx.hideLoading()
         msgToast(err,'none',3000)
        
      }
    })
  },
  initInfo(idnum){
    let selfInfo={
      avator: "",
      nickName: "",
      openid: "",
      tel: ""
    },userInfo = localData('userInfo');
    for(let key in userInfo){
      if(selfInfo.hasOwnProperty(key)){
        selfInfo[key]=userInfo[key];
        if(key =='gender'){
          selfInfo.gender = userInfo[key]+''
        }
      }
    };
    
    let card = formatIdCard(idnum);
    selfInfo= Object.assign(selfInfo,card);
   
    return selfInfo
     
  },
  // 点击开始进行认证
  subAuth() {
    let {name,cardId,card1,card2} = this.data;
    if (empty(card1)) {
      this.setData({show:true,errtext:'请上传个人信息面'})
      return;
    }
    
    if (!isCardID(cardId)) {
      this.setData({show:true,errtext:'身份证读取异常,请重新上传'})
      return
    }
    let selfInfo = this.initInfo(cardId);
   
    postRealNameInfo({
      name,
      idCardNo:cardId,
      idCardFaceUrl:card1,
      idCardBackUrl:card2
    }).then(async(res) => {
      msgToast('实名认证成功');
     
      wxReport('realname_clickconfirm');
      let userInfo = localData('userInfo');
      userInfo.verifyStatus = 1;
      userInfo.birthday=selfInfo.birthday;
      userInfo.birthdayTs= new Date(selfInfo.birthday).getTime();
      userInfo.name = name;
      userInfo.gender = selfInfo.gender = selfInfo.sex;
      delete selfInfo.sex;
    
      gbData('realName',true);
      localData('userInfo', userInfo);
       
      await upDateUserInfo(selfInfo);

      wx.navigateBack()
    }).catch(err=>{
      this.setData({show:true,errtext:err.msg})
      this.setData({firstP:false})
    }).finally(f=>{
      
    })
  }
})