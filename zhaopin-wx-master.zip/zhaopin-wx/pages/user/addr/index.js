// pages/user/addr/index.js
import { msgToast,empty, localData, wxReport } from '../../../utils/index';
import { areaList  } from '../../../utils/citylist';
import {adrList,adrAdd,adrDel,editAdr} from '../../../api/user'
import Dialog from '@vant/weapp/dialog/dialog';
Page({
  data: {
    formOrder:false,
    isEdit:false,
    show:false,
    listArr:[],
    showArea:false,
    addrCheck:'',
    areaList,
    form:{
      receiver:'',receiverPhone:'',receiveAddress:'',detailAddress:'',addressCode:''
    },
    areaVal:'',
    curUseIdx:-1,
    showDel:false,
  },
 
  onLoad(options) {
    wxReport('addr')
    this.initReginArr();
    let {add,isorder,id} =options;
    
    if(isorder==1){
      console.log('onload订单',id)
      this.setData({formOrder:true})
      if(id>-1){
        this.getList(id);
      }else{
        this.getList()
      }
    }else{
    
      this.getList()
    }
    if(add && add==1){
      this.setData({show:true})
    }
  },
  onShow() {},
  backpage(){
    wx.navigateBack({
      delta: 1,
    })
  },
  onClickLeft(){
    this.setData({show:false});
    
  },
  onChange(e){
    let val = e.detail, id = e.currentTarget.dataset.id,{form}=this.data;
    if(id=='receiver'){
      if(val.length==20){
        console.log('到上限了')
      }
    }
    form[id]=val;
    
    this.setData({form})
  },
  openShow(){
    let {form}= this.data;
    for(let key in form){
      form[key]=''
    }
    this.setData({form})
    wxReport('addr_clickadd')
    this.setData({show:true,isEdit:false,form})
    
  },
  openArea(){
    if(!this.data.form.receiveAddress){
      this.setData({areaVal:''})
    }
    this.setData({showArea:true})
  },
  useIt(e){
    let {item,idx} = e.currentTarget.dataset;
    var pages = getCurrentPages(),prevPage = pages[pages.length - 2];  // 上一个页面
    
    this.setData({curUseIdx:idx})
    prevPage.setData({
      addrJumpInfo:{
        id:item.id,
        receiver:item.receiver,
        receiverPhone:item.receiverPhone,
        receiveAddress:item.receiveAddress,
        detailAddress:item.detailAddress,
      }
    });
    wx.navigateBack({delta: 1})
  },
 
 
  cancelArea(){
    this.setData({showArea:false})
  },
  saveNewAddr(){
    const phoneReg = /^1(3|4|5|6|7|8|9)\d{9}$/;
    let { receiver,receiverPhone,receiveAddress,detailAddress} =this.data.form;
    
    if(empty(receiver)){
      msgToast('收货人不能为空','none',2000)
      return
    }
    if(receiver.length<2){
      msgToast('收货人姓名不少于2个字','none',2000)
      return
    }
    if(empty(receiverPhone)){
      msgToast('联系电话不能为空','none',2000)
      return
    }
   
    if(!phoneReg.test(receiverPhone)){
      msgToast('联系电话不规范','none',2000)
      return
    }
    if(empty(receiveAddress)){
      msgToast('所在地址不能为空','none',2000)
      return
    }
    if(empty(detailAddress)){
      msgToast('详细地址不能为空','none',2000)
      return
    }
    if(detailAddress.length<4){
      msgToast('详细地址不少于4个字','none',2000)
      return
    }
    if(this.data.isEdit){
      editAdr({...this.data.form}).then(res=>{
        // editIdx
        wxReport('addr_clicksave');
        let {listArr,editIdx} = this.data;
        listArr[editIdx] = this.data.form;
        this.setData({show:false, listArr});
        localData('adrArr',listArr)
        msgToast('修改成功')
      })
    }else{
      console.log('新增状态')
      let {listArr,form} = this.data;
      // 默认判断
      empty(listArr) ? form.status=1: form.status=0;
     
      adrAdd(form).then(res=>{
        wxReport('addr_clicksave');
        this.setData({show:false});
        this.getList()
      });
    }
  },
  getList(fromId){
    adrList().then(res=>{
      let list = empty(res)? [] : res;
      if(list.length>0){
        list.map((m,i)=>{
          if(m.status==1){
            this.setData({addrCheck:i})
          }
        });
        if(fromId){
          let hasIdx = list.findIndex(f=>f.id==fromId);
          console.log('订单id',fromId,hasIdx);
          if(hasIdx>-1){
            this.setData({curUseIdx:hasIdx})
          }
        }
      } 
    
      localData('adrArr',list)
      this.setData({listArr:list})
    })
  },
  adrChange(e){
    
    let index = e.detail,{listArr,addrCheck} = this.data;
   
    if(index == addrCheck){
      return
    }
    let data = listArr[index];
    data.status=1;
    editAdr(data).then(res=>{
      listArr = listArr.map(m=>{
        m.status=0;
        return m
      });
     // console.log(listArr,listArr[index])
      listArr[index].status=1;
      this.setData({listArr,addrCheck:index})
      localData('adrArr',listArr)
      msgToast('修改成功')
    }).catch(err=>{

    })
  },
  // 编辑
  editItem(e){
    let {listArr} =this.data;
    let idx = e.currentTarget.dataset.idx;
    let form = listArr[idx];
    
    this.setData({show:true,form,areaVal:form.addressCode,isEdit:true,showArea:false,editIdx:idx});
  },
  delItem(e){
    let id = e.currentTarget.id;
    this.setData({showDel:true,targetId:id})
  },
  cancelDel(){
    this.setData({showDel:false,targetId:null})
  },
  confirmdelItem(){
    let {listArr,targetId} =this.data;
    
    adrDel({id:targetId}).then(res=>{
      let idx = listArr.findIndex(f=>f.id == targetId);
      listArr.splice(idx,1);
      this.setData({listArr});
      localData('adrArr',listArr)
      msgToast('删除成功','success')
    }).catch(err=>{

    }).finally(f=>{
      this.setData({showDel:false})
    });
  },
  initReginArr(){
    let {areaList} = this.data, province_list={},city_list={},county_list={};
    areaList.map(lv1=>{
      province_list[lv1.code] = lv1.name;
      if(lv1.children){
        lv1.children.map(lv2=>{
          city_list[lv2.code] = lv2.name;
          if(lv2.children){
            lv2.children.map(lv3=>{
              county_list[lv3.code] = lv3.name
            })
          }
        });
      }
    });
    this.setData({areaListArr:{province_list,city_list,county_list}})
  },
 
  confirmArea({detail={}}){
    
    let {index,values} = detail,{ form} = this.data;

    let white = ['710000','810000','820000'];
    let areaVal ='';
    if(white.indexOf(values[0].code)<0){
      if(index[2]==0){
        wx.showToast({
          icon:'none',
          title: '收货地址选择必须到区/县',
        })
        return
      }
      areaVal = form.addressCode = values[2].code;
      form.receiveAddress = values[0].name+values[1].name+values[2].name;
    }else{
      areaVal = form.addressCode = values[1].code;
      form.receiveAddress = values[0].name+values[1].name;
    }
    
    this.setData({showArea:false,form,areaVal})
  },
  cancelArea(){ 
    this.setData({showArea:false,areaVal:''})
  }

})