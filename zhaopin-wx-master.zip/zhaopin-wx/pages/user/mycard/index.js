import {localData,empty,msgToast,gbData,debounce,sumAge, wxReport,backLeft} from '../../../utils/index'
import { addCard,editCard, addGpCard,editGpCard,delImg } from '../../../api/user.js'
import { checkCForEdit,checkImgForEdit,getMetaData,formatDict,initMetaData} from '../../../utils/getData'
 
import {getCardInfo} from '../../../utils/getData';
import Dialog from '@vant/weapp/dialog/dialog';
import { imgForUpdate } from '../../../api/base';

 
Page({
	data: {
    key_height:0,
    postErrShow:false,
    ErrInfo:{
      imgErrShow:false,
      msgErrShow:false,
      msgErr:'',
      imgErr:''
    },
    selfErrImg:'',
    teamErrImg:'',
    showPicker:false,
    actions:[],
    workYear:'',
		isEdit: true, // 编辑状态
    
    tabActive: -1,
    hasGP:false,
    hasUser:false,
    realname:false,
    autosize:{
      maxHeight: 100, minHeight: 50 
    },
		cardForm: {
      userId: localData('userId'),
     
			cardType: 0,
			contactPhone:'',
			cardWxNumber: '',
      cardName: '', //名片名，默认调姓名
      cityLabelList:'',
      certificateUrl: '',
      industryLabelList:'',
			note: '',
			sex: 0,
			age: null,
			workDate: null,
			cityList: [],
      industryList: [],
      status:null,
      secVerifyStatus:null
    },
    
    workCity: '', //期望城市
    userJobStr: '', //工种文字
		fileList: [], //图片预览-个人
    
    cityActiveId:[],
    indusActiveId:[],
    emptyShow:false,
    loading:false,
    fromFresh:false,
	},

	onLoad(o) {
    wxReport('mycard');
   
    if(o.type) this.setData({tabActive:o.type});
    
    let fixTopHeight = gbData('titleBarHeight') + gbData('statusBarHeight');
    this.setData({fixTopHeight});
	},
  onShow(){
    if(this.data.fromFresh){
      this.setData({fromFresh:false})
      return
    }
    this.syncCards();
  },

  onPullDownRefresh(){
    this.syncCards()
  },
  backLeft,
  syncCards(){
    let id =localData('userId');
    getCardInfo(id).then(info=>{
      wx.stopPullDownRefresh()
      if(!empty(info)){
        localData('cardInfo',info)
        // 更新存储
        this.initCard()
      }
    });
  },
  closePop(){
    this.setData({
      postErrShow:false,
      ErrInfo:{
        imgErrShow:false,
        msgErrShow:false,
        msgErr:'',
        imgErr:''
      }
    })
  },
  // 获取返回的工种
  getIndusArr({detail={}}){
    let {industryList,insusNameStr} = detail;
   
    this.setData({ 'cardForm.industryList':industryList, userJobStr: insusNameStr})
    
  },
  getCityArr({detail={}}){
    let {cityNameStr,cityList} = detail;
    this.setData({ 'cardForm.cityList':cityList, workCity: cityNameStr})
  },
  setOnshow(){
   // let {isEdit,loading} =this.data;
   // if(!isEdit || loading) return
     this.setData({fromFresh:true})
    gbData('canOnShow',0)
  },
  setOnshow2(){
    this.setData({fromFresh:true})
    gbData('canOnShow',0)
  },
  openPicker(){
    if(this.data.loading) return
    if(empty(this.data.yearArr)){
      this.setData({emptyShow:true})
      return
    }
    this.setData({showPicker:true})
  },
  initCard(){
    this.setData({loading:false})
    let indusData=localData('indusData'),yearArr=localData('yearArr');
    // 判断有无元数据缓存
     (empty(indusData) || empty(yearArr)) ? this.reloadIndus() : this.setData({yearArr,emptyShow:false});
   
    
    let userinfo = localData('userInfo') || {},
    {cardForm} = this.data,
    realname =userinfo.verifyStatus==1?true:false;
    this.setData({realname});
    
   

    //名片缓存信息
    let {jobUserCardGroupBo,jobUserCardPersonalBo} = localData('cardInfo');
    let hasUser = empty(jobUserCardPersonalBo)? false :true;
    let hasGP = empty(jobUserCardGroupBo)? false :true; 
    gbData('cardStatus',{hasGP,hasUser});
    this.setData({hasGP,hasUser});

    if(!hasUser && !hasGP){
      // 两种名片都没有
      // 表单-信息初始化
      cardForm.cardType = 0; //默认-个人
      cardForm.userId = userinfo.id;
      cardForm.contactPhone = userinfo.tel;
      cardForm.sex = userinfo.gender;
      if(realname){
        //实名-调用个人信息的年龄，刷新缓存
        cardForm.age = sumAge(userinfo.birthdayTs);
      }else{
        cardForm.age = null;
      }
      
      cardForm.cardName= realname? userinfo.name : (userinfo.name?userinfo.name:userinfo.nickName?userinfo.nickName: `技工0${userinfo.id}`);

      this.setData({cardForm,isEdit:true})
    }else{
     
      this.setData({isEdit:false});
     
      // 兼容旧数据  两种名片同时存在 或  只有个人名片 
      if(hasUser){
        cardForm = this.formatCard(jobUserCardPersonalBo, cardForm);
        cardForm.id= jobUserCardPersonalBo.id;
      }else{
        // 只有班组
        cardForm = this.formatCard(jobUserCardGroupBo, cardForm);
        cardForm.groupName = jobUserCardGroupBo.groupName;
        cardForm.totalNumber = jobUserCardGroupBo.totalNumber;
        cardForm.id= jobUserCardGroupBo.id;
      }

      // 
      if(realname){
        //实名-调用个人信息的年龄，刷新缓存
        cardForm.age = sumAge(userinfo.birthdayTs);
        console.log(cardForm.age)
        cardForm.sex = userinfo.gender;
        cardForm.cardName=userinfo.name;
      }
 
  
      let{cityLabelList,industryLabelList,certificateUrl,id,workDate} =cardForm,fileList=[];
      cardForm.id=id; //编辑状态下  需要名片ID
    
      if(!empty(certificateUrl)){
        certificateUrl = certificateUrl.split(';');
        fileList = certificateUrl.map(p=>{
          return {url:p}
        });
      }
      if(!empty(cardForm.note)){
        cardForm.note = cardForm.note.replace(/<br>/g,'').replace(/(\n\r|\r\n|\r|\n|\n\n)/g, '<br/>')
      }
      
      let workCity = cityLabelList.toString().replace(/,/g, '、');
      let userJobStr = industryLabelList.toString().replace(/,/g, '、');
      let yIndx = this.data.yearArr.findIndex(f=>f.value==workDate);
      if(yIndx>-1) this.setData({workYear:this.data.yearArr[yIndx].name}); 
      this.setData({cardForm,workCity:cityLabelList,userJobStr,fileList,workCity});
    }

  },
  formatCard(from,target){
    if(empty(from)) return;
    for (const key in from) {
      if (target.hasOwnProperty(key)) {
        target[key] = from[key];
      }
    }
    return target;
  },

	openCity(e) {
    if(this.data.loading) return
    const flag = e.currentTarget.dataset.disabled;
    if(flag) return
    let {cardForm,} = this.data;
   
    this.setData({ cityActiveId:cardForm.cityList });
    this.setData({showCity:true})
	 
	},
	openJobPop(e) {
    if(this.data.loading) return
    const flag = e.currentTarget.dataset.disabled;
    if(flag) return
    let indusData=localData('indusData'),yearArr=localData('yearArr');
    if(empty(indusData) || empty(yearArr)){
      this.setData({emptyShow:true})
      return
    }
    let {cardForm,} = this.data;
  
    this.setData({ indusActiveId:cardForm.industryList });
    this.setData({showIndus:true})
  },
  yearSelect(e){
   let {value,name} = e.detail;
    this.setData({showPicker:false,'cardForm.workDate':parseInt(value), workYear:name})
  },
  yearClose(){
    this.setData({showPicker:false})
  },

 
	beforeRead(e) {
		const { file, callback } = e.detail
		callback(file)
	},
	afterRead(e) {
    let filesArr = e.detail.file;
    let { fileList, cardForm, tabActive,hasUser,hasGP } = this.data
		filesArr.map((item, index) => {
			item.name = 'cardimg' + new Date().getTime() + index + item.url.substr(-4)
	 
			wx.uploadFile({
				url: `https://upload.eqianhuo.com/oss/file/upload`,
				filePath: item.url,
				name: 'file',
				success: async(res) => {
          let resdata = JSON.parse(res.data)
          let rst = resdata.data;
          let curlPicArr=[];
        
					if (rst.downloadUrl) {
            let checkRst = null;
           // if(tabActive==0){
              if(hasUser){
                console.log(rst.downloadUrl)
                checkRst = await checkImgForEdit(cardForm.id,0,rst.downloadUrl);
                console.log('个人img',checkRst)
              }else{
                checkRst={verifyStatus:0}
              }
            // }else{
            //   if(hasGP){
            //     checkRst = await checkImgForEdit(cardGPForm.id, 0, rst.downloadUrl);
            //     console.log('班组img',checkRst)
            //   }else{
            //     checkRst={verifyStatus:0}
            //   }
            // }
            if(checkRst.verifyStatus==1){
              msgToast('图片违规，上传失败！','none',3000)
              return
            }
           // if(tabActive==0){
              curlPicArr = empty(cardForm.certificateUrl)? [] : cardForm.certificateUrl.split(';') ;
              curlPicArr.push(rst.downloadUrl);

              fileList.push({ url: rst.downloadUrl, name: item.name});
              
              cardForm.certificateUrl = curlPicArr.join(';');
              
              this.setData({ fileList, cardForm });

            // }else{
            //   curlPicArr = empty(cardGPForm.certificateUrl)? [] : cardGPForm.certificateUrl.split(';');
            //   curlPicArr.push(rst.downloadUrl);

            //   fileList2.push({ url: rst.downloadUrl, name: item.name});
            //   cardGPForm.certificateUrl = curlPicArr.join(';');

            //   this.setData({ fileList2, cardGPForm })
            // }
					}
				},
			})
		})
  },
  sexChange(e){
    this.setData({"cardForm.sex": e.detail})
  },
  inputBlur(){
    this.setData({key_height:0})
  },
  // 公共输入
	getInputVal:debounce(function(e) {
    let id = e.currentTarget.id, 	val = e.detail.value, {cardForm} = this.data;
    
    if(id=='cardName' || id=='note' || id=='groupName'){
      val = e.detail;
    }
    if(id=='age' || id=="totalNumber"){
      val = val.replace(/[^\d]/g, '').replace(/^0{1,}/g,'');
      val = parseInt(val);
    }
    cardForm[id]= val;
    this.setData({cardForm}) 
	}),
 
  setWx() {
		let { cardForm } = this.data;
		if (empty(cardForm.contactPhone)) {
			msgToast('请先输入联系电话')
			return
		}
		cardForm.cardWxNumber = cardForm.contactPhone
		this.setData({ cardForm })
  },

  openUserEdit(){
    wxReport('mycard_clickedit');
    let {tabActive,cardForm,cardGPForm} = this.data;
    
    // if(tabActive==0){
      cardForm.note = cardForm.note.replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n');
      //console.log(cardForm.note)
      this.setData({isEdit:true,cardForm})
   // }else{
   
   //   cardGPForm.note = cardGPForm.note.replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n');
   //   this.setData({isGEdit:true,cardGPForm})
  //  }
  },
  imgLimit(e){
   // console.log(e)
    //msgToast('图片限制大小','none',2000)
  },
  async loadVerify(){
    let verifyArr = await getMetaData('baidu_verify_type');
    if(verifyArr && verifyArr.length){
      verifyArr=formatDict(verifyArr);
      this.setData({verifyArr})
    }else{
      this.setData({verifyArr:[]})
    }
  },
  eventType(){
    let pages = getCurrentPages();
    if(pages.length>=2){
      let {route}  = (pages[pages.length-2]);
      console.log(route);
      if(route.indexOf('index/index')>-1){
        wxReport('index_banner_mycard')
        return
      }
      if(route.indexOf('user/user')>-1){
        wxReport('user_mycard')
        return
      }
      if(route.indexOf('shorttermdetail')>-1){
        wxReport('shorttermdetail_send_mycard')
        return
      }
      if(route.indexOf('findjob')>-1 || route.indexOf('shortterm')>-1){
        wxReport('joblist_clickfindjob_mycard')
        return
      }
      if(route.indexOf('task')>-1){
        wxReport('task_mycard');
        return
      }
    }
  },
  //  名片-提交
  submitForm:debounce(async function(e){
    let { hasUser,hasGP, cardForm } = this.data;
     
		let { industryList, cityList, age, sex, note, workDate,cardWxNumber, cardType,contactPhone, cardName,groupName,totalNumber} = cardForm;
		if (empty(cardName)) {
			msgToast('请输入姓名')
			return
    }
    if (cardName.length<2) {
			msgToast('姓名限制2~20个字')
			return
    }
    
		if (empty(contactPhone)) {
			msgToast('请先输入联系电话')
			return
    }
    if (cardWxNumber && cardWxNumber.length<2) {
			msgToast('微信号限制2-20个字')
			return
    }
    if (sex<1) {
			msgToast('请选择性别')
			return
    }
    if (empty(age)) {
			msgToast('请输入年龄')
			return
    }
    if (age<18 || age>80) {
			msgToast('年龄范围限制18~80岁')
			return
    }
    if (empty(workDate)) {
			msgToast('请选择工龄，必填')
			return
    }
    if (cardType==1){
      if (empty(groupName)) {
        msgToast('请输入班组名')
        return
      }
      if (groupName.length<2) {
        msgToast('班组名限制 2~20 个字')
        return
      }
      if (empty(totalNumber)) {
        msgToast('请输入班组队伍人数')
        return
      }
      if (totalNumber<2) {
        msgToast('队伍人数限制 2~99 人')
        return
      }
    }
   
    
    if (empty(cityList)) {
			msgToast('请选择期望城市')
			return
    }
    if (empty(industryList)) {
			msgToast('请选择工种，必填')
			return
    }

    

    if (note && note.length<15) {
			msgToast('个人/项目简介不少于15个字')
			return
    }

    this.setData({ cardForm , loading:true})
  
    if(!hasUser && !hasGP){
      // 第一次发布
      addCard({ ...cardForm }).then(async(res) => {
        this.eventType();
        wxReport('mycard_clickconfirm')
        //  0-通过 1-不通过
        let {msgCheckResult,imgCheckResult,baiduMsgCheckMsg,baiduImgCheckMsg,saveForId} = res;
        cardForm.id=saveForId;
        if(msgCheckResult==1 || imgCheckResult==1){
          let {ErrInfo}= this.data;
          if(msgCheckResult==1){
            ErrInfo.msgErrShow=true;
            ErrInfo.msgErr= baiduMsgCheckMsg[0]
          }
          if(imgCheckResult==1){
            ErrInfo.imgErrShow=true;
            ErrInfo.imgErr= baiduImgCheckMsg[0]
          }

          this.setData({postErrShow:true,ErrInfo})
        
        }else{
          msgToast('发布成功', 'success')
        }

        //保存更新名片状态
        let cardStatus = gbData('cardStatus');
        cardStatus.hasUser=true;
        gbData('cardStatus',cardStatus);
        this.setData({hasUser:true,isEdit:false,cardForm});
         
        
        let id =localData('userId'), cards = await getCardInfo(id);
        if(cardForm.cardType==1) {
          cardForm= Object.assign(cardForm, cards.jobUserCardGroupBo);
        }else{
          cardForm= Object.assign(cardForm, cards.jobUserCardPersonalBo);
        }
        
        cardForm.note = cardForm.note.replace(/<br>/g,'').replace(/(\n\r|\r\n|\r|\n|\n\n)/g, '<br/>');
        this.setData({cardForm});
        //更新名片本地缓存
        this.freshCardLocal(cards);
        

      }).catch(err=>{
        //console.log('个人名片发布失败',err)
        cardForm.note = cardForm.note.replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n');
        this.setData({cardForm,isEdit:true})
        msgToast('发布失败，请重新提交！','error',5000)
      }).finally(f=>{
        this.setData({loading:false})
      })
    }else{
      //名片编辑状态---内容检测
      let checkRst=null, content = cardForm.cardType==1 ? (cardForm.cardName+cardForm.note+cardForm.groupName):(cardForm.cardName+cardForm.note);

      checkRst = await checkCForEdit(0, cardForm.id,content);
      let {ErrInfo}= this.data;
 
      if(checkRst && checkRst.verifyStatus==1){ 
        ErrInfo.msgErrShow=true;
        ErrInfo.msgErr= checkRst.baiduVerifyMsg[0]
        this.setData({postErrShow:true,ErrInfo,cardForm});
        return
      }

      // let selfImgs = this.data.fileList;
      // let {num,xArr,desc} = await this.imgArrCheck(selfImgs,cardForm.id);
      // if(num>0){
      //   let str = xArr.toString().replace(/,/g,'、');
      //   this.setData({selfErrImg:str})
      //   ErrInfo.imgErrShow=true;
      //   ErrInfo.imgErr= desc[0];
      //   this.setData({postErrShow:true, ErrInfo});
      //   return
      // }

      // 校验通过 修改第三方审核状态
      cardForm.secVerifyStatus=1;
      cardForm.status=1;
      // 提交前过滤转换换行
      cardForm.note = cardForm.note.replace(/<br>/g,'').replace(/(\n\r|\r\n|\r|\n|\n\n)/g, '<br/>');
     
       // 名片-编辑 
      editCard({ ...cardForm }).then(async(res) => {
         
        msgToast('编辑成功', 'success',2000)

        this.setData({hasUser:true,isEdit:false});
        let id =localData('userId'),cards = await getCardInfo(id) ;
        
        let targetObj= cards.jobUserCardGroupBo || cards.jobUserCardPersonalBo;
      
        if(targetObj){
          localData('cardInfo',cards);
          for (const key in targetObj) {
            if (cardForm.hasOwnProperty(key)) {
              cardForm[key] = targetObj[key]
            }
          }           
          //个人页面缓存 去/n
          cardForm.note = cardForm.note.replace(/<br>/g,'').replace(/(\n\r|\r\n|\r|\n|\n\n)/g, '<br/>');
          this.setData({cardForm});
          this.freshCardLocal(cards);
        }
      }).catch(err=>{
        msgToast('编辑失败，请重新提交！','none',2000)
        cardForm.note = cardForm.note.replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n');
        this.setData({cardForm,isEdit:true})
      }).finally(f=>{
        this.setData({loading:false})
      })
    }
	}),
	 
 
  freshCardLocal(data){
    let cardinfo = data, cardStatus = gbData('cardStatus');
    let {jobUserCardGroupBo, jobUserCardPersonalBo} = cardinfo;

    cardStatus.hasUser = empty(jobUserCardPersonalBo)? false : true;
    cardStatus.hasGP = empty(jobUserCardGroupBo)? false : true;

    // 本地缓存去 /n
    if(!empty(jobUserCardGroupBo)) jobUserCardGroupBo.note = jobUserCardGroupBo.note.replace(/<br>/g,'').replace(/(\n\r|\r\n|\r|\n|\n\n)/g, '<br/>')
    if(!empty(jobUserCardPersonalBo)) jobUserCardPersonalBo.note = jobUserCardPersonalBo.note.replace(/<br>/g,'').replace(/(\n\r|\r\n|\r|\n|\n\n)/g, '<br/>')

    localData('cardInfo',{jobUserCardGroupBo,jobUserCardPersonalBo})
    gbData('cardStatus',cardStatus)
  },
	delImgItem(e) {
  
    let url = e.detail.file.url,{ fileList,fileList2,tabActive,cardForm,cardGPForm } = this.data;
   // if(tabActive==0){
      let has = fileList.findIndex(f=>f.url==url);
      if(has>-1){
        fileList.splice(has,1)
      }
      let imgs = fileList.map(i=>{
        return i.url;
      })
      cardForm.certificateUrl = imgs.join(';')
      this.setData({ fileList,cardForm })
    // }else{
    //   let has = fileList2.findIndex(f=>f.url==url);
    //   if(has>-1){
    //     fileList2.splice(has,1)
    //   }
    //   let imgs = fileList2.map(i=>{
    //     return i.url;
    //   })
    //   cardGPForm.certificateUrl = imgs.join(';')
    //   this.setData({ fileList2,cardGPForm })
    // }
  },

	// 切换类别
	tabChange(e) {
    if(this.data.loading) return
    let val = e.detail;
    let {hasGP,hasUser,isGEdit,isEdit,tabActive,} =this.data;
    
  //  if(tabActive == idx) return
    // if((hasUser && isEdit) || (isGEdit && hasGP)){
    
    //   Dialog.confirm({
    //     title: `切换至${idx==0?'个人':'班组'}`,
    //     message: '已编辑内容不会保存，确认切换？',
    //   }).then(() => {
    //     this.setData({tabActive: idx})
    //     //初始化
    //    this.initCard()
    //   });
    //   return
    // }
    this.setData({'cardForm.cardType': val,loading:false })
  },
  // 退出编辑
  quitEdit(){
    console.log('退出编辑',this.data.loading)
    if (this.data.loading) return
    Dialog.confirm({
      title: '提示',
      message: '已编辑内容未保存，确认退出？',
      className:"custom_dialog",
    }).then(() => {
      this.initCard()
    }).catch(() => {
      console.log('取消')
    });
    
  },
  // 切换名片类型
  changeType(e){
    if(this.data.loading) return;
    let value = e.currentTarget.dataset.value,   {cardForm} = this.data;
    cardForm.cardType=value;

    if(value==0){
      delete cardForm.groupName;
      delete cardForm.totalNumber;
     
    }else{
      cardForm.groupName='';
      cardForm.totalNumber='';
    }
    this.setData({cardForm});
  },
 
  async imgArrCheck(list,id){
    let wait = []
    list.map(m=>{
      let a = checkImgForEdit(0, id, m.url);
      wait.push(a)
    })
    let num=0,xArr=[],desc=[];
    let arr = await Promise.all(wait);
    console.log(arr)
    if(!empty(arr)){
      arr.map((it,idx)=>{
        if(it.verifyStatus==1){
          num++;
          let noNum = idx+1;
          xArr.push(noNum);
          desc.push(it.baiduVerifyMsg[0])
        }
      })
    }
    return {num,xArr,desc}
  },
  async reloadIndus(){
    let {job_industry,job_benifit,work_year,company_scale,company_type,report_type,card_group_total} = await initMetaData();
    if(!empty(job_industry)){
      this.setData({emptyShow:false})
      let indusData = job_industry.map((it,idx)=>{
        let obj = {
          text:it.dictLabel,
          id:it.dictValue,
          badge:null,
          num:0,
          disabled:false
        };
        !empty(it.children) && (obj.children = it.children.map(c=>{
          return {
            idx:idx,
            text:c.dictLabel,
            id:c.dictValue
          }
        }));
        return obj
      });
      //msgToast('加载成功')
      localData('indusData',indusData)
    }
    if(!empty(work_year)){
      let yearArr = formatDict(work_year);
      this.setData({yearArr}); //缓存
      console.log('success')
      localData('yearArr',yearArr)
    }
    this.initCard();
    if(!empty(job_benifit)){
      let benifit = formatDict(job_benifit);
      localData('benifit',benifit)
    }
   
    if(!empty(card_group_total)){
      let memArr = formatDict(card_group_total);
      localData('memArr',memArr)
    }
    if(!empty(company_scale)){
      let comSArr = formatDict(company_scale);
      localData('comSArr',comSArr)
    }
    if(!empty(company_type)){
      let comTArr = formatDict(company_type);
      localData('comTArr',comTArr)
    }
    if(!empty(report_type)){
      let reportArr = formatDict(report_type);
      localData('reportArr',reportArr)
    }
  }
})
