import { blackList,delblack } from '../../../api/user'
import {empty, gbData, msgToast} from '../../../utils/index'

Page({
  data: {
    listArr:[],
    isSpecil:false,
    query:{
      pageSize: 10,
      pageNum: 1,
    },
    showLoading:false,
    loading:false,
    hasMore:true
  },

 
  onLoad(options) {
    this.getList()
  },
  onReachBottom(){
    
    console.log('到底')
    let {hasMore,loading,query} =this.data;
    if(!hasMore  || loading) return
    this.setData({loading:true})
    let num = query.pageNum;
    num++;
    this.setData({'query.pageNum':num})
  
     this.getList();
 
    
  },
  remove(e){
 
    let id =e.currentTarget.id;

    delblack({id}).then(res=>{
      let {listArr} = this.data, idx= listArr.findIndex(f=>f.id==id);
       listArr.splice(idx,1);
       if(empty(listArr)){
         this.setData({hasMore:false,showLoading:false})
       }
       this.setData({listArr})
      msgToast('移除成功','success')
    }).catch(err=>{
      msgToast('移除失败','error')
    })
  },
  getList(){
    let {query} = this.data;
    blackList(query).then(res=>{
      this.setData({loading:false})
      let {total,rows} =res;
      rows = rows || [];
      rows = rows.map((m,i)=>{
        let {userBo,companyBo,id,fromType,fromRelationId,fromPoint,blackRelationId,blackRelationType} = m
        let type = empty(companyBo)?0:1;
        return {
          no:`${id}_${i}`,
          type,
          data:userBo || companyBo,
          id,fromType,fromRelationId,fromPoint,blackRelationId,blackRelationType
        }
      })
      if(query.pageNum==1){
        this.setData({listArr:rows});
        if(rows.length==total){
          total==0? this.setData({showLoading:false}): this.setData({showLoading:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true});
          return
        }
        this.setData({listArr:this.data.listArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.listArr.length;
       
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,showLoading:true})
      }
    })
  }
})