import { empty, localData, gbData, wxReport, getUrlParams } from '../../../utils/index';
import { getOpenId, wxlogin, userinfo, upDateUser, taskList, adrList } from '../../../api/user';
import { getCardInfo, msgInfo } from '../../../utils/getData';
Page({
  data: {
    isWxLogin: false,
    disabled: false,
    openid: null
  },
  onLoad() {},
  getOpenId() {
    return new Promise((resolve, reject) => {
      wx.login({
        success: (res) => {
          let code = res.code
          if (!empty(code)) {
            getOpenId({ code }).then(rst => {
              //获取openid
              localData('openid', rst.openid)
              resolve(rst.openid)
            }).catch(err => {
              reject(err)
            })
          }
        }
      })
    })
  },
  async getPhoneNumber(e) {
    let code = e.detail.code;
    if (empty(code)) return;
    let openid = await this.getOpenId();

    this.setData({ isWxLogin: true });
    //登录
    wxlogin({ code, openid }).then(res => {
      let { token, userId, tel } = res;
      localData('token', token)
      localData('userId', userId)
      localData('tel', tel);


      let pages = getCurrentPages(), curpage = pages[pages.length - 1],prevpage=null;
      if (pages.length >= 2) prevpage = pages[pages.length - 2];
      
      
      if(!empty(curpage.options)){
        this.loginEvents(curpage.options);
      }
      console.log('curpage:',curpage,'prevpage:',prevpage);

      if (prevpage) {
        let { options, route } = prevpage;
        // 分页导致的 判断
        if(!empty(curpage.options)){
          if(curpage.options.req==1){
            this.pageEvents(route, curpage.options);
          }
        }
        //
        this.routeEvents(route);
        // 扫码传参-判断
        let queryStr = "", paramObj = {};
        if (!empty(options)) {
          if (options.q) {
            let urlstr = decodeURIComponent(options.q);
            //console.log('login-扫码跳转',options.q,'urlstr',urlstr)
            paramObj = getUrlParams(urlstr);
          } else {
            paramObj = options;
          }
          for (let k in paramObj) {
            if (Object.hasOwnProperty.call(paramObj, k)) {
              queryStr += encodeURIComponent(k) + "=" + encodeURIComponent(paramObj[k]) + "&";
            }
          }
          queryStr = queryStr.length ? ('?' + queryStr.slice(0, queryStr.length - 1)) : "";
        } 
        wx.reLaunch({ url: `/${route}${queryStr}` });
      } else {
        wx.reLaunch({
          url: '/pages/index/index',
        });
      }
    
      //获取用户信息
      this.getUserInfo(userId)
      this.getTaskList();
      this.loadAdr() //收货地址
    })
  },

  loginEvents(params){
    // 当前页-传参判断
    if(params.from=='banner'){
      wxReport('index_banner_login')
      return
    }
    if(params.from=='invite'){
      wxReport('index_invite_login')
      return
    }
    if(params.from=='lottery'){
      wxReport('index_lottery_login')
      return
    }
    if(params.from=='real'){
      //实名触发  找活干-去实名-登录、招工人-去实名-登录
      wxReport('gorealname_login')
      return
    }
  
    if(params.from=='findjob' || params.from=='shortterm'){
      //findjob
     // console.log('joblist_clickfindjob_login')
      wxReport('joblist_clickfindjob_login')
      return
    }
    if(params.from=='findworker'){
      //findworker
      wxReport('findworker_clickfindworker_login')
      return
    }
    
  },
  routeEvents(params){
    // 上一页-判断 不含首页
    if(params.indexOf('index/index')>-1) return

    console.log('routeEvents',params)
    
    if(params.indexOf('shorttermdetail')>-1){
      wxReport('shorttermdetail_login')
      return
    }
    if(params.indexOf('workerdetail')>-1){
      wxReport('workerdetail_login')
      return
    }
    if(params.indexOf('user/')>-1){
      wxReport('user_login')
      return
    }
    if(params.indexOf('message')>-1){
      wxReport('message_login')
      return
    }
  },
  // 分页事件
  pageEvents(route,param){
    console.log('分页事件',route);
    if(route.indexOf('index/index')>-1){
      console.log('index_morelist_login')
      wxReport('index_morelist_login')
      return
    }
    if(route.indexOf('shortterm')>-1){
      if(param.iscom==1){
        console.log('commonlist_morelist_login')
        wxReport('commonlist_morelist_login')
      }else{
        console.log('shortterm_morelist_login')
        wxReport('shortterm_morelist_login')
      }
      return
    }
    if(route.indexOf('findjob')>-1){
      wxReport('findjob_morelist_login')
      return
    }
    if(route.indexOf('findworker')>-1){
      wxReport('findworker_morelist_login')
      return
    }
    if(route.indexOf('search')>-1){
      wxReport('search_morelist_login')
      return
    }
    
  },

  // 任务
  getTaskList() {
    let userId = localData('userId')
    taskList({ userId: userId }).then(res => {
      this.setData({ taskArr: res })

    })
  },
  getUserInfo() {
    userinfo({}).then(async res => {
      let info = res;
      //
      let { avator, name, nickName, openid, id } = info;

      if (empty(avator) && empty(name) && empty(nickName)) {
        //第一次登录  设置默认昵称
        nickName = '技工0' + id;
        upDateUser({ openid, nickName }).then(res => {
          info.nickName = nickName;
          localData('userInfo', info);
        })
      } else {
        localData('userInfo', info);
      }
      //查询名片信息

      let cards = await getCardInfo(id);
      if (!empty(cards)) {
        let cardStatus = {}, { jobUserCardGroupBo, jobUserCardPersonalBo } = cards;
        cardStatus.hasGP = empty(jobUserCardGroupBo) ? false : true;
        cardStatus.hasUser = empty(jobUserCardPersonalBo) ? false : true;
        gbData('cardStatus', cardStatus);
        localData('cardInfo', cards);
      }

      let { unread } = await msgInfo();
      gbData('unread', unread);
      localData('unread', unread);
      unread > 0 ? wx.setTabBarBadge({ index: 3, text: unread.toString() }) : wx.removeTabBarBadge({ index: 3 })

    }).catch(err => {
      wx.showToast({
        title: '获取用户信息失败！',
        duration: 1500
      });
      wx.clearStorageSync()
      wx.reLaunch({
        url: '/pages/user/login/index',
      });
    })
  },
  loadAdr() {
    adrList({}).then(res => {
      let arr = empty(res) ? [] : res;
      localData('adrArr', arr)
    });
  }
})