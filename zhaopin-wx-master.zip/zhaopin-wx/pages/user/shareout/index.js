 
import { localData,gbData,loginCtrl} from "../../../utils/index";
import {regShare, regNum } from "../../../api/base";

Page({
	data: {
    shareNum:0,
    balance:gbData('balance'),
    show:false,
    title:'天天抽奖赚好礼，招工找活用仟活',
    userinfo:localData('userInfo'),
    defaultStatus:false,
  },
  onLoad(){
    let wh = gbData('winHeight'), height = 734 * wh / 734;
    this.setData({defaultStatus:false,height})
  },
  async onShow(){
    if(this.data.defaultStatus){
      setTimeout(()=>{
        if(loginCtrl()){
          console.log('onShow,执行分享')
          this.shareRegLog()
        }
      },200)
    }else{
      if(loginCtrl()){  
        console.log('onShow,查询次数')
        await this.loadNum();
      }
    }
  },
  shareRegLog(){
    regShare({}).then(res=>{
      this.setData({show:true});
      console.log('shareRegLog',res)
    })
  },
  loadNum(){
    return new Promise((resolve,reject)=>{
      regNum({}).then(res=>{
        let num = res || 0;
        this.setData({shareNum:num})
        resolve()
      }).catch(err=>{
        reject(err)
      })
    });
   
  },
  async closePop(){
    //console.log(this.data.balance)
    this.setData({show:false,defaultStatus:false});
    await this.loadNum();
  },
  clickShare(){
    this.setData({defaultStatus:true})
  },
  onShareAppMessage(options){
   
    let {title} = this.data;
    //console.log(title)
    //this.addShareLog()
    return {
      title:title,
      path: `/pages/index/index`,
      imageUrl:''
    }
  },
  onShareTimeline(){
    let {title} =this.data;
    //this.addShareLog()
    return {
      title:title,
      path: `/pages/index/index`,
      imageUrl:''
    }
  },
})