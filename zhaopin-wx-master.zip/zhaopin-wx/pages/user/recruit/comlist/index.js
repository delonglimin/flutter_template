import { postedMe,calledMe,viewedMe } from '../../../../api/job'
 
Page({
  data: {
    tabActive:0,
    postedArr:[],
    viewedArr:[],
    calledArr:[],
    isSpecil:false,
    query:{
      jobId:null,
      pageSize: 10,
      pageNum: 1,
    },
    vquery:{
      jobId:null,
      pageSize: 10,
      pageNum: 1,
    },
    cquery:{
      jobId:null,
      pageSize: 10,
      pageNum: 1,
    },
    postedNum:0,
    viewedNum:0,
    calledNum:0,
    hasMore:true,loading:false,show:false,
    vhasMore:true,vloading:false,vshow:false,
    chasMore:true,cloading:false,cshow:false,
  },

 
  onLoad(options) {
    let {type,id} = options;
    console.log(id)
    if(id) this.setData({'query.jobId':id,'cquery.jobId':id,'vquery.jobId':id})
    switch (Number(type)) {
      case 0:
        this.setData({isSpecil:false,tabActive:0})
        break;
      case 1:
        this.setData({isSpecil:false,tabActive:1})
        break;
      case 2:
        this.setData({isSpecil:true,tabActive:2})
        break;
    }
   
    this.getPostedList();this.getViewList();  
  },
  onReachBottom(){
    console.log('到底')
    let {tabActive} =this.data;
    if(tabActive==0){
      let {hasMore,loading,query} =this.data;
      if(!hasMore || loading) return
      query.pageNum++;
      this.setData({query,loading:true})
      this.getPostedList();
      return
    }
    if(tabActive==1){
      let {vhasMore,vloading,vquery} =this.data;
      if(!vhasMore || vloading) return
      vquery.pageNum++;
      this.setData({vquery,vloading:true})
      this.getViewList();
      return
    }
    if(tabActive==2){
      let {chasMore,cloading,cquery} =this.data;
      if(!chasMore || cloading) return
      cquery.pageNum++;
      this.setData({cquery,cloading:true})
      this.getCallList();
    }
  },
  getlistFilter(e){
    let type = e.target.dataset.type,nowidx=this.data.tabActive;
    if(nowidx==type) return
    type=  Number(type)
    this.setData({tabActive:type})
  },
  //看过我i
  getViewList(){
    let {vquery} = this.data;
    viewedMe(vquery).then(res=>{
      this.setData({vshow:false})
      let {total, rows} =res;
      this.setData({viewedNum:total})
       
      rows = rows || [];
      if(vquery.pageNum==1){
        this.setData({viewedArr:rows});
        if(rows.length==total){
          total==0? this.setData({vshow:false}): this.setData({vshow:true})
          this.setData({vhasMore:false})
          return
        }
      }
      if(vquery.pageNum>1){
        if(empty(rows)){
          this.setData({vhasMore:false,vshow:true});
          return
        }
        this.setData({viewedArr:this.data.viewedArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.viewedArr.length;
        len<total ? this.setData({vhasMore:true}): this.setData({vhasMore:false,vshow:true})
      }
    })
  },
  //沟通过
  getCallList(){
    let {cquery} = this.data;
    calledMe(cquery).then(res=>{
      this.setData({cshow:false})
      let {total, rows} =res;
      this.setData({calledNum:total})
      rows = rows || [];
      if(cquery.pageNum==1){
        this.setData({calledArr:rows});
        if(rows.length==total){
          total==0? this.setData({cshow:false}): this.setData({cshow:true})
          this.setData({chasMore:false})
          return
        }
      }
      if(cquery.pageNum>1){
        if(empty(rows)){
          this.setData({chasMore:false,cshow:true});
          return
        }
        this.setData({calledArr:this.data.calledArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.calledArr.length;
        len<total ? this.setData({chasMore:true}): this.setData({chasMore:false,show:true})
      }
    }).catch(err=>{
      this.setData({cshow:false})
    })
  },
  //投递过
  getPostedList(){
    let {query} = this.data;
    postedMe(query).then(res=>{
      this.setData({show:false})
      let {total, rows} =res;
      this.setData({postedNum:total})
      rows = rows || [];
      if(query.pageNum==1){
        this.setData({postedArr:rows});
        if(rows.length==total){
          total==0? this.setData({show:false}): this.setData({show:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({hasMore:false,show:true});
          return
        }
        this.setData({postedArr:this.data.postedArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.postedArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,show:true})
      }
    }).catch(err=>{
      this.setData({show:false})
    })
  }
})