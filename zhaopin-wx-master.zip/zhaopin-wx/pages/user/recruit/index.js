import {myJobWithStatistics,refreshJob,refreshJobNum,tooglejobs,delJob} from '../../../api/job'
import {empty, msgToast,formatSalary} from '../../../utils/index'
import Dialog from '@vant/weapp/dialog/dialog';
Page({
  data: {
    tabActive: 0,
    jobArr: [],//招工中
    checkArr:[],//审核中
    failArr:[],//未通过
    pauseArr:[],

    loading:false,
    showLoading:false,
    hasMore:false,

    cloading:false,
    cshowLoading:false,
    chasMore:false,

    floading:false,
    fshowLoading:false,
    fhasMore:false,

    ploading:false,
    pshowLoading:false,
    phasMore:false,

    query: {
      pageNum: 1,
      pageSize: 10,
      status: 1, // 上下架 0-下架 1-上架
      verifyStatus:1  // 0-待审核 1-审核成功 2-审核失败
    },
    query2: {
      pageNum: 1,
      pageSize: 10,
      status: 0, // 上下架 0-下架 1-上架
      verifyStatus:0  // 0-待审核 1-审核成功 2-审核失败
    },
    query3: {
      pageNum: 1,
      pageSize: 10,
      status: 0, // 上下架 0-下架 1-上架
      verifyStatus:2  // 0-待审核 1-审核成功 2-审核失败
    },
    query4: {
      pageNum: 1,
      pageSize: 10,
      status: 0, // 上下架 0-下架 1-上架
      verifyStatus:1  // 0-待审核 1-审核成功 2-审核失败
    }

  },
  onLoad(o){
    console.log(o)
    if(o.tabactive && o.tabactive>-1){
      this.setData({tabActive:o.tabactive})
    }
    let {query,query2,query3,query4} =this.data;
    this.getList(query,0);
    this.getList(query2,1);
    this.getList(query3,2);
    this.getList(query4,3);
  },
  onReachBottom(){
    console.log('到底')
    let {tabActive,query,query2,query3,query4}=this.data;
    if(tabActive==0){
      if(!this.data.hasMore || this.data.loading) return
      query.pageNum++;
      this.setData({loading:true,query})
      this.getList(query,0);
    }else if(tabActive==1){
      if(!this.data.chasMore || this.data.cloading) return
      query2.pageNum++;
      this.setData({cloading:true,query2})
      this.getList(query2,1);
    }else if(tabActive==2){
      if(!this.data.fhasMore || this.data.floading) return
      query3.pageNum++;
      this.setData({floading:true,query3})
      this.getList(query3,2);
    }else{
      if(!this.data.phasMore || this.data.ploading) return
      query4.pageNum++;
      this.setData({ploading:true,query4})
      this.getList(query4,3);
    }
  },
  getlistFilter(e){
    let type = e.target.dataset.type,nowidx=this.data.tabActive;
    if(nowidx==type) return
    type =  Number(type)
    this.setData({tabActive:type})
  
  },
 
  // 获取我的招工
  getList(param,type){
    myJobWithStatistics(param).then(res=>{
      if(type==0){
        this.setData({loading:false})
      }else if(type==1){
        this.setData({cloading:false})
      }else if(type==2){
        this.setData({floading:false})
      }else{
        this.setData({ploading:false})
      }
      let {rows,total} = res;
      rows = rows || [];
      if(!empty(rows)){
        rows.map(m=>{
          let {salaryType,salaryMax,salaryMin} = m;
          m.salary = formatSalary(salaryType,salaryMax,salaryMin,1)
        })
      }

      if(param.pageNum==1){
       
        if(type==0){
          this.setData({jobArr:rows})
        }else if(type==1){
          this.setData({checkArr:rows});
        }else if(type==2){
          this.setData({failArr:rows});
        }else{
          this.setData({pauseArr:rows});
        }
          
        if(rows.length==total){
          if(total==0){
            if(type==0){
              this.setData({showLoading:false})
            }else if(type==1){
              this.setData({cshowLoading:false})
            }else if(type==2){
              this.setData({fshowLoading:false})
            }else{
              this.setData({pshowLoading:false})
            }
          }else{
            if(type==0){
              this.setData({showLoading:true})
            }else if(type==1){
              this.setData({cshowLoading:true})
            }else if(type==2){
              this.setData({fshowLoading:true})
            }else{
              this.setData({pshowLoading:true})
            }
          }
          if(type==0){
            this.setData({hasMore:false})
          }else if(type==1){
            this.setData({chasMore:false})
          }else if(type==2){
            this.setData({fhasMore:false})
          }else{
            this.setData({phasMore:false})
          }
          return
        }
      }
      if(param.pageNum>1){
        if(empty(rows)){
          if(type==0){
            this.setData({hasMore:false,showLoading:true});
          }else if(type==1){
            this.setData({chasMore:false,cshowLoading:true});
          }else if(type==2){
            this.setData({fhasMore:false,fshowLoading:true});
          }else{
            this.setData({phasMore:false,pshowLoading:true});
          }
          return
        }
        if(type==0){
          this.setData({jobArr:rows.concat(this.data.jobArr)});
        }else if(type==1){
          this.setData({checkArr:rows.concat(this.data.checkArr)});
        }else if(type==2){
          this.setData({failArr:rows.concat(this.data.failArr)});
        }else{
          this.setData({pauseArr:rows.concat(this.data.pauseArr)});
        }
      }
      if(total >0){
        if(type==0){
          this.data.jobArr.length < total ? this.setData({hasMore:true}): this.setData({hasMore:false,showLoading:true})
        }else if(type==1){
          this.data.checkArr.length < total ? this.setData({chasMore:true}): this.setData({chasMore:false,cshowLoading:true})
        }else if(type==2){
          this.data.failArr.length < total ? this.setData({fhasMore:true}): this.setData({fhasMore:false,fshowLoading:true})
        }else{
          this.data.pauseArr.length < total ? this.setData({phasMore:true}): this.setData({phasMore:false,pshowLoading:true})
        }
      }
      
    }).catch(err=>{
      if(type==0){
        this.setData({loading:false})
      }else if(type==1){
        this.setData({cloading:false})
      }else if(type==2){
        this.setData({floading:false})
      }else{
        this.setData({ploading:false})
      }
    })
  },
  updateJobStatus(id,status){
    tooglejobs({id,status}).then(res=>{
      // 0-下  1-上
      let {jobArr,pauseArr} =this.data;
      
      if(status==0){
        let idx = jobArr.findIndex(f=>f.id==id);
        msgToast('暂停成功')
        if(idx>-1){
          
          jobArr.splice(idx,1);
          let query4 = this.data.query4;
          query4.pageNum=1;
          this.setData({jobArr,pauseArr})
          this.setData({query4,jobArr})
          this.getList(query4,3);
        
        }
      
      }else{
        msgToast('开始成功')
        let pidx = pauseArr.findIndex(p=>p.id==id);
        if(pidx>-1){
          
          pauseArr.splice(pidx,1);
          let query = this.data.query;
          query.pageNum=1;
          this.setData({query,pauseArr})
          this.getList(query,0);
         
        }
      }
      
    })
  },
  pauseWork(e){
    console.log('数据',e.detail)
    let id =e.detail;
    this.updateJobStatus(id,0)
  },
  startWork(e){
    let id =e.detail;
    this.updateJobStatus(id,1)
  },

  delWork(e){
    console.log(e)
    let {id,type} =e.detail,idx = e.currentTarget.dataset.idx;
    console.log(id,type,idx)
    //  
    Dialog.confirm({
      title: '提示',
      message: '您确认要删除职位吗？',
      zIndex:10000
    }).then(() => {
      delJob({id}).then(res=>{
        msgToast('删除成功');
        if(type==2){
          let {failArr} =this.data;
          failArr.splice(idx,1);
          this.setData({failArr})
        }else{
          let {pauseArr} =this.data;
          pauseArr.splice(idx,1);
          this.setData({pauseArr})
        }
      }).catch(err=>{
        console.log(err)
      })
    }).catch(()=>{
      //取消
    })
  },
  editeWork(e){
    let id =e.detail;
    wx.navigateTo({
      url: `/pages/user/recruit/add/index?id=${id}&type=1`,
      fail:err=>{
        console.log(err)
      }
    })
  },
  doRefreshJob(param,operate){
    refreshJob(param).then(res=>{
      let {jobArr,failArr,pauseArr,tabActive} =this.data;
        if(operate=='pause'){
          let idx = jobArr.findIndex(f=>f.id==param.id)
          msgToast('暂停成功')
          jobArr.splice(idx,1);
          let query4 = this.data.query4;
          query4.pageNum=1;
          this.setData({query4,jobArr})
          this.getList(query4,3);
        }
        if(operate=='start'){
          let idx = pauseArr.findIndex(f=>f.id==param.id)
          msgToast('开始成功')
          pauseArr.splice(idx,1);
          this.setData({pauseArr})
          let query = this.data.query;
          query.pageNum=1;
          this.setData({query})
          this.getList(query,0);
        }
        if(operate=='delete'){
          msgToast('删除成功')
          if(tabActive==2){
            let idx = failArr.findIndex(f=>f.id==param.id)
            failArr.splice(idx,1);
            this.setData({failArr});
            if(failArr.length==0){
              this.setData({fshowLoading:false})
            }
            return
          }
          if(tabActive==3){
            let idx = pauseArr.findIndex(f=>f.id==param.id)
            pauseArr.splice(idx,1);
            if(pauseArr.length==0){
              this.setData({pshowLoading:false})
            }
            this.setData({pauseArr})
          }
        }
        
    }).catch(err=>{
      msgToast('操作失败')
    })
  },
  doRefreshJobNum(e){
    let jobId =e.detail;
    if(empty(jobId)) return;
    refreshJobNum({jobId}).then(res=>{
      msgToast('刷新成功')
      // let {jobCallLogTotal, jobReceiveCardTotal, jobWatchedTotal} =res,{jobArr}=this.data;
      // let idx = jobArr.findIndex(f=>f.id==jobId)
      // if(idx>-1){
      //   jobArr[idx].jobLogStatisticsBo={
      //     jobCallLogTotal, jobReceiveCardTotal, jobWatchedTotal
      //   }
      //   this.setData({jobArr})
      // }
    })
  }
})