
import {localData,empty,msgToast,tidyBr,tidyBrBack,formatSalary, gbData, wxReport} from '../../../../utils/index'
import{jobItem,refreshJob} from '../../../../api/job'
import {addJob} from '../../../../api/base'
import { checkCForEdit,formatDict,initMetaData,getCityCode } from '../../../../utils/getData'
Page({
  data: {
    loading:false,
    addTitle:'发布招工信息',
    hasInfo:true,
    emptyShow:false,
    tabActice:0,
    hasMid:false, // 市 flag
    hasLast:false, // 区 flag
    areaList:{},
    show2:false,
    show:false, //省市弹窗显示
    cityname:'', //工作城市名 显示在页面中
    cityData:{
      cityname:'',
      cityID:null
    },
    jobArrStr:'', //工种字符串
    realName:false,//实名
    newJobForm:{
      publisherUserType:0, //0-普通用户 1-企业用户
      publisherUserId:localData('userId'),//发布人ID
      publisherCompanyId:0,//发布公司ID
      title:'',
      industryList:[],
      jobType:0, // 0-个人 1-班组
      jobWorkerType:0, //用工类型 0-零工 1-全职
      city:'', //工作城市id
      address:'', //工作地点
      salaryType:0,//薪资类别 0-面议 1-日结 2-月结
      salaryMax:null,
      salaryMin:null,
      contactPhone:'',
      contactName:'',
      benifitList:[],//福利
      jobDescription:'', //岗位描述/职责
      secVerifyIdList:[],
      secVerifyStatus:null
    },
    jobTerm:0,
    jobWages:0,
   
    descArr: [],
    isEdit:false,
  },

  onLoad(options) {
    wxReport('recruit')
   
    let {id,type} = options;
    let userinfo = localData('userInfo'),{newJobForm} = this.data,
    descArr = localData('benifit'), indusData=localData('indusData');

    let realName =userinfo.verifyStatus==1?true:false;
    this.setData({realName});

    if(empty(descArr) || empty(indusData)){
      this.reloadIndus()
    }else{
      this.setData({descArr,emptyShow:false})
    }
    
    // type 0-发布模式  1-编辑模式
    if(type==0){
      this.eventType();
      newJobForm.contactPhone = userinfo.tel;
      if(realName){
        newJobForm.contactName= userinfo.name;
      }else{
        newJobForm.contactName = userinfo.name?userinfo.name:userinfo.nickName?userinfo.nickName: `技工0${userinfo.id}`;
      }
      this.setData({newJobForm,isEdit:true,hasInfo:false,addTitle:'发布招工信息',});
    }else{
      this.setData({hasInfo:true,isEdit:false,addTitle:'招工信息'})
      this.getJobDetail(id)
    }
  },
 
  backLeft(){
    wx.navigateBack({
      delta: 1,
    })
  },
  // 获取返回的工种
  getIndusArr({detail={}}){
    let {industryList,insusNameStr} = detail;
    this.setData({jobArrStr:insusNameStr,'newJobForm.industryList':industryList})
  },
  getCityArr({detail={}}){
    let {cityNameStr,cityList} = detail;
    let city = empty(cityList)? '': cityList[0];
    this.setData({ 'newJobForm.city':city, cityname: cityNameStr})
  },
  openEdit(){
    if(this.data.isEdit){
      this.submitForm();
      return 
    }
    let {newJobForm} =this.data;
    newJobForm.jobDescription = newJobForm.jobDescription.replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n');
  
    this.setData({isEdit:true,newJobForm, hasInfo:true,addTitle:'编辑招工信息'})
   
  },
  getJobDetail(id){
    let {newJobForm}=this.data;
    newJobForm.id = id;
    jobItem({id}).then(res=>{
      let detail = res;
      for(let key in detail){
        if(newJobForm.hasOwnProperty(key)){
          newJobForm[key] = detail[key]
        }
      }
     // cityName salary_type             jobArrStr
      let { cityName,industryLabelList,jobDescription, jobRequirement,salaryType,salaryMax,salaryMin,title,jobWorkerType} = detail;
      this.setData({addTitle:title,jobTerm:jobWorkerType})
      let jobArrStr = industryLabelList.toString().replace(/,/g,'、');
      //转换br
      newJobForm.jobDescription = jobDescription.replace(/<br>/g,'').replace(/(\n\r|\r\n|\r|\n|\n\n)/g, '<br/>')
      let salary = formatSalary(salaryType,salaryMax,salaryMin,1)
      let benifit = detail.benifitLabelList;
      this.setData({newJobForm, cityname:cityName,jobArrStr,salary,benifit});

      let {descArr} =this.data;
      
      if(empty(detail.benifitList)) return

      if(!empty(descArr)){
        descArr&&descArr.map(m=>{
          detail.benifitList.map(d=>{
            if(m.value == d){
              m.active =true;
            }
          });
          return m
        })
        this.setData({descArr:descArr})
      }
    })
  },
  openCityPop(){
    let {newJobForm} =this.data;
    let idArr = empty(newJobForm.city)?[]:[newJobForm.city];
    this.setData({showCity:true,cityActiveId:idArr})
  },
  openJobPop(e){
    if(this.data.loading) return;
    const flag = e.currentTarget.dataset.disabled;
    if(flag) return
    let indusData=localData('indusData');
    if(empty(indusData)){
      this.setData({emptyShow:true})
      return
    }

    let {newJobForm} =this.data;
    this.setData({ indusActiveId:newJobForm.industryList,showIndus:true })
  },
 

  toggleItem(e){
    if(this.data.loading) return;
    let idx = e.currentTarget.dataset.idx;
    let {descArr,newJobForm} = this.data;
    descArr[idx].active = !descArr[idx].active;
    let fArr = descArr.filter(m=>m.active==true);
    if(fArr && fArr.length<=5){
      newJobForm.benifitList = fArr.map(i=>{
        return i.value
      })
    }else{
      msgToast('最多选择5个')
      descArr[idx].active=false;
    }
    this.setData({descArr, newJobForm})
  },

  // 用工类型radio
  changeJob(e){
    if(this.data.loading) return;
    let value = e.currentTarget.dataset.value;
    let {newJobForm} = this.data;
    newJobForm.jobWorkerType = value;
    this.setData({jobTerm:value,newJobForm})
  },
  changejobType(e){
    if(this.data.loading) return;
    let value = e.currentTarget.dataset.value;
    let {newJobForm} = this.data;
    newJobForm.jobType = value;
    this.setData({ newJobForm})
  },
  changeWages(e){
    if(this.data.loading) return;
    let value = e.currentTarget.dataset.value;
    let {newJobForm} = this.data;
    newJobForm.salaryType=value
    this.setData({newJobForm})

  },
   // 公共输入
	getInputVal(e) {
    let id = e.currentTarget.id, 	val = e.detail.value, {newJobForm} = this.data;
    if(id=="salaryMin" || id=="salaryMax"){
      val =val.replace(/[^\d]/g, '').replace(/^0{1,}/g,'');
    }
    if(id=='jobDescription'){
      val = e.detail;
    }
    newJobForm[id] = val;
    this.setData({newJobForm}) 
  },
   

  getAddr(e) {
    if(this.data.loading) return;
    
    gbData('canOnShow',0);

    const flag = e.currentTarget.dataset.disabled;
    if(flag) return
    const userLocation = localData('userLocation') ||  {latitude: 36.43452,longitude: 115.98847}; 
   
    if (userLocation) {
      wx.chooseLocation({  
         ...userLocation,
        success:async res=>{
          console.log('chooseLocation',res)
          let {newJobForm} = this.data, { address,latitude, longitude} = res;
          newJobForm.lat = latitude+'';
          newJobForm.lng = longitude+'';
          newJobForm.address= address;

          let cityRes = await getCityCode(`${latitude},${longitude}`);
          
          if(cityRes){
            let code = cityRes.adcode;
            newJobForm.city = code.substr(0,4)+'00';
          }else{
            msgToast('获取城市编码失败')
          }
          console.log(newJobForm)
          this.setData({newJobForm});
        }
      })
    }
  },
  
  backLeft(){
    wx.reLaunch({
      url: '/pages/index/index',
    })
   },
  async submitForm(){
    let {newJobForm,isEdit,hasInfo } =this.data;
    //工种 城市 地址 待遇
    let {title,industryList,city,jobDescription,address,contactName,salaryType,salaryMin,salaryMax} = newJobForm;
   
    if(empty(title)){
      msgToast('请输入职位名称，限2-40字');
      return
    }
    if(title.length<2){
      msgToast('职位名称限2-40字');
      return
    }
    if(empty(industryList)){
      msgToast('请选择工种，必填');
      return
    }
    
    if(empty(address) || empty(city)){
      msgToast('请设置工作地点');
      return
    }
    if(empty(contactName)){
      msgToast('请输入联系人');
      return
    }
    if(jobDescription && jobDescription.length<15){
      msgToast('职位描述不少于15个字','none',2000);
      return
    }
    
    // 待遇
    salaryMin= salaryMin==null? 0 :salaryMin;
    salaryMax= salaryMax==null? 0 :salaryMax;
      if(salaryType>0 && salaryMin==0 && salaryMax==0){
        msgToast('请设置最低和最高工资')
        return
      }
      if(salaryType>0 && parseInt(salaryMin)>parseInt(salaryMax)){
       
        msgToast('工资数字0-100000之间，最低不大于最高工资')
        return
      }
 
    newJobForm.jobDescription  = tidyBr(newJobForm.jobDescription);
    //转换br
    let content = newJobForm.title+newJobForm.jobDescription;
    let checkRes=null;
    if(isEdit && hasInfo){
      if(this.data.loading) return
      let id = newJobForm.id;
      checkRes = await checkCForEdit(1,id,content);
    } 
    if(checkRes&&checkRes.verifyStatus==1){
      msgToast('信息中含有敏感词，请检查！')
      return
    }
  
    this.setData({newJobForm,loading:true});
     
    if(isEdit && hasInfo){
      refreshJob({...newJobForm}).then(res=>{
        //编辑成功弹窗
        this.openSuccess('编辑招工')
       
      }).catch(err=>{
        msgToast('操作失败')
       
        newJobForm.jobDescription = newJobForm.jobDescription.replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n');
        this.setData({newJobForm});
        
      }).finally(f=>{
        console.log('end')
        this.setData({loading:false});
      })
    }else{
     
      addJob({...newJobForm}).then(res=>{
        //发布成功弹窗
        wxReport('recruit_clickconfirm')
       
        this.openSuccess('发布招工')
      }).catch(err=>{
        msgToast('发布失败','error')
        newJobForm.jobDescription = newJobForm.jobDescription.replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n');
        this.setData({newJobForm});
      }).finally(f=>{
        this.setData({loading:false});
      });
    }
  },
  // 切换tab 设置jobType 人员类型
  tabChange(e){
    let idx = e.currentTarget.dataset.value;
    let {newJobForm} = this.data;
    newJobForm.jobType = idx;
    this.setData({newJobForm,tabActice:idx})
  },
  openSuccess(title){
    wx.setNavigationBarTitle({title});
    this.setData({show2:true,successTit:title});
  },
  sucJump(e){
    let id = e.currentTarget.dataset.id;
    
    if (id=='confirm'){
      wx.navigateTo({
        url: '/pages/user/realname/index',
      })
      return
    }
    wx.navigateTo({
      url: '/pages/user/recruit/index?tabactive=1',
    })
  },
  eventType(){
    let pages = getCurrentPages();
    if(pages.length>=2){
      let {route}  = (pages[pages.length-2]);
      
      if(route.indexOf('index/index')>-1){
        console.log('index_banner_recruit');
        wxReport('index_banner_recruit')
        return
      }
      if(route.indexOf('findworker')>-1){
        wxReport('findworker_clickfindworker_recruit')
        return
      }
      if(route.indexOf('user/user')>-1){
        console.log('user_recruit')
        wxReport('user_recruit')
        return
      }
      if(route.indexOf('task')>-1){
        console.log('task_recruit');
        wxReport('task_recruit')
        return
      }
     //
    }
  },
  async reloadIndus(){
    let {job_industry,job_benifit,work_year,company_scale,company_type,report_type,card_group_total} = await initMetaData();
    if(!empty(job_industry)){
      this.setData({emptyShow:false})
      let indusData = job_industry.map((it,idx)=>{
        let obj = {
          text:it.dictLabel,
          id:it.dictValue,
          badge:null,
          num:0,
          disabled:false
        };
        !empty(it.children) && (obj.children = it.children.map(c=>{
          return {
            idx:idx,
            text:c.dictLabel,
            id:c.dictValue
          }
        }));
        return obj
      });
     msgToast('加载成功')
      localData('indusData',indusData)
    }
    if(!empty(job_benifit)){
      let benifit = formatDict(job_benifit);
      console.log('success')
      this.setData({descArr:benifit})
      localData('benifit',benifit)
    }
    if(!empty(work_year)){
      let yearArr = formatDict(work_year);
      localData('yearArr',yearArr)
    }
    if(!empty(card_group_total)){
      let memArr = formatDict(card_group_total);
      localData('memArr',memArr)
    }
    if(!empty(company_scale)){
      let comSArr = formatDict(company_scale);
      localData('comSArr',comSArr)
    }
    if(!empty(company_type)){
      let comTArr = formatDict(company_type);
      localData('comTArr',comTArr)
    }
    if(!empty(report_type)){
      let reportArr = formatDict(report_type);
      localData('reportArr',reportArr)
    }
  }
})
