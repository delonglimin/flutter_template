import {shopList,transIt,scoreHis,shopOrderAdd } from '../../../api/user'
import { gbData, localData, msgToast,empty, wxReport } from '../../../utils/index';
import {banner} from '../../../api/base'
import Dialog from '@vant/weapp/dialog/dialog';
Page({
  data:{
   
    show:false,
    onType:0,
    goodsArr:[],
    scoreHisArr:[],
    goodsHis:[],
    balance:0,
    loading:false,
    showLoading:false,
    hasMore:true,
    
    sshowLoading:false,
    shasMore:false,
    sloading:false,
    squery:{
      pageNum:1,
      pageSize:10
    },
    query:{
      pageNum:1,
      pageSize:10
    },
 
    scrollH:'',
    curGoods:{
      name:'',
      img:''
    },
    noShip:false,
    showAdr:false,
    shipIdx:"",
    bannerArr:[]
  },
  onLoad(){
    wxReport('shop');

    let wd = gbData('winWidth'), height = 105 * wd / 375;
    this.setData({bannerH:height})
    this.refreshData()
   
    this.loadBanner();
   
  },
  onShow(){
    let addrInfo={},{addrJumpInfo } =this.data;//收货地址返回选择
    let adrArr = localData('adrArr') || [];
    if(!empty(adrArr)){
      if(addrJumpInfo&&addrJumpInfo.receiverPhone){
        addrInfo = addrJumpInfo
      }else{
        let defAdr = adrArr.filter(f=>f.status==1);
        addrInfo = defAdr[0];
      }
      this.setData({addrInfo,noShip:false})
    }else{
      this.setData({addrInfo:{},noShip:true})
    }
  },
 
  onReachBottom(){
    console.log('到底')
    if(!this.data.shasMore  || this.data.sloading) return
    this.setData({sloading:true})
    let num = this.data.squery.pageNum;
    num++;
    this.setData({'squery.pageNum':num})
    this.getAllList()
  },
  adrChange(e){
    let idx = e.detail; 
    this.setData({shipIdx:idx})
  },
  closeAdrDialog(){
    this.setData({showAdr:false})
  },
  addNewAdr(){
    let {noShip,addrInfo} = this.data;
    console.log(noShip,addrInfo)
   
    let id = noShip?-1: addrInfo.id;
 
		wx.navigateTo({
      url: '../../user/addr/index?isorder=1&id='+id,
      fail:f=>{
        console.log(f)
      }
		});
  },
  confirmAdr(){
    let {balance,addrInfo,formerOrder} = this.data;
    let {receiver,receiverPhone,receiveAddress,addressCode,detailAddress} = addrInfo;
    let userInfo = localData('userInfo'),{exchangePrice,id} = formerOrder;
    let contacts = userInfo.name?userInfo.name:userInfo.nickName, contactsPhone=userInfo.tel;

    shopOrderAdd({receiver,receiverPhone,receiveAddress,addressCode,detailAddress,goodsId:id,contacts,contactsPhone,postalcode:''}).then(res=>{
      msgToast('提交成功');
      wxReport('shop_clickeconfirm');
      // 更新缓存
      let num = res.userIntegral;
     
      this.setData({balance:num,yuan:res.banlenceStr})
      userInfo.balance = num;
      gbData('balance',num);
      gbData('yuan',banlenceStr);
      localData('yuan',banlenceStr);
      localData('userInfo',userInfo);

    }).catch(err=>{
      msgToast(err,'none',2000);
    }).finally(f=>{
      this.setData({showAdr:false});
    })
  },
  gotoSign(){
    wx.navigateTo({
      url: '../task/index',
      success:()=>{
        console.log('shop_signdate')
        wxReport('shop_signdate')
      }
    })
  },
  gotoAdr(){
    wx.navigateTo({
      url: '../addr/index',
    })
  },
  
  onPullDownRefresh(){
    this.refreshData()
  },
  refreshData(){
    let balance = gbData('balance') ||0;
    let yuan = gbData('yuan') || '';
    let avatar = localData('userInfo').avator || '../../assets/avatar.gif'
    this.setData({balance,avatar, yuan})
    this.setData({'squery.pageNum':1})
    this.getAllList()
  },
  bannerJump(e){
    let path = e.detail;
    console.log(path)
    wx.navigateTo({
      url: `/pages${path}`,
      success:()=>{
        if(path.indexOf('lottery')>-1){
          wxReport('shop_lottery');
        }
      }
    })
  },
  openPanel(e){
    let type = parseInt(e.currentTarget.dataset.type);
    if(type==1){
      wx.navigateTo({
        url: '/pages/user/orders/index',
      })
      return
    }
    this.setData({onType:type,show:true})
    if(type==0){
      this.getScoreHis()
      return
    } 
   
    
  },
  onClose(){
    this.setData({show:false})
  },
  openTrans(e){
    let {goodsName, id, exchangePrice,goodsImgUrl,goodsStock} = e.currentTarget.dataset.item;
    wxReport('shop_clickexchange');
    if(this.data.balance<exchangePrice){
      console.log(typeof this.data.balance,typeof exchangePrice)
      msgToast('积分不足','error',2000)
      return
    }
    this.setData({showAdr:true,formerOrder:{goodsImgUrl,goodsName, id, exchangePrice,goodsStock}})
  },
  transGood(e){
    let {tansInfo,balance} = this.data,{exchangePrice,id} =tansInfo;
      if(parseInt(balance) < parseInt(exchangePrice)){
        msgToast('积分不足')
        return
      }
      let userInfo =localData('userInfo');
      // 兑换
      transIt({id,exchangePrice,userId:userInfo.id,userName:userInfo.name,userPhone:userInfo.tel,}).then(res=>{
        msgToast('兑换成功','success')
        
        this.setData({showAdr:true})
        let num = parseInt(balance) - parseInt(exchangePrice);
      
        let {goodsName,goodsImgUrl,orderId,banlenceStr} = res;

        this.setData({balance:num,yuan:banlenceStr,formerOrder:{goodsName,goodsImgUrl,id:orderId}})
        userInfo.balance = num;
        gbData('balance',num);
        gbData('yuan',banlenceStr);
        localData('yuan',banlenceStr);
        localData('userInfo',userInfo);
      }).catch(err=>{
        console.log('兑换失败',err)
      })
  },
  //商品
  getAllList(){
    let {squery} =this.data
    shopList(squery).then(res=>{
      wx.stopPullDownRefresh();
      this.setData({sloading:false})
      let {total, rows,banlence,banlenceStr} =res;
      //console.log(banlence,banlenceStr)
      gbData('balance',banlence);
      gbData('yuan',banlenceStr);
      localData('yuan',banlenceStr);
      this.setData({balance:banlence, yuan:banlenceStr})
      rows = rows || [];
      if(squery.pageNum==1){
        this.setData({goodsArr:rows});
        if(rows.length==total){
          total==0? this.setData({sshowLoading:false}): this.setData({sshowLoading:true})
          this.setData({shasMore:false})
          return
        }
      }
      if(squery.pageNum>1){
        if(empty(rows)){
          this.setData({shasMore:false,sshowLoading:true});
          return
        }
        this.setData({goodsArr:this.data.goodsArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.goodsArr.length;
        len<total ? this.setData({shasMore:true}): this.setData({shasMore:false,sshowLoading:true})
      }
     
    }).catch(err=>{
      this.setData({sloading:false})
      wx.stopPullDownRefresh()
    })
  },
  boxscroll(e){
    // console.log(e.detail.direction)
    let {hasMore,showLoading,onType,query} =this.data;
    if(onType==0){
      if(!hasMore || showLoading) return
      this.setData({showLoading:true})
      query.pageNum++;
      this.setData({query});
      this.getScoreHis()
    } 
   
  },
  // 积分明细
  getScoreHis(){
    let userId = localData('userId'),{query}=this.data;
    scoreHis({...query,userId}).then(res=>{
     
      this.setData({loading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query.pageNum==1){
        this.setData({scoreHisArr:rows});
        if(rows.length==total){
          total==0? this.setData({showLoading:false}): this.setData({showLoading:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true});
          return
        }
        this.setData({scoreHisArr:this.data.scoreHisArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.scoreHisArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,showLoading:true})
      }
    }).catch(err=>{
      this.setData({loading:false})
    })
  },
  loadBanner(){
    banner({type:1}).then(res=>{
      this.setData({bannerArr:res.rows})
    })
  }
})