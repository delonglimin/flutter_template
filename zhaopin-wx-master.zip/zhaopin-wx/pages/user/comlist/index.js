import { posted,callList,comEmploy,comJobList } from '../../../api/job.js'
import { empty ,tidyBrBack, localData} from '../../../utils/index'
import { company,msgloglist} from '../../../api/base'
Page({
  data: {
    jobArr:[],
    isSpecil:false,
    query:{
      pageSize: 10,
      pageNum: 1,
    },
    navTitle:'',
    showLoading:false,
    loading:false,
    hasMore:true
  },

 
  onLoad(options) {
    let {title} = options;
    if(title&&title.length){
      this.setData({navTitle:title})
      
      switch (title) {
        case '投递过':
          this.setData({isSpecil:false,curType:0})
          this.getPostedList();
          break;
        case '电话沟通':
          this.setData({isSpecil:false,curType:1})
          this.getCallList();
          break;
        case '谁看过我':
          this.setData({isSpecil:true,curType:2})
          this.getViewList();
          break;
      }
    }
  },
  onReachBottom(){
    
    console.log('到底')
    let {curType,hasMore,loading,query} =this.data;
    if(!hasMore  || loading) return
    this.setData({loading:true})
    query.pageNum++;
     
    this.setData({query})
    if(curType==0){
     this.getPostedList();
      return
    }
    if(curType==1){
      this.getCallList();
      return
    }
    if(curType==2){
      this.getViewList();
    }
  },
  //看过我i
  getViewList(){
    let userId = localData('userId');
    let {query} = this.data;
    msgloglist({userId,msgType:2,...query}).then(res=>{
      this.setData({loading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query.pageNum==1){
        this.setData({jobArr:rows});
        if(rows.length==total){
          total==0? this.setData({showLoading:false}): this.setData({showLoading:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true});
          return
        }
        this.setData({jobArr:this.data.jobArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.jobArr.length;
       
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,showLoading:true})
      }
    })
  },
  //沟通过
  getCallList(){
    let {query} = this.data;
    callList(query).then(res=>{
      this.setData({loading:false})
      let {currentPage,total,rows} =res;
      rows = rows || [];
      if(currentPage==1){
        this.setData({jobArr:rows});
        if(rows.length==total){
          total==0? this.setData({showLoading:false}): this.setData({showLoading:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(currentPage>1){
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true});
          return
        }
        this.setData({jobArr:this.data.jobArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.jobArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,showLoading:true})
      }
    })
  },
  //投递过
  getPostedList(){
    let {query} = this.data;
    posted(query).then(res=>{
      this.setData({loading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query.pageNum==1){
      
        this.setData({jobArr:rows});
        if(rows.length==total){
          console.log(query.pageNum,rows)
          total==0? this.setData({showLoading:false}): this.setData({showLoading:true})
          this.setData({hasMore:false})
          return
        }
      }
     
      if(query.pageNum>1){
      
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true});
          return
        }
        
       this.setData({jobArr:this.data.jobArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.jobArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,showLoading:true})
      }
    }).catch(err=>{
      this.setData({loading:false})
    })
  },
  backLeft(){
    wx.navigateBack({
      delta: 1,
    })
  },
  loadComdetail({detail={}}){
    company({companyId:detail.id}).then(res=>{
      let comInfo = res || {};
      let {welfares,scale,type,summary} =comInfo;
      console.log('scale',scale,'type',type)
      if(!empty(welfares)){
        comInfo.welfares = welfares.split(',')
      }
     
        if(summary){
          comInfo.summary = tidyBrBack(summary)
        }
    
    
        let comTArr=localData('comTArr') || [], comSArr= localData('comSArr') || [];
        let s = comSArr.findIndex(f=>f.value==scale);
        s > -1? comInfo.scaleStr= comSArr[s].name : comInfo.scaleStr='';

        let t = comTArr.findIndex(f=>f.value==type);
        t > -1? comInfo.typeStr= comTArr[t].name : comInfo.typeStr='';

        if(!empty(comInfo.descImages)){
          comInfo.descImages = comInfo.descImages.map(p=>{
            return {
              url:p
            }
          })
        }
        
        //console.log(comInfo.scaleStr,comSArr[s])
        this.setData({comInfo});
        // comjobArr
        this.loadComJobs(comInfo.id)
        this.setData({showComp:true})
        comEmploy({publisherCompanyId:detail.id}).then(res=>{
        
          let num = res.number;
          this.setData({'comInfo.jobnum':num}) 
        })
    })
  },
  loadComJobs(id){
    comJobList({publisherCompanyId:id}).then(res=>{
      //console.log(res)
      this.setData({comjobArr:res || []})
    })
  },
  closeCom(){
    
    this.setData({showComp:false})
  }

})