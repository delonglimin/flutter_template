import { orderHis } from '../../../api/user'
import { empty } from '../../../utils/index'
Page({
 
  data: {
    query:{
      pageNum:1,
      pageSize:10
    },
    gshowLoading:false,
    ghasMore:true,
    gloading:false,
  },

 
  onLoad(options) {
  },
  onShow() {
    this.getOrderHis()
  },
	goDetail(e){
    let id = e.currentTarget.dataset.id;
		wx.navigateTo({
			url: `/pages/user/orders/detail/index?id=${id}`,
			fail:err=>{
				console.log(err)
			}
		})
  }, 
  onReachBottom(){
    console.log('到底')
    let {ghasMore,gshowLoading,query} =this.data;
    if(!ghasMore || gshowLoading) return
    this.setData({gshowLoading:true})
    query.pageNum++;
    this.setData({query});
    this.getOrderHis()
  },
  //兑换记录
  getOrderHis(){
    let {query} =this.data;
    orderHis(query).then(res=>{
    
      this.setData({gloading:false})
      
      let {total,rows} =res,query=this.data.query;
      rows = rows || [];
      if(query.pageNum==1){
        this.setData({goodsHis:rows});
        if(rows.length==total){
          total==0? this.setData({gshowLoading:false}): this.setData({gshowLoading:true})
          this.setData({ghasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({ghasMore:false,gshowLoading:true});
          return
        }
        this.setData({goodsHis:this.data.goodsHis.concat(rows)});
      }
      if(total >0){
        let len = this.data.goodsHis.length;
        len<total ? this.setData({ghasMore:true}): this.setData({ghasMore:false,gshowLoading:true})
      }
    }).catch(err=>{
      this.setData({gloading:false})
    })
  }
})