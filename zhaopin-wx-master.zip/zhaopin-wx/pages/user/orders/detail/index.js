import {localData,empty, msgToast} from '../../../../utils/index'
import {orderUpdate} from '../../../../api/base'

import {orderDetail,logicLog} from '../../../../api/user'
Page({

  data: {
    noShip:false,
    isOpen:false,
		addrInfo:{
      receiver:'',
      receiverPhone:'',
      receiveAddress:'',
      detailAddress:'',
    },
    addrJumpInfo:{
      receiver:'',
      receiverPhone:'',
      receiveAddress:'',
      detailAddress:'',
    },
		logSteps:[ ],
		logActive:0,
    orderInfo:{}
  },
  onLoad(options) {
    let id = options.id;
    if(id){
      this.setData({orderId:id})
      this.loadLogic(id)
      this.loadOrder(id)
    }
    
  },

 
  onShow() {
    console.log('onshow')
    let {orderInfo,addrJumpInfo } =this.data;
    if(orderInfo.id && addrJumpInfo.receiverPhone && orderInfo.status==0){
      console.log('onshow-返回收获地址')
      this.setData({showAdr:true,noShip:false})
    }else{
      if(orderInfo.id){
        let {addrInfo} =this.data;
        for(let key in orderInfo){
          if(addrInfo.hasOwnProperty(key)){
            addrInfo[key] = orderInfo[key]
          }
        }
        addrInfo.receiver? this.setData({noShip:false}) :this.setData({noShip:true});
      }
     
    }
    
	 
  },

  confirmAddr(){
    let {addrJumpInfo,orderInfo} =this.data;
    let userId = localData('userId');
  
    orderUpdate({...addrJumpInfo,id:orderInfo.id,userId}).then(res=>{
      msgToast('操作成功','success')

      this.setData({showAdr:false, noShip:false,addrInfo:addrJumpInfo});
      this.loadOrder(this.data.orderId)
    })
  },
  loadOrder(id){
    orderDetail({orderId:id}).then(res=>{
      let {addrInfo}=this.data;
      for(let key in res){
        if(addrInfo.hasOwnProperty(key)){
          addrInfo[key] = res[key]
        }
      }
      addrInfo.receiver? this.setData({noShip:false}) :this.setData({noShip:true})

      this.setData({orderInfo:res,addrInfo})
      
    })
  },
  toggleBox(){
    this.setData({isOpen:!this.data.isOpen})
  },
	addNewAdr(){
    let {noShip,addrInfo,orderInfo} = this.data;
   
    if(orderInfo.status>0) return;
    let id = noShip?-1: addrInfo.id;
		wx.navigateTo({
			url: '../../addr/index?isorder=1&id='+id,
		})  
  },
 
  copyOrderNum(){
    let {orderInfo} = this.data;
    if(orderInfo && orderInfo.expressNum){
      wx.setClipboardData({
        data: orderInfo.expressNum,
        success:res=>{
          //msgToast('复制成功')
        }
      })
    }
  },

  loadLogic(id){
    logicLog({orderId:id}).then(res=>{
      console.log(res)
      let list = res.logisticsDetailRspList;
      list = list.map(m=>{
        return {
          text:m.content,
          desc:m.formatTime
        }
      });
      this.setData({logSteps:list})
    })
  }
})