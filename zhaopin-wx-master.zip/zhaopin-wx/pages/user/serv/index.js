// pages/serv/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  callServ(e){
    let id = e.currentTarget.id;
    console.log(e)
    if(id==1){
      wx.makePhoneCall({
        phoneNumber: '18865123690',
      });
    }else{
      // wx.openCustomerServiceChat({
      //   extInfo: {url: 'https://work.weixin.qq.com/kfid/kfc2cc844e3a961c9e6'},
      //   corpId: 'ww9fc9be675b2571b4',
      //   success(res) {}
      // })
    }
  }
})