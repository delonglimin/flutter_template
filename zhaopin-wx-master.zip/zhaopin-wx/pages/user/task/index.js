
import {taskList} from '../../../api/user'
import { localData, wxReport } from '../../../utils/index'
Page({
  data:{
    taskArr:null
  },
  onLoad(){
    
  },
  onShow(){
    this.getList()
  },
  goTask(e){
    // 任务类别：0-查看职位；1-查看工人；2-查看零工；3-完善名片；4-发布岗位；5-分享培训视频；6-实名认证 7-签到；
    let type = e.detail.type,url='';
    switch (type) {
      case 0:
        url= '/pages/findjob/findjob';
        wxReport('task_findjob');
        break;
      case 1:
        url='/pages/findworker/findworker?pageIndex=1&type=1';
        wxReport('task_findworker');
        break;
      case 2:
        url='/pages/shortterm/shortterm?pageIndex=0&type=0'
         break;
      case 3:
        url='/pages/user/mycard/index?pageIndex=2';
        wxReport('task_mycard')
        break;
      case 4:
        url='/pages/user/recruit/add/index?pageIndex=2&type=0'
         break;
      case 5:
        url='/pages/training/training?shareflag=1';
        wxReport('task_training')
         break;
      case 6:
        url='/pages/user/realname/index?pageIndex=2';
        
         break;
      case 7:
        url='/pages/user/signdate/index'
        wxReport('task_signdate');
        break;
    }
    if(type<=1){
      wx.switchTab({url: url})
    }else{
      wx.navigateTo({url: url})
    }
    
  },
  getList(){
    let userId = localData('userId')
    taskList({userId:userId}).then(res=>{
      res.map(item=>{
        if(item.type==3){
          item.icon = 'card'
        }else if(item.type==4){
          item.icon= 'edit'
        }else if(item.type==5){
          item.icon= 'share2'
        }else if(item.type==7){
          item.icon='sign'
        }else {
          item.icon= 'eye'
        }
      })
      this.setData({taskArr:res})
      console.log(res)
    })
  }
})