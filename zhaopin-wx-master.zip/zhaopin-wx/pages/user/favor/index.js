import {favJobs,favCardT,favCardW} from '../../../api/user'
import {removeFav} from '../../../api/job'
import { empty, msgToast,localData } from '../../../utils/index';
import Dialog from '@vant/weapp/dialog/dialog';

Page({
  data:{
    tabActive:0,
    fixtopheight:0,

    showLoading:false,
    loading:false,
    hasMore:false,
    jobArr: [],

    showTLoading:false,
    tloading:false,
    thasMore:false,
    teamArr: [],

    showWLoading:false,
    wloading:false,
    whasMore:false,
    workerArr: [],

    query:{
      type:1,
      
      pageNum:1,
      pageSize:10,
    },
    query2:{
      type:2,
     
      pageNum:1,
      pageSize:10,
    },
    query3:{
      type:3,
      
      pageNum:1,
      pageSize:10,
    }
  },
  onLoad(){
    this.getfavJobsList();
    this.getfavCardWList();
    this.getfavCardTList();
  },

  onReachBottom(){
    console.log('到底')
    let {tabActive,query,query2,query3,hasMore,whasMore,thasMore} = this.data;
    if(tabActive==0){
      if(this.data.loading || !hasMore) return
      query.pageNum++
      this.setData({query,loading:true})
      this.getfavJobsList();
      return
    }
    if(tabActive==1){
      if(this.data.wloading || !whasMore) return
      query2.pageNum++
      this.setData({query2,wloading:true})
      this.getfavCardWList();
      return
    }
    if(tabActive==2){
      if(this.data.tloading || !thasMore) return
      query3.pageNum++
      this.setData({query3,tloading:true})
      this.getfavCardTList();  
    }
  },
  deleteFav({detail={}}){
    let {index,type,relationId} = detail;
    Dialog.confirm({
      title: '提示',
      message: '您确认要取消收藏吗？',
      zIndex:10000
    }).then(() => {
      removeFav({type,relationId}).then(res=>{
        msgToast('删除成功','success')
        if(type==1){
          //job
          let {jobArr} =this.data;
          jobArr.splice(index,1);
          this.setData({jobArr})
          if(empty(jobArr)){
            this.setData({showLoading:false})
          }
          return
        }
        if(type==2){
          //工人
          let {workerArr} =this.data;
          workerArr.splice(index,1);
          this.setData({workerArr})
          if(empty(workerArr)){
            this.setData({showWLoading:false})
          }
          return
        }
       
        //班组
        let {teamArr} =this.data;
        teamArr.splice(index,1);
        this.setData({teamArr})
        if(empty(teamArr)){
          this.setData({showTLoading:false})
        }
      }).catch(err=>{
        msgToast('删除失败','error')
      })
    }).catch(err=>{
      
    })
   
  },
  getfavJobsList(){
    let {query} =this.data;
    favJobs(query).then(res=>{
      console.log(res)
      this.setData({loading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query.pageNum==1){
         
        this.setData({jobArr:rows});
        if(rows.length==total){
          total==0? this.setData({showLoading:false}): this.setData({showLoading:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true});
          return
        }
        this.setData({jobArr:this.data.jobArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.jobArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false})
      }
      
    }).catch(err=>{
      this.setData({loading:false}) 
    })
  },
 
  getfavCardWList(){
    let {query2} =this.data;
    favCardW(query2).then(res=>{
      this.setData({wloading:false})
      let {total,rows} =res;
      rows = rows || [];
      let yearArr = localData('yearArr');
      if(!empty(rows) && !empty(yearArr)){
        rows.map(m=>{
          let has = yearArr.filter(f=>f.value== m.data.workDate);
          if(!empty(has)){
            m.data.workDateStr =  has[0].name;
          }
        })
      }

      if(query2.pageNum==1){
      
        this.setData({workerArr:rows});
        if(rows.length==total){
          total==0? this.setData({showWLoading:false}): this.setData({showWLoading:true})
          this.setData({whasMore:false})
          return
        }
      }
      if(query2.pageNum>1){
        if(empty(rows)){
          this.setData({whasMore:false,showWLoading:true});
          return
        }
        this.setData({workerArr:this.data.workerArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.workerArr.length;
        len<total ? this.setData({whasMore:true}): this.setData({whasMore:false})
      }
    }).catch(err=>{
      this.setData({wloading:false})
    })
  },
  getfavCardTList(){
    let {query3} =this.data;
    favCardT(query3).then(res=>{
      this.setData({tloading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query3.pageNum==1){
        this.setData({teamArr:rows});
        if(rows.length==total){
          total==0? this.setData({showTLoading:false}): this.setData({showTLoading:true})
          this.setData({thasMore:false})
          return
        }
      }
      if(query3.pageNum>1){
        if(empty(rows)){
          this.setData({thasMore:false,showTLoading:true});
          return
        }
        this.setData({teamArr:this.data.teamArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.teamArr.length;
        len<total ? this.setData({thasMore:true}): this.setData({thasMore:false})
      }
    }).catch(err=>{
      this.setData({tloading:false})
    })
  },
  getlistFilter(e){
    let type = e.target.dataset.type
    this.setData({tabActive:type})
  }
})
