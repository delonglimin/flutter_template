import {historyLog} from '../../../api/job'
import {formatSalary,empty} from '../../../utils/index'
Page({
  data:{
    tabActive:0,
    fixtopheight:0,

    showLoading:false,
    loading:false,
    hasMore:true,
    jobArr: [],

    showTLoading:false,
    tloading:false,
    thasMore:true,
    teamArr: [],

    showWLoading:false,
    wloading:false,
    whasMore:true,
    workerArr: [],

    query:{
      type:1,
      pageNum:1,
      pageSize:10,
    },
    query2:{
      type:0,
      cardType:0,
      pageNum:1,
      pageSize:10,
    },
    query3:{
      type:0,
      cardType:1,
      pageNum:1,
      pageSize:10,
    }
  },
  onLoad(){
    this.getJobsList();
   
    this.getCardWList(); 
    this.getCardTList();
  },
  onReachBottom(){
    console.log('到底')
    let {tabActive,query,query2,query3,hasMore,whasMore,thasMore} = this.data;
    if(tabActive==0){
      if(this.data.loading || !hasMore) return
      query.pageNum++
      this.setData({query,loading:true})
      this.getJobsList();
      return
    }
    if(tabActive==1){
      if(this.data.wloading || !whasMore) return
      query2.pageNum++
      this.setData({query2,wloading:true})
      this.getCardWList();
      return
    }
    if(tabActive==2){
      if(this.data.tloading || !thasMore) return
      query3.pageNum++
      this.setData({query3,tloading:true})
      this.getCardTList();  
    }
  },
  getJobsList(){
    let {query} =this.data;
    historyLog(query).then(res=>{
     
      this.setData({loading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(!empty(rows)){
        rows.map(m=>{
          
          let {salaryType,salaryMax,salaryMin} = m.jobBo;
         
          m.jobBo.salary = formatSalary(salaryType,salaryMax,salaryMin,1)
          
        })
      }
     
      if(query.pageNum==1){
       
        this.setData({jobArr:rows});
        if(rows.length==total){
          total==0? this.setData({showLoading:false}): this.setData({showLoading:true})
          this.setData({hasMore:false})
          return
        }
      }
      if(query.pageNum>1){
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true});
          return
        }
        this.setData({jobArr:this.data.jobArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.jobArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,showLoading:true})
      }
      
    }).catch(err=>{
      this.setData({loading:false}) 
    })
  },
 
  getCardWList(){
    let {query2} =this.data;
    historyLog(query2).then(res=>{
      this.setData({wloading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query2.pageNum==1){
      
        this.setData({workerArr:rows});
        if(rows.length==total){
          total==0? this.setData({showWLoading:false}): this.setData({showWLoading:true})
          this.setData({whasMore:false})
          return
        }
      }
      if(query2.pageNum>1){
        if(empty(rows)){
          this.setData({whasMore:false,showWLoading:true});
          return
        }
        this.setData({workerArr:this.data.workerArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.workerArr.length;
        len<total ? this.setData({whasMore:true}): this.setData({whasMore:false,showWLoading:true})
      }
    }).catch(err=>{
      this.setData({wloading:false})
    })
  },
  getCardTList(){
    let {query3} =this.data;
    historyLog(query3).then(res=>{
      this.setData({tloading:false})
      let {total,rows} =res;
      rows = rows || [];
      if(query3.pageNum==1){
        this.setData({teamArr:rows});
        if(rows.length==total){
          total==0? this.setData({showTLoading:false}): this.setData({showTLoading:true})
          this.setData({thasMore:false})
          return
        }
      }
      if(query3.pageNum>1){
        if(empty(rows)){
          this.setData({thasMore:false,showTLoading:true});
          return
        }
        this.setData({teamArr:this.data.teamArr.concat(rows)});
      }
      if(total >0){
        let len = this.data.teamArr.length;
        len<total ? this.setData({thasMore:true}): this.setData({thasMore:false,showTLoading:true})
      }
    }).catch(err=>{
      this.setData({tloading:false})
    })
  },
  getlistFilter(e){
    let type = e.target.dataset.type
    this.setData({tabActive:type})
  }
})
