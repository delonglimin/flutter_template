import { localData, empty, loginCtrl, gbData ,msgToast,randomStr,wxReport} from '../../utils/index'
import {upDateUser} from '../../api/user'
import {historyNum} from '../../api/job'
import {findJob,findworker,moreServ,scores} from '../../utils/static'
import {getUserInfo,msgInfo} from '../../utils/getData'
Page({
  data: {
    viewHisNum:0,
    findJob,
    findworker,
    moreServ,
    scores,
    islogin: false,
    userInfo: localData('userInfo')||{},
    show: false,
    birthday:'',
    selfInfo: {
      avator:'',
      nickName:'',
      gender: 0,
      name: '',
      tel: '',
      birthday: '',
      birthdayTs:null,//时间戳
      verifyStatus:null
    },
    currentDate: null, //时间戳
    minDate: null,
    maxDate: null,
    formatter(type, value) {
      
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      if (type === 'day') {
        return `${value}日`;
      }
      return value;
    },
    showPicker: false,
    canOnShow:1,
  },
  onLoad(){
    const dates = new Date();
    const year = dates.getFullYear(),day=dates.getDate(),month=dates.getMonth();
    let minYear = year-80,maxYear =year-18;
    
    this.setData({
      minDate: new Date(minYear, month, day).getTime(),
      maxDate: new Date(maxYear, month, day).getTime(),
    })
  },
  async onShow(){
   
    let canOnShow = this.data.canOnShow;
    if(canOnShow==0) {
      this.setData({canOnShow:1})
      return
    }
    // 消息未读数
    let pages = getCurrentPages();
    if(!pages[pages.length - 2] && localData('token')){
      this.getMsgNum()
    }
    let id = localData('userId');
    if(id){
      let data =await getUserInfo(id)
      
      if(!empty(data)){
        this.setData({userInfo:data})
        this.setData({islogin:true})
        this.gethistoryNum();
        this.initDataUser();
      }else{
        // console.log('onShow')
        // wx.clearStorageSync();
        // wx.redirectTo({
        //   url: '/pages/user/login/index',
        // })
      }
    }
  },
  onTabItemTap(e){
    let unread = gbData('unread') || 0;
    if(unread>0){
      wx.setTabBarBadge({
        index: 3,
        text: unread.toString(),
      })
    }else{
      wx.removeTabBarBadge({
        index: 3,
      })
    }
  },
  initDataUser(){
    let {userInfo,selfInfo,birthday,currentDate}=this.data;
    
    for(let key in userInfo){
      if(selfInfo.hasOwnProperty(key)){
        selfInfo[key]=userInfo[key];
        if(key =='gender'){
          selfInfo.gender = userInfo[key]+''
        }
        
        if(key =='birthdayTs'){
          if(userInfo['birthdayTs']){
         
            currentDate =userInfo['birthdayTs'];
            selfInfo['birthday'] = this.timeFormat(userInfo['birthdayTs']);
           
          }else{
            selfInfo['birthday'] ='请设置'
            currentDate = new Date().getTime()
          }
        }
      }
    }
    this.setData({selfInfo,currentDate})
  },
 
  async onPullDownRefresh(){
    let userInfo = localData('userInfo');
    if(userInfo.id){
      let data =await getUserInfo(userInfo.id);
      if(!empty(data)){
        this.setData({userInfo:data})
        this.setData({islogin:true})
        this.gethistoryNum();
        this.initDataUser();
        wx.stopPullDownRefresh();
      }
    }
    //wx.stopPullDownRefresh();
    
  },
  gethistoryNum(){
    historyNum({}).then(res=>{
      let num = res.statistics;
      this.setData({viewHisNum:num})
    }).catch(err=>{
      console.log(err)
    })
  },
  setOnshow(){
    this.setData({canOnShow:0})
    gbData('canOnShow',0)
  },
  onChooseAvatar(e){
 
    const { avatarUrl } = e.detail 
   // https://upload.eqianhuo.com/oss/file/upload
    wx.uploadFile({
      url: `https://upload.eqianhuo.com/oss/file/upload`,
      filePath: avatarUrl,
      name: 'file',
      success: async(res) => {
       
        let resdata = JSON.parse(res.data)
        let rst = resdata.data;
        let proName = this.data.userInfo.id+'avator';
        
        if (rst.downloadUrl) {
          console.log(rst.downloadUrl)
          this.setData({'selfInfo.avator':rst.downloadUrl})
          //保存
          // saveFile({ moduleKey: 'wx_user_avator', itemKey:randomStr(), proName, proUrl: rst.downloadUrl}).then((imgRes) => {
            
          //   this.setData({'selfInfo.avator':imgRes.proUrl})
          // }).catch((err) => {
          //   console.log(err)
          // })
        }
      },fail:err=>{
        console.log('上传失败',err)
      }
    });
  },
  jumpPath(e){
    if(!loginCtrl(true)) return

    let type = e.currentTarget.dataset.type,url='';
    console.log(type)
    if(type==1){
      url='/pages/user/favor/index'
    }
    if(type==2){
      url='/pages/user/history/index'
    }
    if(type==3){
      url='/pages/user/shop/index'
    }
    wx.navigateTo({url})
  },
  //菜单按钮跳转
  async menuJump(e){
   let f= loginCtrl(true);
   if(!f) return
    let {path,name} = e.detail;
    
    if(name =='刷新名片'){
      wx.switchTab({
        url: '../findjob/findjob',
      })
     
      return
    }
    wx.navigateTo({
      url:`.${path}?title=${name}`,
      success:()=>{
        if(path.indexOf('lottery')>-1){
          console.log('lottery')
          wxReport('user_lottery');
          return
        }
        if(path.indexOf('shop')>-1){
          console.log('user_shop')
          wxReport('user_shop');
          return
        }
        //
        if(path.indexOf('task')>-1){
          console.log('task')
          wxReport('user_task');
          return
        }
        if(path.indexOf('signdate')>-1){
          console.log('user_signdate')
          wxReport('user_signdate');
          return
        }
        //
      }
    })
  },
  // 修改生日
  setDate(e) {
    let timStr = e.detail;
   
    let birthday = this.timeFormat(timStr);
    console.log('birthday',birthday,timStr)
    this.setData({
      currentDate:timStr,
      birthday,
      'selfInfo.birthday':birthday,
      showPicker: false
    })
  },
  // 保存个人信息修改
  saveInfo() {
    let openid = localData('openid') || '',{selfInfo,currentDate,userInfo}=this.data;
    delete selfInfo.birthdayTs;
   
    let {nickName} = selfInfo;
    if(nickName&&nickName.length<2){
      msgToast('昵称不少于2个字')
      return
    }
 
    let data = {openid,...selfInfo};
    data.birthday= this.timeFormat(currentDate);;
    
   // console.log(Object.assign(userInfo,data))

    upDateUser(data).then(res=>{
      let newUserInfo = Object.assign(userInfo,data);
      localData('userInfo',newUserInfo);
      msgToast('保存成功','success')
      this.setData({
        show: false,
        userInfo:newUserInfo
      })
      wx.showTabBar()
    })
    
  },
  timeFormat(e) {
    let year = new Date(e).getFullYear();
    let month = new Date(e).getMonth() + 1;
    let day = new Date(e).getDate();
   
    month = month>=10? month : '0'+month;
    day = day>=10? day : '0'+day;
    return year + '-' + month + '-' + day
  },
  closePicker() {
    this.setData({
      showPicker: false
    })
  },
  openPicker() {
    this.setData({
      showPicker: true
    })
  },
  openDetail() {
    if(!loginCtrl(true)) return
    this.setData({ show: true })
    this.initDataUser();
    wx.hideTabBar()
  },
  closePop() {
    this.setData({
      show: false
    })
    wx.showTabBar()
  },
  radioChange(e) {
    let gender = e.detail;
    this.setData({'selfInfo.gender':gender})
  },
  async getMsgNum(){
    let {unread} =  await msgInfo();
    gbData('unread',unread);
    localData('unread',unread)
    unread>0 ? wx.setTabBarBadge({index: 3,text: unread.toString()}) : wx.removeTabBarBadge({index: 3})
  },
  // 进入实名认证页面
  goRealName(){
    wx.navigateTo({
      url: '/pages/user/realname/index'
    })
  },
  getNickname(e){
    let name =  e.detail.value;
    this.setData({'selfInfo.nickName':name});
  },
  getInputVal(e) {
    let id = e.currentTarget.id, 	val = e.detail.value, { selfInfo} = this.data;
    selfInfo[id] = val;
    this.setData({selfInfo})
  },
  callReport(e){
    let call = e.currentTarget.dataset.tel;
    wx.makePhoneCall({
      phoneNumber: call,
      fail:err=>{
        msgToast(err)
      }
    })
  }
})
