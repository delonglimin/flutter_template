// pages/training.js
import {originallv2} from '../../api/base'

import {trainList,trainlog} from '../../api/user'
import { gbData } from '../../utils/index';
Page({
  data: {
    active:0,
    lev2_active:null,
    trainMenu:[
      {title: '热门推荐', id:0},
      {title: '技能培训', id:1},
      {title: '培训规范', id:2},
      {title: '政策法规', id:3},
      {title: '健康培训', id:4}
    ],
    listArr:[],
    isTask:false,
    query:{
      trainingType:null,// 0-图文 1-视频 为空代表不所有
      pageNum:1,
      pageSize:10,
      isRecommend:0, //1-未推荐 0-已推荐
      oneClassifyId:null,
      twoClassifyId:null,
      publishStatus:0
    },
    loading:false,
    hasMore:false,
    loading:false,
    itemWidth:0,
    itemHeight:0,
    videoHeight:0,
  },
 
  onLoad (o) {
    let {shareflag} = o;
    if(shareflag==1){
      this.setData({isTask:true})
    }else{
      this.setData({isTask:false})
    }
    this.getList()
  },

  onReady () {
   
  },

  onShow () {
   let {fromDetail,listArr}=this.data;
   if(fromDetail && fromDetail.id){
    console.log('onshow', fromDetail)
    let {id,readTotal} = fromDetail,{listArr}=this.data;
      let idx = listArr.findIndex(f=>f.id==id);
      if(idx>-1){
        listArr[idx].readTotal = parseInt(readTotal)+1;
        this.setData({listArr});
      }

   }
    this.setData({coverImgUrl:''})
  },
 
  lev2Click(e){
    let idx = e.currentTarget.dataset.index;
    this.setData({lev2_active:idx});
    let id = this.data.menuArr[idx].dictValue;
    this.setData({'query.twoClassifyId':id });
    this.getList()
  },
  getlev2Nav(id){
    originallv2({dictType:'training_classify',parent:id}).then(res=>{
      let data = res || [];
      if(data){
        let id = data[0].dictValue;
        this.setData({'query.twoClassifyId':id,lev2_active:0});
        this.getList()
      }
      this.setData({menuArr:res})
    })
  },
  goToDetail(e){
    let item =e.currentTarget.dataset.data,{listArr}=this.data;
    let {id,trainingType,title} = item;
    if(trainingType) return;
    let flag = this.data.isTask===true? 1 : 0;
    
    wx.navigateTo({
      url: `/pages/training/detail/index?id=${id}&title=${title}&isTask=${flag}`,
      // success:()=>{
     
      // }
    })
  },
  playVideo(e){
    let id = e.currentTarget.dataset.id,{listArr}=this.data;
    let idx = listArr.findIndex(f=>f.id==id);
    if(idx>-1){
      
      listArr[idx].readTotal = parseInt(listArr[idx].readTotal)+1;
      this.setData({listArr});
       
    }
    trainlog({trainingId:id,trainingType:1}).then(res=>{});
  },
  shareTarget(e){
     
    let {title,coverImgUrl} = e.detail.currentTarget.dataset.detail;
    
    this.setData({coverImgUrl:coverImgUrl})
     
  },
  scrollPage () {
    if(!this.data.hasMore  || this.data.loading) return
    this.setData({loading:true})
    let num = this.data.query.pageNum;
    num++;
    this.setData({'query.pageNum':num})
    this.getList()
  },
 
  onShareAppMessage(options){
    let {title,coverImgUrl} =options.target.dataset.detail;
    return {
      title:title,
      path: `/pages/training/training`,
      imageUrl:coverImgUrl
    }
  },
  onShareTimeline(o){
    let {coverImgUrl} =this.data;
    console.log(coverImgUrl)
  
    return {
      title:'仟活培训',
      path: ``,
      imageUrl:coverImgUrl
    }
  },
  tabChange(e){
    console.log(e)
    let active = e.currentTarget.dataset.index;
    let id = this.data.trainMenu[active].id;
    let {query}=this.data;
    query.pageNum=1;
    if(active>0){
      this.setData({query})
      this.getlev2Nav(id)
    }else{
      query.twoClassifyId=null;
      query.isRecommend=0;
      this.setData({query})
      this.getList()
    }
    
    this.setData({active});
 
  },

  getList(){
    let {query} =this.data;
    trainList(query).then(res=>{
      this.setData({loading:false})
      let {total,rows,currentPage} = res;
      if(currentPage==1){
        this.setData({listArr: rows || []})
        if(rows.length == total){ 
          this.setData({hasMore:false})
          total==0?this.setData({showLoading:false}):this.setData({showLoading:true})
          return
        };  
      }
      if(currentPage>1){
        
        this.setData({listArr: this.data.listArr.concat(rows)})
      }
      if(total >0){
        let len = this.data.listArr.length;
        len<total? this.setData({hasMore:true}) : this.setData({hasMore:false})
      }else{
        this.setData({hasMore:false})
      }
         
   
    }).catch(err=>{
      this.setData({loading:false})
    })
  }
})