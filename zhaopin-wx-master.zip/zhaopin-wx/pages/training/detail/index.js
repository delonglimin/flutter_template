import {trainDetail} from '../../../api/base'
import {trainList,trainlog} from '../../../api/user'
import{sharelog}from '../../../api/job'
import {formatRichText,msgToast,localData} from '../../../utils/index'

Page({
  data: {
    targetId:null,
    isTask:false,
    videoContext:null,
    title:'',
    htmlSnip:'',
    detailInfo:{},
    query:{
      trainingType:null,// 0-图文 1-视频 为空代表不所有
      pageNum:1,
      pageSize:10,
      isRecommend:0, //0-未推荐 1-已推荐
      oneClassifyId:null,
      twoClassifyId:null,
      publishStatus:0
    },
    listArr:[],
    id:null
  },
  onLoad (options) {
    let {id,title,isTask} = options;
 
    if(title&&title.length) {
      wx.setNavigationBarTitle({title});
      
    }
    // 分享任务 flag
    isTask==1? this.setData({isTask:true}) :this.setData({isTask:false});
    if(id) {
      this.setData({targetId:id});
      this.getDetail(id);
      this.addTrainLog(id,0);
    }
    // 内容类型
    this.setData({id,title})
  },

 
  onReady() {
    //this.videoContext = wx.createVideoContext('myVideo')
  },
 
  onShow() {
 
  },
  onUnload(){
    let pages = getCurrentPages();
    let prevPage = pages[pages.length - 2];
    prevPage.setData({
      fromDetail:{
        id:this.data.targetId,
        readTotal:this.data.detailInfo.readTotal
      }
    });
  },
  onShareAppMessage(options){
    let {title,id} =this.data;
    console.log(title,id)
    this.addShareLog()
    return {
      title:title,
      path: `/pages/training/detail/index?id=${id}&title=${title}&isTask=1`,
      imageUrl:''
    }
  },
  onShareTimeline(){
    let {title,id} =this.data;
    console.log(title)
    this.addShareLog()
    return {
      title:title,
      path: `id=${id}&title=${title}`,
      imageUrl:''
    }
  },
  addShareLog(){
    let userid = localData('userInfo').id;
    // shareType  0-分享职位 1-分享培训视频 2-其它.  shareContentId
    sharelog({userId:userid,shareType:1,shareContentId:this.data.id}).then(res=>{
      msgToast('分享培训成功','success')
    })
  },
  addTrainLog(trainingId,trainingType){
    trainlog({trainingId,trainingType}).then(res=>{
      
    })
  },
  getDetail(id){
    trainDetail({id}).then(res=>{
      this.setData({detailInfo:res})

      let content = formatRichText(res.content);
      this.setData({htmlSnip:content})
    })
  },
  getList(){
    let {query} =this.data;
    trainList(query).then(res=>{
      console.log(res.rows)
      this.setData({listArr:res.rows})
    })
  }
})