import {msgViewed } from '../../../api/job';
import {msgloglist} from '../../../api/base';
import {msgCard } from '../../../api/user';

Page({
  data: {
    listArr:[],
    curType:0,
    hasMore:false,
    loading:false,
    show:false,
    query:{
      pageNum:1,
      pageSize:10
    },
    cquery:{
      pageNum:1,
      pageSize:10
    }
  },
  onLoad(options) {
 
    this.setData({listArr:[]})
    let {type,title,msgid} = options;
    type = Number(type)
    this.setData({curType:type})
    wx.setNavigationBarTitle({title})
   
    if(type==4){
      this.systMsg(msgid,type)
    }
    if(type==1){
      //审核
      this.getCheckMsg();
    }
    if(type==0){
      //名片投递
      this.getCard()
    }
  },
  onReady() {

  },
  onShow() {

  },
  systMsg(id,msgType){
    
    msgloglist({id,msgType}).then(res=>{
     let list = res.rows;
     this.setData({listArr:list})
    })
  },
  getCard(){
    let {query} =this.data;
    msgCard(query).then(res=>{
      let {total,rows} = res;
      rows = rows || [];
      this.setData({loading:false})
      if(query.pageNum==1){
        this.setData({listArr: rows || []});
        if(rows.length == total){
          total==0?this.setData({show:false}):this.setData({show:true})
          this.setData({hasMore:false});
        }
        console.log(this.data.hasMore)
        return
      }
      if(query.pageNum>1){
       
        this.setData({listArr: this.data.listArr.concat(data)})
      }
      if(total >0){
        let len = this.data.listArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,show:true})
      }
    }).catch(err=>{
      console.log(err)
      this.setData({loading:false})
    })
  },
  onReachBottom(){
    console.log('到底')
    let {curType,query} = this.data;
   
    if(!this.data.hasMore  || this.data.loading) return
    this.setData({loading:true})
    query.pageNum++;
    this.setData({query})
    if(curType==1){
      this.getCheckMsg()
      return
    }
    if(curType==0){
      this.getCard()
      return
    }
  },
  onHide() {

  },
  onUnload() {

  },
  getCheckMsg(){
    let query =this.data.query;
    msgViewed(query).then(res=>{
     
      let {total,rows} = res;
      rows = rows || [];
      this.setData({loading:false})
      if(query.pageNum==1){
        console.log(rows)
        this.setData({listArr: rows});
        if(rows.length == total){
          total==0?this.setData({show:false}):this.setData({show:true})
          this.setData({hasMore:false});
        }
        return
      }
      if(query.pageNum>1){
        this.setData({listArr: this.data.listArr.concat(data)})
      }
      if(total >0){
        let len = this.data.listArr.length;
        len<total ? this.setData({hasMore:true}): this.setData({hasMore:false,show:true})
      }
    }).catch(err=>{
      this.setData({loading:false})
    })
  },
  
})