 
import { msgInfo } from "../../utils/getData";
import {clearMsg } from '../../api/user'
import {empty, loginCtrl,gbData, localData} from '../../utils/index'
Page({
  data: {
    msgList:[],
  },
  onLoad(){
    
  },
  onShow(){
    if(!loginCtrl(true)) return
   
    this.getList()
  },
  onPullDownRefresh(){
    if(!loginCtrl()) return
    this.getList()
  },
  async getList(){
    let {data,unread} =  await msgInfo();
    gbData('unread',unread);
    localData('unread',unread);
    if(unread>0){
      wx.setTabBarBadge({
        index: 3,
        text: unread.toString(),
      })
    }else{
      wx.removeTabBarBadge({
        index: 3,
      })
    }

   if(empty(data)){
      let msgList =[{
        id:null,
        msgCount:0,
        updateTime:null,
        msgTitle:'暂无消息',
        typeName :'名片投递',
        
        icon:'/pages/assets/message/cardup.svg'
      },
     {
      id:null,
      msgCount:0,
      updateTime:null,
      msgTitle:'暂无消息',
       typeName : '审核通知',
      icon : `/pages/assets/message/auditnotice.svg`
      },
     {
      id:null,
      msgCount:0,
      updateTime:null,
      msgTitle:'暂无消息',
        typeName :'谁看过我',
        icon : `/pages/assets/message/wholookme.svg`
      },
     {
      id:null,
      msgCount:0,
      updateTime:null,
      msgTitle:'暂无消息',
        typeName : '培训通知',
        icon : `/pages/assets/message/trainnotion.svg`
      },
      {
        id:null,
        msgCount:0,
        updateTime:null,
        msgTitle:'暂无消息',
        typeName:'系统通知',
        icon:'/pages/assets/message/systemnotion.svg'
      }]
      this.setData({msgList})
      return
   }
   this.setData({msgList:data});
   
    
  },
  goMsgList(e){
   
    let {msgList} = this.data;
    let {type,title,id,idx} = e.currentTarget.dataset;
    if(id==null) return

    let unread = localData('unread');
    unread=parseInt(unread);
    // isRead 0 -未读   1 已读
    let curNum= parseInt(msgList[idx].msgCount);
    if(curNum>0){
      this.changeUnRead(id,type).then(res=>{
        let x =unread-curNum;
        unread= x>=0? x :0
        localData('unread',unread)
        if(unread>0){
          wx.setTabBarBadge({index: 3,text: unread.toString()});
        }else{
          wx.removeTabBarBadge({index:3})
        }
        msgList[idx].msgCount=0;
        msgList[idx].isRead=1;
        localData('msgList',msgList);
        this.setData({msgList})
      })
    }
 
  
    if(type==2){
      wx.navigateTo({
        url: `/pages/user/comlist/index?title=谁看过我&msgtype=2&msgid=${id}`,
      })
      return
    }
    // 培训
    if(type==3){
      console.log(333)
      wx.navigateTo({
        url: `/pages/training/training`,
        fail:err=>{
          console.log(err)
        }
      })
      return
    }
     
    wx.navigateTo({
      url: `/pages/message/cardup/index?type=${type}&title=${title}&msgid=${id}`,
    })
  },
  changeUnRead(id,type){
    return new Promise((resolve,reject)=>{
      clearMsg({id,msgType:type}).then(res=>{
        resolve(res)
      }).catch(err=>{
        reject(err)
      })
    });
    
  }
})
