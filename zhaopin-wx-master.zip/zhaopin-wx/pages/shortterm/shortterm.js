 

import {jobs,updateFindJob,getFindStatus,dayFresh,doFresh} from '../../api/job'
import {initMetaData,formatDict} from '../../utils/getData'
import { empty, gbData,loginCtrl,formatCity,localData, msgToast  } from '../../utils/index';
import {areaList} from '../../utils/citylist'
let scrollTime = null;
Page({
  data: {
    freshNumber:1,
    floatStatus:false,
    emptyShow:false,
    placeholder:'',
    indusNum:0,
    showDropdownMenu:false,
    canStatus:0,
    cardStatus:gbData('cardStatus')||{},
    realName:false,
    indusTitle:'工种',
    indusActiveIndex: 0,
    indusActiveId: [],
    indusMax:3,
    indusArr:[],
 
    orginActiveId: [],
    orginTitle:"地区",
    orginmax:1,
    orginArr:[],
    orginActiveIndex: 0, //默认激活北京 
    wayActiveIdx:-1,
    realActiveIdx:-1,
    wayArr:[{name:'企业直聘',value:1},{name:'个人招聘',value:0}],
    realNameArr:[{name:'已认证',value:1},{name:'未认证',value:0}],
    otherArr:[],
    otherSelct:[],
    
   
    limits:[],
    jobArr:[],
    query:{
      city:'',
      jobType:null,
      jobWorkerType:null,//用工类型 0-零工 1-全职
      needWorker:null,
      publisherCompanyId:null, // 发布公司ID
      publisherUserId:null, // 发布人ID
      publisherUserType:null,//0-普通用户 1-企业用户
      title:'',
      benifitList:[],
      industryList:[],//工种
      userVerifyStatus:null,//0-未认证 1-已认证
      status:1,//上下架状态 0-上架 1-下架
      verifyStatus:1, //0-待审核 1-审核成功 2-审核失败
      pageNum:1,
      pageSize:10
    },
    showLoading:true,
    hasMore:false,
    loading:false,
    isCompany:false,
  },
  onLoad(o){
    let {type,publisherUserType} = o;
    console.log( {type,publisherUserType})
    if(type==0){
      wx.setNavigationBarTitle({title:'找零工'})
      this.setData({'query.jobType':0,'query.jobWorkerType':0,isCompany:false,placeholder:'输入关键词搜索零工'})
    }
    if(publisherUserType>0){
      if(publisherUserType==1){
        wx.setNavigationBarTitle({title:'企业直聘'});
        this.setData({placeholder:'输入关键词搜索企业直聘'});
      }
      this.setData({'query.publisherUserType':1,wayActiveIdx:0,isCompany:true})
    }
   this.initMeta()
  },
  onShow(){
    //this.initFindStatus()
    let userInfo=localData('userInfo')
    let realName =userInfo.verifyStatus==1?true:false;
    this.setData({realName})
    this.initFresh()
    this.updateQuery()
    this.getList()
  },
  onPageScroll(e){
    if(this.data.freshNumber>0) return;
    this.setData({floatStatus: true})
    clearTimeout(scrollTime)
    scrollTime = setTimeout(res => {
      this.setData({floatStatus: false})
      clearTimeout(scrollTime)
    },500)
  },
  initFresh(){
    if(!loginCtrl(false)) {
      this.setData({freshNumber:0});
      return
    }
    dayFresh({}).then(res=>{
      if(res.freshNumber>0){
        clearTimeout(scrollTime)
      }
      this.setData({freshNumber:res.freshNumber})
    })
  },
  onHide(){
    clearTimeout(scrollTime)
  },
  onUnload(){
    clearTimeout(scrollTime)
    console.log('onUnload')
  },
  
  onReachBottom () {
    let {loading,hasMore,query} = this.data;
    if(loading || !hasMore) return
    query.pageNum++;
    this.setData({query,loading:true})
    this.getList()
  },
  //
  initMeta(){
    let orginArr = [], indusData=localData('indusData'),otherArr=localData('benifit');
    orginArr = formatCity(areaList,orginArr,1,3);
    this.setData({orginArr});
    if(empty(otherArr) || empty(indusData)){
      this.reloadIndus()
    }else{
      this.setData({indusArr:indusData,otherArr:otherArr,emptyShow:false})
    }
  },
  async reloadIndus(){
    let {job_industry,job_benifit,work_year,company_scale,company_type,report_type,card_group_total} = await initMetaData();
    if(!empty(job_industry)){
      this.setData({emptyShow:false})
      let indusData = job_industry.map((it,idx)=>{
        let obj = {
          text:it.dictLabel,
          id:it.dictValue,
          badge:null,
          num:0,
          disabled:false
        };
        !empty(it.children) && (obj.children = it.children.map(c=>{
          return {
            idx:idx,
            text:c.dictLabel,
            id:c.dictValue
          }
        }));
        return obj
      });
      //msgToast('加载成功')
      this.setData({indusArr:indusData});//缓存
      localData('indusData',indusData)
    }
    if(!empty(job_benifit)){
      let benifit = formatDict(job_benifit);
      this.setData({otherArr:benifit}); //缓存
      localData('benifit',benifit)
    }
    if(!empty(work_year)){
      let yearArr = formatDict(work_year);
      localData('yearArr',yearArr)
    }
    if(!empty(card_group_total)){
      let memArr = formatDict(card_group_total);
      localData('memArr',memArr)
    }
    if(!empty(company_scale)){
      let comSArr = formatDict(company_scale);
      localData('comSArr',comSArr)
    }
    if(!empty(company_type)){
      let comTArr = formatDict(company_type);
      localData('comTArr',comTArr)
    }
    if(!empty(report_type)){
      let reportArr = formatDict(report_type);
      localData('reportArr',reportArr)
    }
  },
  initFindStatus(){
    getFindStatus({}).then(res=>{
      let status = res;
      this.setData({canStatus:status})
    })
  },
  changeFindJob(oddStatus){
    updateFindJob({oddStatus}).then(res=>{
      console.log(res)
      this.setData({canStatus:oddStatus})
    })
  },
  goSearch(e){
   let type =  this.data.isCompany? 4 : 3;
    wx.navigateTo({
      url: `/pages/search/search?type=${type}`,
    })
  },
  //工种
  indusClickNav({ detail = {} }) {
    console.log(detail)
    this.setData({
      indusActiveIndex: detail.index || 0,
    });
  },
   
  indusClickItem({ detail = {} }) {
    let { indusActiveId, indusArr} = this.data;
    console.log(indusActiveId,detail)
    let {id,idx} = detail;
    
    let has = indusActiveId.indexOf(id);
    if (has > -1) {
      indusActiveId.splice(has, 1);
      indusArr[idx].num--;
    } else {
      indusActiveId.push(id);
      indusArr[idx].num++;
    }
    indusArr[idx].num>0? indusArr[idx].badge= indusArr[idx].num : indusArr[idx].badge= null;
    this.setData({ indusActiveId, indusArr});
  },
  indusReset(){
    let { indusArr }=this.data;
    indusArr&&indusArr.map(m=>{
      m.num=0;
      m.badge=null;
    })
    this.setData({ indusActiveId:[], indusArr,indusActiveIndex:0});
  },

  indusConfirm() {
    this.selectComponent('#indus').toggle(false)
    let {indusActiveId} =this.data;
    this.setData({'query.industryList':indusActiveId,'query.pageNum':1,indusNum:indusActiveId.length});
    //存储意向
    localData('specjob_indus',indusActiveId)
    this.getList()
  },
  //地区
  orginReset(){
    let { orginArr}=this.data;
    orginArr.map(m=>{
      m.dot=false;
    })
    this.setData({ orginActiveId:[],curCityObj:{}, orginArr,orginActiveIndex:0});
  },
  orginConfirm(){
    let {curCityObj,query}=this.data,curCityTit='';
  
    curCityTit = curCityObj.text?curCityObj.text:'';
    query.cityList = curCityObj.id?[curCityObj.id] : [];
    query.pageNum=1;
    if(empty(curCityObj)){
      localData('clearCity',1)
    }

    this.setData({query,curCityTit});
    //存储意向
    localData('citySelect',curCityObj);
    this.selectComponent('#orgin').toggle(false);
 
    this.getList();
  },
  orginClickNav({ detail = {} }) {
    let index = detail.index;
    this.setData({orginActiveIndex:index})
  },
 
  orginClick({ detail = {} }) {
    let { orginActiveId, orginArr,orginActiveIndex,orginmax}=this.data;
    const index = orginActiveId.indexOf(detail.id);
    if (index > -1) {
      orginActiveId.splice(index, 1);
      orginArr[orginActiveIndex].dot=false;
    } else {
      orginmax===1? orginActiveId = [detail.id] :orginActiveId.push(detail.id);
      orginArr.map(m=>{
        m.dot=false;
      })
      orginArr[orginActiveIndex].dot=true;
    }
    let curCityObj=null; 
    empty(orginActiveId)? curCityObj ={} : curCityObj=detail;
    this.setData({ orginActiveId,curCityObj, orginArr});
  },

  filterReset(){
    let {otherArr,isCompany} =this.data;
     otherArr.map(m=>{
      m.active=false;
    })
  
    this.setData({
      otherSelct:[],
      otherArr,
    //  'query.userVerifyStatus':null,
    //  realActiveIdx:-1,
    });
    isCompany? this.setData({wayActiveIdx:0}) : this.setData({wayActiveIdx:-1,});
   // this.getList();
  },
  filterConfirm(){
    this.selectComponent('#filters').toggle(false);
    let {wayArr,wayActiveIdx,realNameArr,realActiveIdx,otherSelct,query}=this.data;
    localData('specjobfilter',{realActiveIdx,otherSelct});

    wayArr[wayActiveIdx]? query.publisherUserType= wayArr[wayActiveIdx].value : query.publisherUserType=null;
    realNameArr[realActiveIdx]? query.userVerifyStatus= realNameArr[realActiveIdx].value :query.userVerifyStatus=null;

    query.pageNum=1;
    query.benifitList = otherSelct;
    this.setData({query});
    this.getList();
  },
  goOperate(){
    wx.navigateTo({
      url: '/pages/user/realname/index',
    })
  },
  getWay(e){
    let {index} = e.detail;
 
    this.setData({ wayActiveIdx:index})
   
  },
  getReal(e){
    let {index} = e.detail;
    this.setData({realActiveIdx:index})
  },
  getOther(e){
    let ids = e.detail;
    this.setData({otherSelct:ids})
    let {otherArr} =this.data;
    otherArr.map(m=>{
      if(ids.indexOf(m.value)>-1){
        m.active=true;
      }else{
        m.active=false;
      }
    })
    this.setData({otherArr})

  },
  toggleStatus(){
    if(!loginCtrl()) return
    //零工  不包含班组
    let status = this.data.cardStatus;
    if(!status.hasUser) {
      wx.showModal({
        title:'提示',
        content:'发布名片，获得更多零工机会',
        success:res=>{
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/user/mycard/index',
            })
          }
        }
      })
      
      return
    }
    let findStatus = Number(!this.data.canStatus);
    
    if(findStatus==1){
      msgToast('您已开始接活，系统会自动推送您的求职意向给招工方')
    }else{
      msgToast('您已暂停自动接活服务')
    }
    
    setTimeout(()=>{
      this.changeFindJob(findStatus)
    },500)
    
  },
  getList(){
    let {query} = this.data;
    jobs({...query}).then(res=>{
      this.setData({loading:false})
      let {total,currentPage,rows} = res;
      rows = rows ||[];
      if(currentPage==1){
        this.setData({jobArr:rows})
        if(total == rows.length){
          this.setData({hasMore:false});
          total==0 ? this.setData({showLoading:false}):this.setData({showLoading:true});
          return
        }
      }
      if(currentPage>1){
        if(empty(rows)){
          this.setData({hasMore:false,showLoading:true})
          return
        } 
        this.setData({jobArr:this.data.jobArr.concat(rows)});
      }
       total>this.data.jobArr.length ? this.setData({hasMore:true}) : this.setData({hasMore:false,showLoading:true});
      
    }).catch(err=>{
      this.setData({loading:false})
    })
  },

  openDropMenu(e){
    if(empty(otherArr) || empty(indusData)){
      this.setData({emptyShow:true})
      return
    }
    this.updateQuery();
    this.setData({showDropdownMenu:true});
  },
  closeDropMenu(e){
    this.updateQuery();
    this.setData({showDropdownMenu:false})
  },
  updateQuery(){
    let specjobfilter =localData('specjobfilter') || {};
    let citySelect = localData('citySelect'),specjob_indus=localData('specjob_indus') || [],idArr=[],{indusArr,query} =this.data;;
    // 地区缓存
    if(empty(citySelect)){
      idArr=[];
      this.setData({curCityObj:{}})
      this.orginReset();
    }else{
      idArr=[citySelect.id];
      let front = citySelect.id.substr(0,2),{orginArr}=this.data;
  
      let hasidx = orginArr.findIndex(item=> item.id.substr(0,2)== front );
      if(hasidx>-1) {
        orginArr[hasidx].dot=true;
        this.setData({orginActiveIndex:hasidx,curCityTit:citySelect.text,orginActiveId:idArr,orginArr,curCityObj:citySelect})
      }
    }
   
    // 找活干-工种缓存
    if(empty(specjob_indus)){
      this.indusReset();
    }else {
      indusArr && indusArr.map((item,idx)=>{
        item.num=0;
        item.children&&item.children.map(son=>{
          let has = specjob_indus.indexOf(son.id);
          if(has>-1){
            let pidx = son.idx;
            indusArr[pidx].num++;
            indusArr[pidx].num>0 ?  indusArr[pidx].badge = indusArr[pidx].num : indusArr[pidx].badge = null;
          }
        })
      });
    }
    //  零工/直聘 -筛选
   
    if(empty(specjobfilter)){
      query.userVerifyStatus=null;
      query.benifitList =[];
      this.setData({realActiveIdx:-1,otherSelct:[]})
    }else{
      let {realNameArr} = this.data;
      let {realActiveIdx, otherSelct} = specjobfilter;
      console.log('otherSelct',otherSelct)
      this.setData({realActiveIdx,otherSelct});

      realNameArr[realActiveIdx]? query.userVerifyStatus= realNameArr[realActiveIdx].value :query.userVerifyStatus=null;

      query.benifitList = otherSelct;
    }
    query.pageNum=1;
    query.cityList=idArr;
    query.industryList=specjob_indus;
    this.setData({
      query,
      indusNum:specjob_indus.length,
      indusActiveId:specjob_indus,
      indusArr
    });
  },

  // 漂浮按钮事件
  goLogin(){
    wx.navigateTo({
      url: '/pages/user/login/index?from=shortterm',
    })
  },
  goFresh(){
    console.log('Fresh')
    doFresh({}).then(res=>{
      msgToast('今日已刷新，您的名片将提升曝光','none',2500);
      this.setData({freshNumber:1});
    });
  },
  goPost(){
    console.log('Post')
    wx.navigateTo({
      url: '/pages/user/mycard/index?type=0',
    })
  }
})