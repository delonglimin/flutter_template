import { cardList, teamList } from '../../api/job.js'
import {initMetaData,formatDict,msgInfo} from '../../utils/getData'
import { empty, localData,gbData, loginCtrl,formatCity,wxReport } from '../../utils/index.js';
import {areaList} from '../../utils/citylist'
 
 let scrollTime=null;
Page({
  data: {
    floatStatus: false,
    emptyShow:false,
    tabActive:0,
    realName:false,
    yearArr:[],//工龄
    yearActiveIdx:-1,

    certActiveIdx:-1,
    memActiveIdx:-1,

    tradeTitle:'工种',
    indusActiveIndex: 0,
    indusActiveId: [],
    indusMax:3,
    indusArr:[],

    orginActiveId: [],
    orginTitle:"地区",
    orginmax:1,
    orginArr:[],
    orginActiveIndex: 0, //默认激活北京 

    sexActiveIdx:-1,
    otherArr:[],
    otherSelct:[],
    sexArr:[{name:'男',value:1},{name:'女',value:2}],
    certArr:[{name:'有',value:1},{name:'无',value:0}],
    memArr:[],

    limits:[],
    workerArr:[],
    grouparr: [],
    wHasMore:true,
    wLoading:false,
    showWLoad:true,
    wQuery: {
      pageNum:1, // 页数
      pageSize: 10,
      cardName:'', // 标题
      cityList:[], // 城市列表
      industryList:[], //行业
      sex:null,  // 0-男 1-女
      workDate:null, // 工龄
      haveCertificateKey:null, // 0-有 1-无 证书
      pageNum: 1,
      pageSize: 10
    },
    tHasMore:true,
    tLoading:false,
    showTLoad:true,
    tQuery: {
      pageNum: 1, // 分页
      pageSize: 10,
      cardName: '', // 名称
      cityList: [], // 城市
      industryList: [], // 行业
      cardType: 1, // 1-班组
      minTotalNumber: null, // 总人数
      maxTotalNumber: null, // 总人数
      groupLeaderName: '', // 领队名称
      note: '' // 简介
    },
    indusNum:0,
    curCityTit:'',
    showDropdownMenu:false
  },

     /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.initMeta();
  },
  onShow(){
    // 消息未读数
    let pages = getCurrentPages();
    if(!pages[pages.length - 2] && localData('token')){
      this.getMsgNum()
    }
    
    let userInfo=localData('userInfo')
    let realName =userInfo.verifyStatus==1?true:false;
    this.setData({realName})
    
    wx.showTabBar({
      animation: true,
    })
    this.updateQuery();
    this.getCard();
    this.getTeam();
  },
  async getMsgNum(){
    let {unread} =  await msgInfo();
    gbData('unread',unread);
    localData('unread',unread)
    unread>0 ? wx.setTabBarBadge({index: 3,text: unread.toString()}) : wx.removeTabBarBadge({index: 3})
  },

  updateQuery(){
    let citySelect = localData('citySelect'),card_indus=localData('card_indus') || [],cardfilter_w = localData('cardfilter_w') || {},cardfilter_t = localData('cardfilter_t') || {},idArr=[],{indusArr} =this.data;
  
    // 地区缓存
    if(empty(citySelect)){
      idArr=[];
      this.orginReset();
    }else{
      idArr=[citySelect.id];
      let front = citySelect.id.substr(0,2),{orginArr}=this.data;
  
      let hasidx = orginArr.findIndex(item=> item.id.substr(0,2)== front );
      if(hasidx>-1) {
        orginArr[hasidx].dot=true;
        this.setData({orginActiveIndex:hasidx,curCityTit:citySelect.text,orginActiveId:idArr,orginArr})
      }
    }
    
    // 招工人-工种缓存
    if(empty(card_indus)){
      this.indusReset();
    }else {
      indusArr && indusArr.map((item,idx)=>{
        item.num=0;
        item.children && item.children.map(son=>{
          let has = card_indus.indexOf(son.id);
          if(has>-1){
            let pidx = son.idx;
            indusArr[pidx].num++;
            indusArr[pidx].num>0 ?  indusArr[pidx].badge = indusArr[pidx].num : indusArr[pidx].badge = null;
          }
        })
      });
    }
    let {wQuery,tQuery,tabActive} = this.data;
    wQuery.cityList =  tQuery.cityList = idArr;
    wQuery.industryList = tQuery.industryList = card_indus;
    wQuery.pageNum = tQuery.pageNum = 1;
    // 工人-筛选
    if(empty(cardfilter_w)){
      this.setData({sexActiveIdx:-1,yearActiveIdx:-1,certActiveIdx:-1});
      wQuery.sex=null;
      wQuery.workDate=null;
      wQuery.haveCertificateKey=null;
    }else{
      let {sexArr,yearArr,certArr} = this.data;
      let {sexActiveIdx,yearActiveIdx,certActiveIdx} = cardfilter_w;
      this.setData({sexActiveIdx,yearActiveIdx,certActiveIdx});
      sexArr[sexActiveIdx]? wQuery.sex=sexArr[sexActiveIdx].value: wQuery.sex=null;
      yearArr[yearActiveIdx]? wQuery.workDate= yearArr[yearActiveIdx].value: wQuery.workDate=null;
      if(tabActive==0){
        this.setData({certActiveIdx});
      }
      certArr[certActiveIdx]? wQuery.haveCertificateKey=certArr[certActiveIdx].value :wQuery.haveCertificateKey=null;
    }
    // 班组-筛选
    if(empty(cardfilter_t)){
      tQuery.haveCertificateKey=null;
      tQuery.minTotalNumber=null; // 总人数
      tQuery.maxTotalNumber=null; // 总人数
      this.setData({certActiveIdx:-1,memActiveIdx:-1}); 
    }else{
      let { certArr } = this.data;
      let { memActiveIdx, certActiveIdx } = cardfilter_t;
      this.setData({memActiveIdx});
      if(tabActive==1){
        this.setData({certActiveIdx});
      }
      this.formatMem(); //队伍人数
      certArr[certActiveIdx]? tQuery.haveCertificateKey=certArr[certActiveIdx].value :tQuery.haveCertificateKey=null;
    }

    this.setData({
      wQuery,
      tQuery,
      indusNum:card_indus.length,
      indusActiveId:card_indus,
      indusArr
    });
     
  },
  onHide(){
    console.log('findworker onHide')
    clearTimeout(scrollTime)
  },
  onUnload(){
    clearTimeout(scrollTime)
    console.log('findworker onUnload')
  },
  onReachBottom(){
    if(this.data.tabActive==0){
      if(this.data.wLoading || !this.data.wHasMore) return;
      this.setData({wLoading:true})
      let num = this.data.wQuery.pageNum;
      num++;
      this.setData({'wQuery.pageNum':num})
      this.getCard();
    }else{
      if(this.data.tLoading || !this.data.tHasMore) return;
      this.setData({tLoading:true});
      let num = this.data.wQuery.pageNum;
      num++;
      this.setData({'tQuery.pageNum':num})
      this.getTeam();
    }
  },
  tabChange(e){
    let {tabActive,indusActiveId,orginActiveId, sexArr, sexActiveIdx,certArr,certActiveIdx,yearActiveIdx,yearArr} = this.data;
    let {idx} = e.currentTarget.dataset;
    if(tabActive==idx) return
    // 关闭窗口
    this.selectComponent('#indus').toggle(false);
    this.selectComponent('#orgin').toggle(false);
    this.selectComponent('#filters').toggle(false);
    this.setData({tabActive:idx});
  },
  goLogin(){
    wx.navigateTo({
      url: '/pages/user/login/index?from=findworker'
    })
  },
  goPost(){
    wx.navigateTo({
      url: '/pages/user/recruit/add/index?type=0'
    })
  },
  
  goOperate(){
    if(!localData('token')){
      wx.navigateTo({
        url: '/pages/user/login/index?from=real',
      })
      return
    }
    wx.navigateTo({
      url: '/pages/user/realname/index'
    })
  },
 
  openDropMenu(e){
    let {indusArr,otherArr,yearArr,memArr} = this.data;
    if(empty(indusArr) || empty(otherArr) || empty(yearArr) || empty(memArr)){
      this.setData({emptyShow:true});
      return
    }
    this.updateQuery();
    this.setData({showDropdownMenu:true});
    wx.hideTabBar({
      animation: true,
    })
  },
  closeDropMenu(e){
    this.updateQuery();
    this.setData({showDropdownMenu:false})
    wx.showTabBar({
      animation: true,
    })
  },
  getCard(){
    let {wQuery} = this.data;
    cardList(wQuery).then(res=>{
      this.setData({wLoading:false})
      let {rows,total} = res;
     
      let yearArr = localData('yearArr');
      if(!empty(rows) && !empty(yearArr)){
        rows.map(m=>{
          let has = yearArr.filter(f=>f.value== m.workDate);
         
          if(!empty(has)){
            m.workDateStr =  has[0].name;
          }
          
        })
      }

      if(wQuery.pageNum==1){
        
        this.setData({workerArr: rows || []})
        if(rows.length == total) {
          total==0?this.setData({showWLoad:false}):this.setData({showWLoad:true});
          this.setData({wHasMore:false});
          return
        }
      }
      if(wQuery.pageNum>1){
        
        this.setData({workerArr:this.data.workerArr.concat(rows)})
      }
      if(total >0){
        let len = this.data.workerArr.length;
        len<total? this.setData({wHasMore:true}) : this.setData({wHasMore:false,showWLoad:true})
      }else{
        this.setData({wHasMore:false})
      }
    }).catch(err=>{
      this.setData({wLoading:false})
    })
  },
  goSearch(e){
    wx.navigateTo({
      url: '/pages/search/search?type=2',
    })
  },
  // 查询班组名片列表
  getTeam(){
    let {tQuery} = this.data;
    teamList(tQuery).then(res=>{
      this.setData({tLoading:false})
      let {rows,total} = res;
      if(tQuery.pageNum==1){
        this.setData({grouparr: rows || []})
        if(rows.length == total){
          total==0? this.setData({showTLoad:false}) : this.setData({showTLoad:true})
          this.setData({tHasMore:false});
          return
        }
      }
      if(tQuery.pageNum>1){
        this.setData({grouparr: this.data.grouparr.concat(rows)})
      }
      if(total >0){
        let len = this.data.grouparr.length;
        len<total? this.setData({tHasMore:true}) : this.setData({tHasMore:false,showTLoad:true})
      }else{
        this.setData({tHasMore:false})
      }
    }).catch(err=>{
      this.setData({tLoading:false})
    })
  },
 
  initMeta(){
    let orginArr = [],indusArr=localData('indusData'),otherArr=localData('benifit'),yearArr=localData('yearArr'),memArr=localData('memArr');
    orginArr = formatCity(areaList,orginArr,1,3);
    this.setData({orginArr});
    if(empty(indusArr) || empty(otherArr) || empty(yearArr) || empty(memArr)){
      this.reloadIndus()
      
    }else{
      this.setData({indusArr,otherArr,yearArr,memArr,emptyShow:false})
    }
    
  },
  async reloadIndus(){
    let {job_industry,job_benifit,work_year,company_scale,company_type,report_type,card_group_total} = await initMetaData();
    if(!empty(job_industry)){
      this.setData({emptyShow:false})
      let indusData = job_industry.map((it,idx)=>{
        let obj = {
          text:it.dictLabel,
          id:it.dictValue,
          badge:null,
          num:0,
          disabled:false
        };
        !empty(it.children) && (obj.children = it.children.map(c=>{
          return {
            idx:idx,
            text:c.dictLabel,
            id:c.dictValue
          }
        }));
        return obj
      });
     // msgToast('加载成功')
      this.setData({indusArr:indusData});//缓存
      localData('indusData',indusData)
    }
    if(!empty(job_benifit)){
      let benifit = formatDict(job_benifit);
      this.setData({otherArr:benifit}); //缓存
      localData('benifit',benifit)
    }
    if(!empty(work_year)){
      let yearArr = formatDict(work_year);
      this.setData({yearArr}); //缓存
      localData('yearArr',yearArr)
    }
    if(!empty(card_group_total)){
      let memArr = formatDict(card_group_total);
      this.setData({memArr}); //缓存
      localData('memArr',memArr)
    }
    if(!empty(company_scale)){
      let comSArr = formatDict(company_scale);
      localData('comSArr',comSArr)
    }
    if(!empty(company_type)){
      let comTArr = formatDict(company_type);
      localData('comTArr',comTArr)
    }
    if(!empty(report_type)){
      let reportArr = formatDict(report_type);
      localData('reportArr',reportArr)
    }
  },
  //工种
  indusClickNav({ detail = {} }) {
    this.setData({
      indusActiveIndex: detail.index || 0,
    });
  },
  indusClickItem({ detail = {} }) {
    let { indusActiveId, indusArr} = this.data;
    let {id,idx} = detail;
    let has = indusActiveId.indexOf(id);
    if (has > -1) {
      indusActiveId.splice(has, 1);
      indusArr[idx].num--;
    } else {
      indusActiveId.push(id);
      indusArr[idx].num++;
    }
    indusArr[idx].num>0? indusArr[idx].badge= indusArr[idx].num : indusArr[idx].badge= null;
    this.setData({indusActiveId,indusArr})
  },
  // 工种 清除条件
  indusReset(){
    let { indusArr }=this.data;
    indusArr&&indusArr.map(m=>{
      m.num=0;
      m.badge=null;
    })
    this.setData({ indusActiveId:[], indusArr,indusActiveIndex:0,indusNum:0});
  },
  indusConfirm() {
    this.selectComponent('#indus').toggle(false)
    let {indusActiveId,wQuery,tQuery} =this.data;
    wQuery.pageNum = tQuery.pageNum = 1;
    wQuery.industryList = tQuery.industryList = indusActiveId;
    this.setData({wQuery,tQuery,indusNum:indusActiveId.length});
    //load
    this.getCard()
    this.getTeam()
    //存储意向
    localData('card_indus',indusActiveId)
  },

  orginClickNav({ detail = {} }) {
    let index = detail.index;
    this.setData({orginActiveIndex:index})
  },
  
  orginClick({ detail = {} }) {
    let { orginActiveId, orginArr,orginActiveIndex,orginmax}=this.data;
    const index = orginActiveId.indexOf(detail.id);
    if (index > -1) {
      orginActiveId.splice(index, 1);
      orginArr[orginActiveIndex].dot=false;
    } else {
      orginmax===1? orginActiveId = [detail.id] :orginActiveId.push(detail.id);
      orginArr.map(m=>{
        m.dot=false;
      })
      orginArr[orginActiveIndex].dot=true;
    }
    this.setData({ orginActiveId,curCityObj:detail, orginArr});
 
  },
  //地区 清除条件
  orginReset(){
   
    let { orginArr}=this.data;
    orginArr.map(m=>{
      m.dot=false;
    })
    this.setData({ orginActiveId:[],curCityObj:{}, orginArr,orginActiveIndex:0});
 
  },
  // 根据地区条件查询
  orginConfirm(){

    let {curCityObj,tQuery,wQuery}=this.data,curCityTit='';
    curCityTit = curCityObj.text?curCityObj.text:'';
    tQuery.cityList = wQuery.cityList = curCityObj.id?[curCityObj.id] : [];
    tQuery.pageNum = wQuery.pageNum=1;
    if(empty(curCityObj)){
      localData('clearCity',1)
    }
    
    this.setData({tQuery,wQuery,curCityTit});
    //存储意向
    localData('citySelect',curCityObj);
    this.selectComponent('#orgin').toggle(false);
    this.getCard();
    this.getTeam();
  },
  filterReset(){
    let {tabActive} =this.data;
    tabActive==0? this.setData({sexActiveIdx:-1,yearActiveIdx:-1,certActiveIdx:-1}) : this.setData({memActiveIdx:-1,certActiveIdx:-1});
  },
  filterConfirm(){
    let {wQuery,tQuery,tabActive,sexArr,sexActiveIdx,yearArr,yearActiveIdx,certArr,certActiveIdx, memActiveIdx} =this.data;
    if(tabActive==0){
      wQuery.pageNum=1;
      sexArr[sexActiveIdx]? wQuery.sex=sexArr[sexActiveIdx].value: wQuery.sex=null;
      yearArr[yearActiveIdx]? wQuery.workDate= yearArr[yearActiveIdx].value: wQuery.workDate=null;
      certArr[certActiveIdx]? wQuery.haveCertificateKey=certArr[certActiveIdx].value :wQuery.haveCertificateKey=null;
       
      localData('cardfilter_w', { sexActiveIdx,yearActiveIdx,certActiveIdx })
      this.setData({wQuery})
      this.getCard()
    }else{
      tQuery.pageNum=1;
     
      certArr[certActiveIdx]? tQuery.haveCertificateKey = certArr[certActiveIdx].value : tQuery.haveCertificateKey=null;

      this.setData({tQuery});
      localData('cardfilter_t', { certActiveIdx, memActiveIdx });

      this.formatMem(); //队伍人数
      this.getTeam();
    }
    this.selectComponent('#filters').toggle(false);
  },
  onPageScroll(e){
    this.setData({floatStatus: true})
    clearTimeout(scrollTime)
    scrollTime = setTimeout(res => {
      this.setData({floatStatus: false})
      clearTimeout(scrollTime)
    },200)
  },
  // 工人-性别
  getSex(e){
    let {index} = e.detail;
    this.setData({ sexActiveIdx:index})
  },
   // 公共-技能证书
  getCert(e){
    let {index} = e.detail;
    this.setData({ certActiveIdx:index});
  },
  // 工人-工龄
  getYear(e){
    let {index} = e.detail;
    this.setData({ yearActiveIdx:index})
    
  },
  //队伍人数
  getMem(e){
    let {index} = e.detail; 
    this.setData({ memActiveIdx:index})
  },
  formatMem(){
    let {memArr,memActiveIdx,tQuery} = this.data;
    if(memActiveIdx<0){
      tQuery.minTotalNumber=null;
      tQuery.maxTotalNumber=null;
      this.setData({tQuery});
      return
    }
    let str = memArr[memActiveIdx].name.replace('人','');
    if(str.indexOf('以下')>-1){
      let num = str.replace('以下','')
      tQuery.minTotalNumber=null;
      tQuery.maxTotalNumber=Number(num);
      
    }else if(str.indexOf('以上')>-1){
      let num = str.replace('以上','');
      tQuery.minTotalNumber=Number(num);
      tQuery.maxTotalNumber=null;
    }else{
      let arr = str.split('-')
      tQuery.minTotalNumber=Number(arr[0]);
      tQuery.maxTotalNumber=Number(arr[1]);
    }
    this.setData({tQuery});
  }
})
