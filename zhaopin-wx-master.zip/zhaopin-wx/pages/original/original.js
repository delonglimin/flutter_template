import {original} from '../../api/base'
import { empty } from '../../utils/index';

Page({
  data:{
    orginSelcet:[],
    orginNameArr:[],
    orginArr:[],
    orginmax:3,
    orginActiveId: [],
    ActiveIdx:0
  },
  onLoad(){
    this.getOrgions('job_industry')
  },
  orginClickNav({ detail = {} }) {
    this.setData({
      ActiveIdx: detail.index || 0,
    });
  },
  orginReset(){
    this.setData({orginActiveId:[],orginSelcet:[]})
  },
  //工种
  orginConfirm(){
   
    let pages = getCurrentPages();
    let prevPage = pages[pages.length - 2];
    prevPage.setData({
      jobSelect:this.data.orginSelcet
    });
   
    wx.navigateBack({
      delta: 1
    });
  },
  orginClick({ detail = {} }) {
    console.log(detail)
    let { orginSelcet,orginActiveId,orginNameArr } = this.data;
    let hasidx = orginActiveId.findIndex(f=>f.id==detail.id);
    if(hasidx>-1){
      orginSelcet.splice(hasidx,1);
      orginActiveId.splice(index, 1);
      orginNameArr.splice(idx,1)
    } else {
      orginSelcet.push(detail);
      orginActiveId.push(detail.id);
      orginNameArr.push(detail.text);
    }
    this.setData({ orginSelcet, orginActiveId,orginNameArr });
    // let index = orginActiveId.indexOf(detail.id),idx = orginNameArr.indexOf(detail.text);
    // if (index > -1) {
    //   orginActiveId.splice(index, 1);
    //   orginNameArr.splice(idx,1)
    // } else {
    //   orginActiveId.push(detail.id);
    //   orginNameArr.push(detail.text);
    // }
    // 获取工种ID 数组
    
   // this.setData({ orginActiveId,orginNameArr });
     
  },
  getOrgions(dictType){
    original({dictType}).then(res=>{
      console.log(res)
      
        let arr = res ||[];
        // this.setData({orginArr:arr})
      
        let dataArr = arr.map(it=>{
          let obj = {};
          obj.text = it.dictLabel;
          obj.id = it.dictValue;
          obj.disabled = false;
          console.log('it.children',it)
          if(!empty(it.children)){
            obj.children = it.children.map(c=>{
              let s = {};
              s.text = c.dictLabel;
              s.id = c.dictValue;
              return s
            });
          }
          
          return obj
        });
        this.setData({orginArr:dataArr})
       
    })
  }
})