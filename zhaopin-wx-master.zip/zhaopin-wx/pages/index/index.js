import {mainMenu} from '../../utils/static';
import {jobs,cardList} from '../../api/job'
import {banner,ipPos} from '../../api/base'
import {areaList} from '../../utils/citylist'
import {initMetaData,formatDict,getCityCode,msgInfo} from '../../utils/getData'
import { empty,gbData,localData,formatSalary,formatCity,loginCtrl,getViewInfo,throttle,debounce, msgToast, wxReport} from '../../utils/index';

let scrollTime=null;
Page({
  data: {
    floatStatus:false,
    emptyShow:false,
    betop:'',
    bannerH: 214,
    mainMenu,
    userId: gbData('userId'),
    wHasMore:true,
    wLoding:false,
    wquery: {
      city: '',
      cityList:[],
      industryList:[],
      jobType: null,
      jobWorkerType: null, //用工类型 0-零工 1-全职
      needWorker: null,
      publisherCompanyId: null, // 发布公司ID
      publisherUserId: null, // 发布人ID
      publisherUserType: null, //0-普通用户 1-企业用户
      title: '',
      benifitList: [],
      userVerifyStatus: null, //0-未认证 1-已认证
      status: 1, //上下架状态 0-上架 1-下架
      verifyStatus: 1, //0-待审核 1-审核成功 2-审核失败
      pageNum: 1,
      pageSize: 10,
    },
    listActive: 0,
    isFixed: false,
    fixTopHeight: 0, //置顶高度
    bannerArr: [],
    jobArr: [],
    cHasMore:true,
    cLoding:false,
    showWLoading:true,
    showCLoading:true,
    cquery: {
      pageNum: 1,
      pageSize:10,
      cardName: '',
      cityList: [],
      industryList: [],
      sex: 0,
      workDate: null,
      cardCertificateKey: null
    },
    workerArr: [],

    orginArr:[],
    curCityObj:{},
    confirmCityTit:'',
    reginFlag:false,
    orginmax:1,
    orginActiveId:[],
    orginActiveIndex:0,

    indusArr:[],
    indusFlag:false,
    indusActiveIndex:0,
    indusActiveId:[],
    indusmax:3,
    indusNum:0
  },

  onLoad() {
    let wd = gbData('winWidth'), height = 214 * wd / 375,
    fixTopHeight = gbData('navHeight');
    
    let betop = 'top:'+fixTopHeight+'px';
    // let treeTop = 'top:'+fixTopHeight+44+'px'
    this.setData({fixTopHeight,bannerH: height,betop});
    getViewInfo('.sticky_view').then(res=>{
      let treeTop = fixTopHeight+res.height;
       treeTop = 'top:'+treeTop+'px';
     // console.log(treeTop)
      this.setData({treeTop});
    })
    
    this.getBanner();
   
  },
  onShow() {
    this.checkLocation();
    this.initData()
    this.updateQuery()
  },
 
   
  onHide(){
    this.setData({reginFlag:false,indusFlag:false})
  },
  onPageScroll(e){
    this.setData({floatStatus: true})
    clearTimeout(scrollTime)
    scrollTime = setTimeout(res => {
      this.setData({floatStatus: false})
      clearTimeout(scrollTime)
    },200)

    let distance = e.scrollTop;
    
    if(distance>=118){
      if(this.data.isFixed) return
      console.log(distance)
      this.setData({isFixed:true})
    }else{
      if(!this.data.isFixed) return
      this.setData({isFixed:false})
    }
  },
  pageTo(){
    wx.pageScrollTo({
      scrollTop:0,
      duration: 500,
    })
  },
  initData(){
    wx.showTabBar({
      animation: true,
    })
    // 消息未读数
    let pages = getCurrentPages();
    if(!pages[pages.length - 2] && localData('token')){
      this.getMsgNum()
    }
    
   
    let orginArr = [];
    orginArr = formatCity(areaList,orginArr,1,3);
    this.setData({orginArr});
    //
    let indusArr = localData('indusData');
    if(empty(indusArr)){
      this.reloadIndus()
       
    }else{
      this.setData({indusArr});
    }
  },
  bannerJump(e){
    let path =e.detail;
    if(!localData('token')){
      wx.navigateTo({url: '/pages/user/login/index?from=banner'});
      return
    }
    wx.navigateTo({
      url: `/pages${path}`,
      success:()=>{
        if(path.indexOf('lottery')>-1){
          wxReport('index_banner_lottery')
          return
        }
        if(path.indexOf('signdate')>-1){
          console.log('index_banner_signdate')
          wxReport('index_banner_signdate')
          return
        }
       }
    });
  },
  async getMsgNum(){
    let {unread} =  await msgInfo();
    gbData('unread',unread);
    localData('unread',unread)
    unread>0 ? wx.setTabBarBadge({index: 3,text: unread.toString()}) : wx.removeTabBarBadge({index: 3})
  },
  async reloadIndus(){
    let {job_industry,job_benifit,work_year,company_scale,company_type,report_type,card_group_total} = await initMetaData();
    if(!empty(job_industry)){
      this.setData({emptyShow:false})
      let indusData = job_industry.map((it,idx)=>{
        let obj = {
          text:it.dictLabel,
          id:it.dictValue,
          badge:null,
          num:0,
          disabled:false
        };
        !empty(it.children) && (obj.children = it.children.map(c=>{
          return {
            idx:idx,
            text:c.dictLabel,
            id:c.dictValue
          }
        }));
        return obj
      });
      msgToast('加载成功')
      this.setData({indusArr:indusData});
      localData('indusData',indusData)
    }
    if(!empty(job_benifit)){
      let benifit = formatDict(job_benifit);
      localData('benifit',benifit)
    }
    if(!empty(work_year)){
      let yearArr = formatDict(work_year);
      localData('yearArr',yearArr)
    }
    if(!empty(card_group_total)){
      let memArr = formatDict(card_group_total);
      localData('memArr',memArr)
    }
    if(!empty(company_scale)){
      let comSArr = formatDict(company_scale);
      localData('comSArr',comSArr)
    }
    if(!empty(company_type)){
      let comTArr = formatDict(company_type);
      localData('comTArr',comTArr)
    }
    if(!empty(report_type)){
      let reportArr = formatDict(report_type);
      localData('reportArr',reportArr)
    }
  },
  orginClickNav({ detail = {} }){
    let index = detail.index;
    this.setData({orginActiveIndex:index})
  },
  orginClick({ detail = {} }) {
    let { orginActiveId, orginArr,orginActiveIndex,orginmax} = this.data;
    const index = orginActiveId.indexOf(detail.id);

    if (index > -1) {
      orginActiveId.splice(index, 1);
      orginArr[orginActiveIndex].dot=false;
    } else {
      orginmax===1? orginActiveId = [detail.id] :orginActiveId.push(detail.id);
      orginArr.map(m=>{
        m.dot=false;
      })
      orginArr[orginActiveIndex].dot=true;
    }
    let curCityObj=null; 
    empty(orginActiveId)? curCityObj ={} : curCityObj=detail;
    this.setData({ orginActiveId,curCityObj, orginArr});
  },
  orginReset(){
    let { orginArr}=this.data;
    orginArr.map(m=>{
      m.dot=false;
    })
    this.setData({ orginActiveId:[],curCityObj:{}, orginArr,orginActiveIndex:0});
  },
  orginConfirm(){
    // 关闭下拉
    let {curCityObj,wquery,cquery}=this.data;
    wquery.pageNum = cquery.pageNum =1;
    wquery.cityList = cquery.cityList = curCityObj.id?[curCityObj.id] : [];
    let curCityTit = curCityObj.text?curCityObj.text:'';
    if(empty(curCityObj)){
      localData('clearCity',1)
    }
   
    this.setData({wquery,cquery,reginFlag:false,curCityTit})
    wx.showTabBar({
      animation: true,
    }) 
    this.getList();
    this.getCardList();
    setTimeout(()=>{
      wx.pageScrollTo({
        scrollTop: 300,
        duration: 50
      })
    },500);
    //存储意向
    
    localData('citySelect',curCityObj)
  },
  indusReset(){
    let { indusArr }= this.data;
    indusArr&&indusArr.map(m=>{
      m.num=0;
      m.badge=null;
    })
    this.setData({ indusActiveId:[], indusArr,indusActiveIndex:0});
  },
  indusConfirm(){
    let {wquery,cquery,indusActiveId,indusArr}=this.data, indusNum= indusArr&&indusArr.reduce((total,item)=>{
      return total+item.num
    },0);
    wquery.industryList = cquery.industryList = indusActiveId;
    wquery.pageNum= cquery.pageNum =1;

    this.setData({indusNum,indusFlag:false,wquery,cquery});
    wx.showTabBar({
      animation: true,
    }) 
    //
    this.getList();
    this.getCardList();
    setTimeout(()=>{
      wx.pageScrollTo({
        scrollTop: 300,
        duration: 50
      })
    },500);
    //存储意向
    localData('jobSelect',indusActiveId)
     
  },
  indusClickNav({ detail = {} }){
    let index = detail.index;
    this.setData({indusActiveIndex:index})
  },
  indusClick({ detail = {} }) {
    let { indusActiveId, indusArr}=this.data;
    let {id,idx} = detail;
    
    const has = indusActiveId.indexOf(id);
    if (has > -1) {
      indusActiveId.splice(has, 1);
      indusArr[idx].num--;
    } else {
      indusActiveId.push(id);
      indusArr[idx].num++;
    }
    indusArr[idx].num>0? indusArr[idx].badge= indusArr[idx].num : indusArr[idx].badge= null;
    this.setData({ indusActiveId, indusArr});
  },
  updateQuery(){
    let citySelect = localData('citySelect'),jobSelect=localData('jobSelect') || [],idArr=[],{indusArr} =this.data;
     
    // 地区缓存
    if(empty(citySelect)){
      idArr=[];
      this.orginReset();
    }else{
      
      idArr=[citySelect.id.toString()];
     
      let front = citySelect.id.substr(0,2),{orginArr}=this.data;
  
      let hasidx = orginArr.findIndex(item=> item.id.substr(0,2)== front);
      if(hasidx>-1) {
        orginArr[hasidx].dot=true;
        this.setData({orginActiveIndex:hasidx,curCityTit:citySelect.text,orginActiveId:idArr,orginArr})
      }
    }
    // 工种缓存
    let indus = empty(jobSelect)? [] : jobSelect;
    if(indus.length>0){
      indusArr && indusArr.map((item,idx)=>{
        item.num=0;
        item.children && item.children.map(son=>{
          let has = indus.indexOf(son.id);
          if(has>-1){
            let pidx = son.idx;
            indusArr[pidx].num++;
            indusArr[pidx].num>0 ?  indusArr[pidx].badge = indusArr[pidx].num : indusArr[pidx].badge = null;
          }
        })
      });
    }else{
      this.indusReset();
    }
    this.setData({
      'wquery.cityList':idArr,
      'cquery.cityList':idArr,
      'wquery.industryList':indus,
      'cquery.industryList':indus,
      indusNum:indus.length,
      indusActiveId:indus,
      indusArr
    });
    this.getList();
    this.getCardList();
  },

  getlistFilter(e) {
    let type = e.target.dataset.type
    this.setData({
      listActive: type
    })
  },
  onPullDownRefresh(){
    this.getBanner()
    this.getList();
    this.getCardList() 
  },
  onReachBottom() {
    let active = this.data.listActive;
    if(active==0){
      if(!this.data.wHasMore  || this.data.wLoding) return
      this.setData({wLoding:true})
      let num = this.data.wquery.pageNum;
      num++;
      this.setData({'wquery.pageNum':num})
      this.getList()
    }else{
      if(!this.data.cHasMore || this.data.cLoding) return
      this.setData({cLoding:true})
      let num = this.data.cquery.pageNum;
      num++;
      this.setData({'cquery.pageNum':num})
      this.getCardList()
    }
  },
  gotoSearch() {
    wx.navigateTo({
      url: `/pages/search/search?type=0`,
    })
  },
  goDraw(){
    if(!localData('token')) {
      wx.navigateTo({
        url: '../user/login/index?from=lottery',
      })
      return
    }
    
    wx.navigateTo({
      url: '../user/lottery/index',
      success:()=>{
        console.log('report')
        wxReport('index_lottery_lottery');
      }
    })
  },
  getList() {
    let {wquery} = this.data;
    jobs({...wquery}).then(res => {
      let {total,rows} = res;
      rows = rows || [];
      if(!empty(rows)){
        rows.map(m=>{
          let {salaryType,salaryMax,salaryMin,companyBo} = m;
        //  .replace(/<br>/g, '').replace(/<br[^>]*\/>/gi, '\n')
          if(companyBo){
            m.companyBo.summary = m.companyBo.summary.replace(/<br>/g,'').replace(/\s+/g,'') 
          }
          m.salary = formatSalary(salaryType,salaryMax,salaryMin,1)
        })
      }
      this.setData({wLoding:false})
      if(wquery.pageNum==1){
        this.setData({jobArr: rows || []});
        if(rows.length == total){
          total==0?this.setData({showWLoading:false}):this.setData({showWLoading:true})
          this.setData({wHasMore:false});
        }
        return
      }
      if(wquery.pageNum>1){
         
        this.setData({jobArr: this.data.jobArr.concat(rows)})
      }
      if(total >0){
        let len = this.data.jobArr.length;
        len<total ? this.setData({wHasMore:true}): this.setData({wHasMore:false,showWLoading:true})
      }
    }).catch(err=>{
      this.setData({wLoding:false})
    })
  },
  getCardList() {
    let {cquery} = this.data;
    cardList(cquery).then(res => {
      this.setData({cLoding:false})
      let {total,rows} = res;
      let yearArr = localData('yearArr');
      rows = rows || [];
      if(!empty(rows)&& !empty(yearArr)){
        rows.map(m=>{
          let has = yearArr.filter(f=>f.value== m.workDate);
          if(!empty(has)){
            m.workDateStr =  has[0].name;
          }
          
        })
      }

      if(cquery.pageNum==1){
        this.setData({workerArr: rows})
      
        if(rows.length == total){ 
          this.setData({cHasMore:false})
          total==0?this.setData({showCLoading:false}):this.setData({showCLoading:true})
          return
        };  
      }
      if(cquery.pageNum>1){
      
        this.setData({workerArr: this.data.workerArr.concat(rows)})
      }
      if(total >0){
        let len = this.data.workerArr.length;
        len<total? this.setData({cHasMore:true}) : this.setData({cHasMore:false,showCLoading:true})
      }
    }).catch(err=>{
      this.setData({cLoding:false})
    })
  },
  getBanner() {
    banner().then(res => {
      this.setData({
        bannerArr: res.rows
      })
    })
  },
  toggleDrop(e){
    let type = e.currentTarget.dataset.type;
    let { isFixed, reginFlag, indusFlag} = this.data;
    this.updateQuery();
    if(type == 'regin'){
      indusFlag=false;
      reginFlag=!reginFlag;
      isFixed = !reginFlag;
      this.setData({reginFlag,indusFlag});
    }else{
      //关闭地区
      this.setData({reginFlag:false});

      if(empty(this.data.indusArr)){
        this.setData({emptyShow:true});
      }else{
        indusFlag=!indusFlag;
        isFixed = !indusFlag;
        this.setData({indusFlag});
      }
    }
    
    if(reginFlag || indusFlag){
      this.setData({isFixed:true})
      wx.hideTabBar({
        animation: true,
      })
      // 
      wx.pageScrollTo({
        scrollTop: 300,
        duration: 50
      })
    }else{
      wx.showTabBar({
        animation: true,
      }) 
    }
  },
 
  async qqGeoInfo(latitude,longitude){
    let ad_info = await getCityCode(`${latitude},${longitude}`);
    let {city,adcode} = ad_info, citySelect=localData('citySelect') || {};
    if(empty(citySelect)){
      let id = adcode.substr(0,4)+'00';
      this.updateQuery()
      this.setData({curCityTit:city})
        localData('citySelect',{id,text:city,disable:false})
    }
  },
  getPosByNet(){
    let clearCity =  localData('clearCity');
    if(clearCity==1) return
    ipPos({}).then(res=>{
      
      let citySelect=localData('citySelect') || {};
      if(empty(citySelect)){
        var l=res.cityCode.substr(0,2);
        var r=res.cityCode.substr(2);
        if(r=='0000'){
          r = '0100'
          res.cityCode = l+r
        }
        localData('citySelect',{id: res.cityCode,text: res.city,disable:false})
        this.updateQuery()
        this.setData({curCityTit: res.city})
      }
    })
  },
  checkLocation(){
    if(!wx.getFuzzyLocation){
      //console.log('不支持模糊定位');
      this.getPosByNet()
      return
    }
    if(!gbData('gpsOpen')){
      wx.showModal({
        title:'开启定位',
        content:'请开启手机GPS定位功能，如果已开启，点击【确认】重新加载',
        confirmText:'确认',
        cancelText:'取消',
        success:(res)=> {
          if (res.confirm) {
           wx.reLaunch({
             url: '/pages/index/index',
           })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      });
      return
    }
    // undefined-初始化  false-非初始化未授权   true-已授权
    wx.getSetting({
      success:(res)=> {
        //console.log(res.authSetting['scope.userFuzzyLocation'])
        if (res.authSetting['scope.userFuzzyLocation'] == false) {
          wx.showModal({
            title:'位置授权',
            content:'为了提供更精准的信息服务，请点击【确认】打开授权窗口，位置信息->选择允许',
            confirmText:'确认',
            cancelText:'稍后',
            
            success:set=> {
              if (set.confirm) {
                wx.openSetting()
              } else if (set.cancel) {
                this.getPosByNet()
              }
            }
          })
        } else if(res.authSetting['scope.userFuzzyLocation'] == undefined ){
          //console.log('undefined-初始化')
          wx.authorize({
            scope: 'scope.userFuzzyLocation',
            success:(auth)=> {
           //   console.log(auth)
              if(auth.errMsg == 'authorize:ok'){
                //console.log('初始化-允许授权')
                wx.getFuzzyLocation({
                  type: 'gcj02',
                  success:(gcj)=>{
                    let {latitude,longitude} =gcj;
                    this.qqGeoInfo(latitude,longitude);
                    //localData('userLocation',{latitude,longitude});
                  },fail:f=>{
                    this.getPosByNet()
                  }
                })
              }
            },
            fail: () => {
              wx.showToast({
                title: '需要您授权位置信息',
                duration: 1500
              })
              wx.openSetting()
            }                  
          });
        } else if( res.authSetting['scope.userFuzzyLocation'] == true ){
          wx.getFuzzyLocation({
            type: 'gcj02',
            success:(gcj)=>{
              let {latitude,longitude} =gcj;
              this.qqGeoInfo(latitude,longitude);
            },fail:err=>{
              this.getPosByNet()
            }
          })
        }
      }
    })
  }
})