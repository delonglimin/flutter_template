import {jobs,cardList,teamList} from '../../api/job'
import { empty,localData,gbData } from '../../utils/index'
Page({
	data: {
    curType:0,
    keytext:'',
    jLoading:false,
    wLoading:false,
    tLoading:false,
    jHasMore:false,
    wHasMore:false,
    tHasMore:false,
    showJLoad:false,
    showWLoad:false,
    showTLoad:false,
    query:{
      city:'',
      jobType:null,
      jobWorkerType:null,//用工类型 0-零工 1-全职
      needWorker:null,
      publisherCompanyId:null, // 发布公司ID
      publisherUserId:null, // 发布人ID
      publisherUserType:null,//0-普通用户 1-企业用户
      title:'',
      searchWord:'',
      benifitList:[],
      userVerifyStatus:null,//0-未认证 1-已认证
      status:1,//上下架状态 0-上架 1-下架
      verifyStatus:1, //0-待审核 1-审核成功 2-审核失败
      pageNum:1,
      pageSize:10,
    },
    query2:{
      pageNum:1,
      pageSize:10,
      cardName:'',
      searchWord:'',
      cityList:[],
      industryList:[],
      sex:0,
      workDate:null,
      cardCertificateKey:null
    },
    query3:{
      pageNum:1,
      pageSize:10,
      cardName:'',
      cityList:[],
      industryList:[],
      cardType:1,
      totalNumber:0,
      groupLeaderName:'',
      note:''
    },
    wtabActive:0,
    tabActive:0,
    fixtopheight:0,
		isSearch: false,
    placeholder:'',
		historyData:[],
		jobArr: [],
		teamArr: [],
		workerArr:[],
	},


	onLoad (options) {
    let {type} =options,title='',placeholder='';
    type=Number(type);
    this.setData({curType:type})
    switch (type) {
      case 4:
        title='企业直聘'
        placeholder='输入关键词搜索企业直聘'
        break;
      case 3:
        title='找零工'
        placeholder='输入关键词搜索零工'
        break;
      case 1:
        title='找活干'
        placeholder='输入关键词搜索工作'
        break;
      case 2:
        title='搜工人'
        placeholder='输入关键词搜索工人、班组'
        break;
      case 0:
        title='搜索'
        placeholder='输入关键词搜索工作、工人'
        break;
    }
    this.setData({placeholder})
    wx.setNavigationBarTitle({title})
  },
	onReady() {},
	onShow () {
    let his = localData('searchKey') ||[];
    this.setData({historyData:his})
  },
	onHide () {},


	onUnload () {},
	onReachBottom () {
    //console.log('到底', this.data.curType)
    if(this.data.curType==0){
      let {tabActive} =this.data;
      if(tabActive==0){
        let {query,jLoading,jHasMore} = this.data;
        if(jLoading || !jHasMore) return
        this.setData({jLoading:true});
        let num = query.pageNum;
        num++;
      
        this.setData({'query.pageNum':num})
        this.getList()
      }
      if(tabActive==1){
        let {query2,wLoading,wHasMore} = this.data;
        console.log(query2,wLoading,wHasMore)
        if(wLoading || !wHasMore) return
        this.setData({wLoading:true});
        let num = query2.pageNum;
        num++;
        this.setData({'query2.pageNum':num})
        this.getCardList()
        return
      }
      if(tabActive==2){
        let {query3,tLoading,tHasMore} = this.data;
        console.log(query3,tLoading,tHasMore)
        if(tLoading || !tHasMore) return
        this.setData({tLoading:true});
        let num = query3.pageNum;
        num++;
        this.setData({'query3.pageNum':num})
        this.getTeamList()
        return
      }
      return
    }
    if(this.data.curType==1){
      let {query,jLoading,jHasMore} = this.data;
      console.log(query,jLoading,jHasMore)
      if(jLoading || !jHasMore) return
      this.setData({jLoading:true});
      let num = query.pageNum;
      num++;
     
      this.setData({'query.pageNum':num})
      this.getList()
      return
    }
    if(this.data.curType==2){
      return
    }
  },
	clearhis() {
		this.setData({ historyData: [] })
		localData('searchKey', [])
  },
  getInputVal(e){
    this.setData({keytext:e.detail})
  },
	async tagserach(e) {
    this.setData({ isSearch: true })
    let type = this.data.curType;
    let str = e.target.dataset.name;
    this.setData({keytext:str});
    this.doSearch(type,str)
	},
  getlistFilter(e){
    let type = e.target.dataset.type
    this.setData({tabActive:type})
  },
  getWtab(e){
    let type = e.target.dataset.type
    this.setData({wtabActive:type})
  },
	goSearch(e) { 
    let word = e.detail;
		this.setData({isSearch:true})
		
    if(!empty(word)){
      let arr = this.data.historyData || [];
      if (!empty(arr)) {
        let idx = arr.findIndex((f) => f == word)
        if (idx<0) arr.push(word)
        this.setData({ historyData: arr })
        localData('searchKey', arr)
      }else{
        arr.push(word)
        this.setData({ historyData: arr })
        localData('searchKey', arr)
      }
    }
		
    let curtype = this.data.curType;
    this.doSearch(curtype,word);
  },
  doSearch(type,str){
    if(type==0){
      this.setData({
        'query.searchWord':str,
        'query.pageNum':1,
        'query2.searchWord':str,
        'query2.pageNum':1,
        'query3.searchWord':str,
        'query3.pageNum':1
      });
      this.getList();
      this.getCardList();
      this.getTeamList();
      return
    }
    if(type==1 || type==3){
      this.setData({'query.searchWord':str,'query.pageNum':1})
      this.getList();
      return
    }
    if(type==4){
      this.setData({'query.searchWord':str,'query.publisherUserType':1,'query.pageNum':1})
      this.getList();
      return
    }
    if(type==2){
      this.setData({'query3.searchWord':str,'query2.searchWord':str,'query2.pageNum':1,'query3.pageNum':1})
      this.getCardList();
      this.getTeamList();
    }
  },
  getList(){
    jobs({...this.data.query}).then(res=>{
      let {currentPage,rows,total} = res;
      rows = rows || [];
      this.setData({jLoading:false})
      if(currentPage==1){
        this.setData({jobArr: rows});
        if(rows.length == total){
          total==0?this.setData({showJLoad:false}):this.setData({showJLoad:true})
          this.setData({jHasMore:false});
          return
        }
        //this.setData({jHasMore:true});
      }
      if(currentPage>1){
        rows = rows.concat(this.data.jobArr);
        this.setData({jobArr: rows})
      }
      if(total >0){
        let len = this.data.jobArr.length;
        len<total ? this.setData({jHasMore:true}): this.setData({jHasMore:false,showJLoad:true})
      }
    }).catch(err=>{
      this.setData({jLoading:false})
    })
  },
  //个人名片
  getCardList(){
    cardList({...this.data.query2}).then(res=>{
      this.setData({wLoading:false})
      let {currentPage,rows,total} = res;
      rows = rows || [];
      if(currentPage==1){
        this.setData({workerArr: rows});
        if(rows.length == total){
          total==0?this.setData({showWLoad:false}):this.setData({showWLoad:true})
          this.setData({wHasMore:false});
        }
        return
      }
      if(currentPage>1){
        rows = rows.concat(this.data.workerArr);
        this.setData({workerArr: rows})
      }
      if(total >0){
        let len = this.data.workerArr.length;
        len<total ? this.setData({wHasMore:true}): this.setData({wHasMore:false,showWLoad:true})
      }
    }).catch(err=>{
      this.setData({wLoading:false})
    })
  },
  //班组名片
  getTeamList(){
    teamList({...this.data.query3}).then(res=>{
    
      this.setData({tLoading:false})
      let {currentPage,rows,total} = res;
      rows = rows || [];
      if(currentPage==1){
        this.setData({teamArr: rows});
        if(rows.length == total){
          total==0?this.setData({showTLoad:false}):this.setData({showTLoad:true})
          this.setData({tHasMore:false});
        }
        return
      }
      if(currentPage>1){
        rows = rows.concat(this.data.teamArr);
        this.setData({teamArr: rows})
      }
      if(total >0){
        let len = this.data.teamArr.length;
        len<total ? this.setData({tHasMore:true}): this.setData({tHasMore:false,showTLoad:true})
      }
    }).catch(err=>{
      this.setData({tLoading:false})
    })
  },
  
})
