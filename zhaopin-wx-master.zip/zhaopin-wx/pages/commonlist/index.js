import { userJob,comJobList } from '../../api/job'
Page({

  data: {
    jobArr:[],
    HasMore:true ,showLoading:false,
   
  },
 
  onLoad(o) {
     let {id,name,type}=o;
     if(id){
      wx.setNavigationBarTitle({
        title: `${name} 的招工信息`,
      })
      if(type==1){
        this.loadComJobs(id)
        return
      }
      this.userJob(id);
     }
  },
  loadComJobs(id){
    comJobList({publisherCompanyId:id}).then(res=>{
      let list = res || [];
      this.setData({jobArr: list})
      if(list.length == 0) {
        this.setData({showLoading:false});
        this.setData({HasMore:false})
      }else{
        this.setData({showLoading:true})
      }
    })
  },
  userJob(id){
    userJob({publisherUserId:id}).then(res=>{
      let list = res || [];
      this.setData({jobArr: list})
      if(list.length == total) {
        total==0? this.setData({showLoading:false}): this.setData({showLoading:true});
        this.setData({HasMore:false})
        
      };
    }).catch(err=>{
      
    })
  },
})