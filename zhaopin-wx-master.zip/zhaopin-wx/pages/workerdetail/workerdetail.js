import {cardDetail,original} from '../../api/base'
import {addFav,removeFav,commonlog,sharelog,isReport,realWx} from '../../api/job'
import {addblack,viewCard} from '../../api/user'
import {getRealCall,getRealWx} from '../../utils/getData'
import {msgToast,empty,loginCtrl,gbData,localData,tidyBrBack,getUrlParams} from '../../utils/index'
import Dialog from '@vant/weapp/dialog/dialog';

Page({
  data: {
    isClose:false,
    showClose:false,
    canPrev:false,
    type:null,
    yearArr:localData('yearArr') || [],
    detail: {isFavorite:0,status:1, isDelete:0},
    fileList:[],
    showReport:false,
    isLogin:gbData('isLogin'),
    //withpic:
  },

  onLoad(options) {
    let pages = getCurrentPages();
    (pages[pages.length - 2])? this.setData({canPrev:true}) : this.setData({canPrev:false});
    if(options.q){
      console.log('扫码')
      const q = decodeURIComponent(options.q);
      let params = getUrlParams(q);
      let {id,cardType} = params;
      if(id){
        this.setData({type:cardType,relationId:id});
        this.getDetail(id,cardType,2);
      }
    }else{
      console.log('小程序',options)
      let {id,type,userid,fromview} = options;
      let source = options.source>-1? options.source :2;
      if(fromview && fromview==1){
        //来自-谁看过我
        //console.log('谁看过我',userid,fromview)
        this.getFromViewDetail(userid,type,source)
        this.setData({type})
      }else{
        //来自名片列表
        if(options.cardType) {
          type = options.cardType;
        }
        this.setData({type,relationId:id})
        this.getDetail(id,type,source)
        
      }
    }
  },
  backLeft(){
   if(this.data.canPrev){
     wx.navigateBack({//返回
       delta: 1
     })
   }else{
      wx.reLaunch({
        url: '/pages/index/index',
      })
    }
  },
  
 
  async reportItem(){
    if(!loginCtrl(true)) return
    
    let {id,userId} =this.data.detail,selfId = localData('userId');

    if(this.data.isClose){
      msgToast('名片已关闭，无法举报')
      return
    }
  
   
    if(selfId == userId){
      this.setData({showShare:false})
      msgToast('不能举报自己','error')
      return
    }
    let reFlag = await this.checkReport(id,0);
    // console.log('reFlag',reFlag)
     if(reFlag==1){
       msgToast('您已举报此名片')
       this.setData({showShare:false})
       return
     }
    let reportParams={
      fromPoint:0, //0-微信 1-企业端
      fromType:0, //0-名片 1-职位
      fromRelationId:id, //id
      reportRelationType: 0,  //被举报类型 0-微信用户 1-企业
      reportRelationId:userId //被举报人关联ID 个人ID或公司ID
    }
    this.setData({showReport:true, reportParams});
  },
  setBlack(){
    if(!loginCtrl(true)) return
  
    let {userId} =this.data.detail,selfid = localData('userId');
    if(this.data.isClose){
      msgToast('名片已关闭')
    }
    if(userId==selfid){
      msgToast('不能拉黑自己','error')
      return
    }
    Dialog.confirm({
      title: '拉黑此帐户',
      message: '拉黑后，您和对方将相互不可见',
    }).then(() => {
      let {id,userId} =this.data.detail;
      addblack({fromPoint:0,fromType:0,fromRelationId:id,blackRelationType:0,blackRelationId:userId}).then(res=>{
        wx.navigateBack({
          delta: 1,
        })
      }).catch(err=>{
        if(err.msg && err.msg.indexOf('名片已关闭')>-1){
          this.setData({isClose:true});
          wx.navigateBack({
            delta: 1,
          });
        }
      })
    }).catch(() => {
      
    });
    
    
  },
  getCardStatus(e){
    console.log('getCardStatus',e)
    this.setData({isClose:true})
  },
  //收藏
  collectItem(){
    if(!loginCtrl(true)) return
   
    let {type,relationId,detail} =this.data;
    if(this.data.isClose){
      msgToast('名片已关闭')
    }
    let cardType = type==1? 2 : 3; //2-工人名片   3 班组名片
   
    let status = Number(this.data.detail.isFavorite);
 
    if(status==0){
      addFav({type:cardType,relationId}).then(res=>{
        this.setData({'detail.isFavorite':1})
        msgToast('收藏成功')
        
      }).catch(err=>{
         console.log(err)
         if(err.msg=='名片已关闭'){
          msgToast('收藏成功')
          this.setData({'detail.isFavorite':1,isClose:true})
         }
      })
    }else{
      removeFav({type:cardType,relationId}).then(res=>{
        this.setData({'detail.isFavorite':0})
        msgToast('取消收藏成功')
        
      }).catch(err=>{
        msgToast('取消收藏成功')
        if(err.msg=='名片已关闭'){
          this.setData({'detail.isFavorite':0,isClose:true})
        }
      })
    }
  },
  onShareAppMessage(options){
    let {type,relationId,detail,isLogin} =this.data;
    if(isLogin){
      this.addShareLog(); 
    } 

      return {
        title:'我在仟活发现了好简历，快来看看吧',
        path: `/pages/workerdetail/workerdetail?id=${relationId}&type=${type}`,
        imageUrl:''
      }
  },
  onShareTimeline(){
    let {type,relationId,detail} =this.data;
   
    if(isLogin){
      this.addShareLog(); 
    } 
    return {
      title:'我在仟活发现了好简历，快来看看吧',
      path: `id=${relationId}&type=${type}`,
      imageUrl:''
    }
  },
  addShareLog(){
    let userid = localData('userInfo').id;
  
    // shareType  0-职位 1-培训  2名片 .  shareContentId
    sharelog({userId:userid,shareType:2,shareContentId:this.data.relationId}).then(res=>{
      msgToast('分享职位成功','success')
    })
  },
  //分享
  shareItem(){

    if(this.data.isClose){
      msgToast('名片已关闭，无法分享')
      return
    }
 
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage']
    })
  },
  async setCopy(){
    if(!loginCtrl(true)) return
    let data = await getRealWx(this.data.detail.id);
     
    if(!data) return
    wx.setClipboardData({
      data: data,
      success:res=>{
        msgToast('复制成功')
      }
    })
  },
  setOnshow(){
    console.log('canOnShow')
    gbData('canOnShow',0)
  },
  async delivCardItem(){
    if(!loginCtrl(true)) return;
    let {detail}=this.data;
    if(this.data.isClose){
      msgToast('名片已关闭，无法分享')
      return
    }
   
    let tel = await getRealCall(detail.id,0);
    if(tel.msg && tel.msg.indexOf('名片已关闭')>-1){
      msgToast('名片已关闭，无法打电话')
      this.setData({isClose:true})
      return
    }
    if(empty(tel)) return;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  getDetail(id,type,source){
    cardDetail({id}).then(res=>{
     
      let data = res.jobUserCardPersonalBo || res.jobUserCardGroupBo;
      if(data.status==0){
        this.setData({showClose:true})
        return
      }
      if(loginCtrl()){
        let userId = localData('userId');
        if(userId != data.userId){
          console.log('不是自己的')
          this.upDateLog(id, data.userId, source)
        }
      }
      let fileList =[];
      if(!empty(data.certificateUrl)){
        let imgArr=[];
          if(data.certificateUrl.indexOf(',')<0 && data.certificateUrl.indexOf(';')<0){
            imgArr = [data.certificateUrl];
          }else{
            if(data.certificateUrl.indexOf(',')>-1){
              imgArr = data.certificateUrl.split(',')
            }else{
              imgArr = data.certificateUrl.split(';')
            }
          }
          fileList = imgArr.map(p=>{
            return {
              url:p
            }
          });
      }
      this.setData({fileList})
      // if(!empty(data.contactPhone)){
      //   data.contactPhoneMix = data.contactPhone.substr(0,3)+'********'
      // }
      // if(!empty(data.cardWxNumber)){
      //   data.cardWxNumberMix = data.cardWxNumber.substr(0,3)+'********'
      // }
      if(!empty(data.cityLabelList)){
        data.cityLabelList = data.cityLabelList.toString().replace(/,/g,'、');
      }
      if(!empty(data.industryLabelList)){
        data.industryLabelList = data.industryLabelList.toString().replace(/,/g,'、');
      }
      if(!empty(data.note)){
        data.note = tidyBrBack(data.note)
      }
      if(type==1){
        if(!empty(this.data.yearArr)){
          this.data.yearArr.map(f=>{
            if(f.value==data.workDate) data.workDateName = f.name;
          });
        }
        this.setData({detail:data})
        return
      }
      // 班组详情
      this.setData({detail:data})
    })
  },
  getFromViewDetail(userId,type,source){
    viewCard({userId}).then(res=>{
     
      let info = type==1? res.jobUserCardPersonalBo : res.jobUserCardGroupBo;
      this.setData({relationId:info.id});

      if(loginCtrl()){
        let userId = localData('userId');
        if(userId != info.userId){
          console.log('不是自己的')
          this.upDateLog(info.id, info.userId, source)
        }
      }
      console.log(info.contactPhone,info.cardWxNumber)
      //fileList
      if(!empty(info.cardCertificateFileList)){
        let fileList = info.cardCertificateFileList.map(p=>{
          return {
            url: p.proUrl,
            name: p.proName
          }
        });
        this.setData({fileList})
      }

      if(!empty(info.contactPhone)){
        info.contactPhoneMix = info.contactPhone.substr(0,3)+'********'
      }
      if(!empty(info.cardWxNumber)){
        info.cardWxNumberMix = info.cardWxNumber.substr(0,3)+'********'
      }

      if(!empty(info.note)){
        info.note = tidyBrBack(info.note)
      }
      if(type==1){
        if(!empty(this.data.yearArr)){
          this.data.yearArr.map(f=>{
            if(f.value==info.workDate) info.workDateName = f.name;
          });
        }
        this.setData({detail:info})
        return
      }
      // 班组详情
      this.setData({detail:info})
    })
  },
  // id,userid,source
  upDateLog(cardId,cardUserId,pageIndex){
    let userId = localData('userId');
    cardId = Number(cardId);
    cardUserId = Number(cardUserId);
    pageIndex = Number(pageIndex);
    let param ={
      cardType:this.data.type==1?0:1,
      userId,
      type:0,//1职位 0名片
      cardId,
      cardUserId,
      userType:0,
      pageIndex,//来源  0-微信零工页面 1-微信感兴趣页面 2-其它
    }
    commonlog(param).then(res=>{
      console.log('查看日志')
    })
  },
  checkReport(id,type){
    return new Promise((resolve,reject)=>{
      isReport({fromRelationId:id,fromType:type}).then(res=>{
        resolve(res)
      }).catch(err=>{
        reject()
      })
    })
  }
})