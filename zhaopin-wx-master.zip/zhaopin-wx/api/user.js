import {request} from '../utils/request'
import {base,img,save} from './config'


export const getOpenId=(data)=>{
  return request.post(`/login/getOpenId`,data)
}
export const wxlogin=(data)=>{
  return request.post(`/login/login1Key`,data)
}
export const userinfo=(data)=>{
  return request.post(`/user/getInfo`,data)
}
export const upDateUser=(data)=>{
  return request.post(`/user/edit`,data)
}
 
export const sendSms=(data)=>{
  return request.post(`/mp/sendSmsCode`,data)
}
export const smsLogin=(data)=>{
  return request.post(`/mp/loginPhoneCode`,data)
}
export const addCard=(data)=>{
  
  return request.post(`/jobUserCard/addNewUserCard`,data)
 // return request.post(`/jobUserCard/addNewPersonalUserCard`,data) 原接口
}

export const editCard=(data)=>{
  return request.post(`/jobUserCard/editUserCard`,data)
 // 废弃  return request.post(`/jobUserCard/editPersonalUserCard`,data)
}
// 废弃
export const addGpCard=(data)=>{
  return request.post(`/jobUserCard/addNewGroupUserCard`,data)
}
// 废弃
export const editGpCard=(data)=>{
  return request.post(`/jobUserCard/editGroupUserCard`,data)
}


export const addFeed=(data)=>{
  return request.post(`/feedback/addFeedback`,data)
}

export const viewCard=(data)=>{
  return request.post(`/jobUserCard/getUserCardByUserId`,data)
}

export const delImg = (data)=>{
  return request.post(`/oss/deleteOneFile`,data)
}

//转盘记录
export const drawHis = (data)=>{
  return request.get(`/luckyWheel/getRecordList`,data)
}
export const drawGoods = (data)=>{
  return request.get(`/luckyWheel/getWheelItemList`,data)
}
export const drawLuck = (data)=>{
  return request.get(`/luckyWheel/getLotteryList`,data)
}
export const drawDo = (data)=>{
  return request.get(`/luckyWheel/addLottery`,data)
}

// 商城 
export const shopList = (data)=>{
  return request.get(`/goods/getList`,data)
}
export const transIt = (data)=>{
  return request.post(`/goods/editExchangeGoods`,data)
}
export const scoreHis = (data)=>{
  return request.get(`/userIntegralLog/getList`,data)
}
 
export const orderHis = (data)=>{
  return request.get(`/order/getExchangeList`,data)
}
export const taskList = (data)=>{
  return request.get(`/integralTask/getIntegralTaskList`,data)
}
export const signHis = (data)=>{
  return request.get(`/signin/getCurrentMonthList`,data)
}
export const signDay = (data)=>{
  return request.post(`/signin/addSignin`,data)
}
export const sign3Day = ()=>{
  return request.get(`/signin/getRecentThreeDaysSigninList`)
}
//更新定位
export const updatePos = (data)=>{
  return request.post(`/user/updateLocation`,data)
}
export const favJobs = (data)=>{
  return request.post(`/userFavorite/getJobList`,data)
}
export const favCardW = (data)=>{
  return request.post(`/userFavorite/getEmployeeList`,data)
}
export const favCardT = (data)=>{
  return request.post(`/userFavorite/getGroupList`,data)
}

// 培训


export const trainList = (data)=>{
  return request.post(`/training/getTrainingList`,data)
}

export const mytrain = (data)=>{
  return request.post(`/training/myTrainingList`,data)
}
 
export const trainlog = (data)=>{
  return request.post(`/training/addMyTraining`,data)
}
//
export const msgList=(data)=>{
  return request.get(`/message/getMessageList`,data)
}
export const clearMsg=(data)=>{
  return request.post(`/message/editMessageReadStatus`,data)
}
//消息-投递的名片
export const msgCard=(data)=>{
  return request.post(`/jobLog/getMyReceiveCardList`,data)
}
// 查询未完成订单
export const hasorder=(param)=>{
  return request.get(`/order/getExistUnHandledOrder`,param)
}
export const orderDetail=(param)=>{
  return request.get(`/order/getOrderInfo`,param)
}
export const logicLog=(param)=>{
  return request.get(`/order/getOrderLogisticsInfo`,param)
}

export const shopOrderAdd=(data)=>{
  return request.post(`/order/addOrderWithAddress`,data)
}
export const adrDel=(param)=>{
  return request.get(`/address/deleteAddress`,param)
}
export const adrAdd=(data)=>{
  return request.post(`/address/addAddress`,data)
}
export const editAdr=(data)=>{
  return request.post(`/address/editAddress`,data)
}
export const adrList=(data)=>{
  return request.get(`/address/getAddressList`,data)
}

//black
export const blackList=(data)=>{
  return request.post(`/job/getBlackList`,data)
}
export const delblack=(data)=>{
  return request.post(`/job/editReleaseBlackRecord`,data)
}
export const addblack=(data)=>{
  return request.post(`/job/addBlackRecord`,data)
}

export const report=(data)=>{
  return request.post(`/job/addReportRecord`,data)
}

export const getOcrInfo=(data)=>{
  return request.post(`/user/ocrIdentifyCard`,data)
}

export const postRealNameInfo=(data)=>{
  return request.post(`/user/verifyIdNamePhone`,data)
}
 
