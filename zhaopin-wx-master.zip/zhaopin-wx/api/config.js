
  const base='http://10.1.1.109:7003/zhaopin-mp';
  const img='http://10.1.1.109:9002';
  const save='http://10.1.1.109:7003';
 
  export {base,img,save}