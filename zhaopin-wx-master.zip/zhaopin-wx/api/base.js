import {request} from '../utils/request'
import {base,img} from './config'
// 省市 
export const getRegin=(data)=>{
  return request.post(`/dataDict/getRegionList`,data)
}
// 元数据
export const original=(data)=>{
  return request.post(`/dataDict/getList`,data)
}
export const mydiscts=(data)=>{
  
  return request.post(`/dataDict/getListByList`,data)
}

export const originallv2=(data)=>{
  return request.post(`/dataDict/getChildrenList`,data)
}

export const addJob=(data)=>{
  return request.post(`/job/addNewJob`,data)
}
export const banner=(param)=>{
  return request.get(`/banner/getBannerList`,param)
}
export const company=(data)=>{
  return request.post(`/company/getInfo`,data)
}

export const trainDetail=(data)=>{
  return request.post(`/training/getDetail`,data)
}
export const cardDetail=(data)=>{
 
  return request.post(`/jobUserCard/getUserCardById`,data)
}

export const articelDetail=(data)=>{
  return request.post(`/agreement/getInfoById`,data)
}


export const textForEdit=(data)=>{
  return request.post(`/wxCheck/getContentCheckMsg`,data)
}

export const imgForUpdate=(data)=>{
  return request.post(`/wxCheck/getImgCheckMsg`,data)
}

export const orderUpdate=(param)=>{
  return request.get(`/order/editOrderUserAddress`,param)
}
export const msgloglist=(param)=>{
  return request.get(`/message/queryUserMessage`,param)
}
// 邀请注册

export const regNum=(param)=>{
  return request.get(`/invitation/queryUserInvitation`,param)
}
export const regShare=(param)=>{
  return request.get(`/invitation/shareLink`,param)
}

export const ipPos=(param)=>{
  return request.get(`/dataDict/getRequestInCity`,param)
}//dataDict/getRequestInCity

export const realPhone=(param)=>{
  return request.get(`/job/getMobilePhoneById`,param)
}