
import {request} from '../utils/request'
import {base,img,save} from './config'

export const realWx=(data)=>{
  return request.get(`/job/getWeChatNo`,data)
}
export const tooglejobs=(data)=>{
  return request.post(`/job/editJobStatus`,data)
}
export const jobs=(data)=>{
  return request.post(`/job/getJobList`,data)
}
export const jobItem=(data)=>{
  return request.post(`/job/getJobDetail`,data)
}
export const callog=(data)=>{
  return request.post(`/jobLog/addCallLog`,data)
}
// 沟通过的 list
export const callList=(data)=>{
  return request.post(`/jobLog/jobLog/getJobCallLogList`,data)
}
export const calledMe=(data)=>{
  return request.post(`/jobLog/getOneJobCallList`,data)
}

//投递
export const deliv=(data)=>{
  return request.post(`/jobLog/addJobReceiveCardLog`,data)
}
export const addFav = (data)=>{
  return request.post(`/userFavorite/add`,data)
}
export const removeFav = (data)=>{
  return request.post(`/userFavorite/delete`,data)
}

export const isReport = (data)=>{
  return request.post(`/job/getIsReport`,data)
}
// 工人名片列表
export const cardList = (data)=>{
  return request.post(`/jobUserCard/getPersonalList`,data)
}
export const comJobList = (data)=>{
  return request.post(`/job/getCompanyJob`,data)
}

// 班组名片列表
export const teamList = (data)=>{
  return request.post(`/jobUserCard/getGroupList`,data)
}

 
export const myJobWithStatistics=(data)=>{
  return request.post(`/job/getMyJobWithStatisticsList`,data)
}

export const postedMe=(data)=>{
  return request.post(`/jobLog/getReceiveCardByJobIdList`,data)
}
export const posted=(data)=>{
  return request.post(`/jobLog/getJobReceiveCardList`,data)
}
export const viewedMe=(data)=>{
  return request.post(`/jobLog/getCardWatchedLogByJobIdList`,data)
}
export const meView=(data)=>{
  return request.post(`/jobLog/getCardWatchedLogList`,data)
}

export const userJob=(data)=>{
  return request.post(`/job/getUserJobList`,data)
}
// /
export const getFindStatus=(data)=>{
  return request.post(`/jobUserCard/getOddStatus`,data)
}
export const updateFindJob=(data)=>{
  return request.post(`/jobUserCard/eidtOddStatus`,data)
}

export const dayFresh=(data)=>{
  return request.post(`/jobUserCard/getDayFreshNumber`,data)
}
export const doFresh=(data)=>{
  return request.post(`/jobUserCard/addDayFreshNumber`,data)
}
export const checkStatus=(data)=>{
  return request.get(`/job/checkStatus`,data)
}
export const delJob=(data)=>{
  return request.get(`/job/delete`,data)
}

//更新招工信息
export const refreshJob=(data)=>{
  return request.post(`/job/editJob`,data)
}
export const refreshJobNum=(data)=>{
  return request.get(`/job/refresh`,data)
}

// 任务查看提交
export const commonlog=(data)=>{
  return request.post(`/jobLog/addJobCardWatchedLog`,data)
}
export const sharelog=(data)=>{
  return request.post(`/jobLog/addShareLog`,data)
}


export const msgViewed=(data)=>{
  return request.post(`/jobLog/getVerifyLogList`,data)
}

//
export const historyLog=(data)=>{
  return request.post(`/jobLog/getWatchedLogPageList`,data)
}
export const historyNum=(data)=>{
  return request.post(`/jobLog/getWatchedLogNumber`,data)
}
export const comEmploy=(data)=>{
  return request.post(`/job/getCompanyJobNumber`,data)
}

export const watchLog=(data)=>{
  return request.post(`/jobLog/getWatchedLogList`,data)
}
